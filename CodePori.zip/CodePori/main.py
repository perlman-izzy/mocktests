#!/usr/bin/env python3
# coding: utf-8
"""
CodePori (Proxy/Gemini) — driver-only pipeline with until-converged linter + guardrails.

Key behaviors:
- Strict JSON planning/generation (no app code).
- Namespace guard (avoid src/<pkg>.py vs src/<pkg>/ collisions).
- Linter runs UNTIL CONVERGED with budgets: time, LLM calls, and thrash detection.
- No fabrication of third-party modules; only touch src.*.
- Never mutate src/__init__.py.
- Pytest plugin safety: fallback to -p safelist and explicitly load pytest_cov when needed.

Environment toggles (defaults shown):
  GEMINI_PROXY_BASE="http://localhost:8000"
  CP_HTTP_TIMEOUT=180
  CP_ENABLE_LINTER=1
  CP_LLM_BUDGET=60                 # max LLM calls across linter repairs
  CP_LINTER_TIME_BUDGET=600        # seconds max spent in linter loop
  CP_LINTER_THRASH_LIMIT=2         # consecutive identical "gap signature" passes allowed
  CP_LINTER_PASS_CAP=50            # absolute cap just in case
  CP_JSON_RETRIES=6
  CP_AUTOFIX_RELATIVE=1
  CP_STRICT_CODEPORI=1
  CP_SKIP_THIRDPARTY_SYNTHESIS=1   # never write modules for non-src imports
  CP_NO_MUTATE_SRC_INIT=1
"""

from __future__ import annotations

import ast
import importlib
import json
import os
import pathlib
import re
import shutil
import subprocess
import sys
import textwrap
import time
import traceback
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple

import requests

try:
    import tomllib  # py311+
except Exception:  # pragma: no cover
    tomllib = None

# ---------------------- PATHS / CONFIG ----------------------
PROJECT_DIR = pathlib.Path(__file__).resolve().parent
OUT_DIR = PROJECT_DIR / "output"
CODE_DIR = OUT_DIR / "code"
LOG_FILE = OUT_DIR / "run.log"
PREV_SNAPSHOT = PROJECT_DIR / ".codepori_prev"

PROMPTS = {
    "project": PROJECT_DIR / "project_description.txt",
    "manager": PROJECT_DIR / "manager_bot.txt",
    "dev1": PROJECT_DIR / "dev_1.txt",
    "dev2": PROJECT_DIR / "dev_2.txt",
    "final1": PROJECT_DIR / "finalizer_bot_1.txt",
    "final2": PROJECT_DIR / "finalizer_bot_2.txt",
    "verify": PROJECT_DIR / "verfication_bot.txt",
}

PROXY_BASE = os.getenv("GEMINI_PROXY_BASE", "http://localhost:8000").rstrip("/")
PRIMARY_MODEL = "models/gemini-2.5-pro"
FALLBACK_MODEL = "models/gemini-2.5-flash"
TIMEOUT_SECONDS = int(os.getenv("CP_HTTP_TIMEOUT", "180"))

ENABLE_LINTER = os.getenv("CP_ENABLE_LINTER", "1") != "0"
JSON_RETRIES = max(1, int(os.getenv("CP_JSON_RETRIES", "6")))
AUTOFIX_RELATIVE = os.getenv("CP_AUTOFIX_RELATIVE", "1") != "0"
STRICT_CODEPORI = os.getenv("CP_STRICT_CODEPORI", "1") != "0"

# New budgets / guardrails
LLM_CALL_BUDGET = max(1, int(os.getenv("CP_LLM_BUDGET", "60")))
LINTER_TIME_BUDGET = max(30, int(os.getenv("CP_LINTER_TIME_BUDGET", "600")))
LINTER_THRASH_LIMIT = max(1, int(os.getenv("CP_LINTER_THRASH_LIMIT", "2")))
LINTER_PASS_CAP = max(1, int(os.getenv("CP_LINTER_PASS_CAP", "50")))
SKIP_THIRDPARTY_SYNTHESIS = os.getenv("CP_SKIP_THIRDPARTY_SYNTHESIS", "1") != "0"
NO_MUTATE_SRC_INIT = os.getenv("CP_NO_MUTATE_SRC_INIT", "1") != "0"

SAFE_PYTEST_PLUGINS = ("pytest_mock", "pyfakefs")

# Tiny allowlist for auto-installed *test* deps if referenced by tests
TEST_DEP_ALLOWLIST = {
    "pytest-cov": {"import_names": ["pytest_cov"], "pip": "pytest-cov"},
    "respx": {"import_names": ["respx"], "pip": "respx"},
}

# ---------------------- LOGGING ----------------------
def log(msg: str) -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    line = f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}"
    print(line, flush=True)
    with LOG_FILE.open("a", encoding="utf-8") as f:
        f.write(line + "\n")

# ---------------------- SNAPSHOT/DIFF ----------------------
def snapshot_previous() -> None:
    try:
        if PREV_SNAPSHOT.exists():
            shutil.rmtree(PREV_SNAPSHOT)
        if CODE_DIR.exists():
            shutil.copytree(CODE_DIR, PREV_SNAPSHOT)
        log(f"Snapshot saved: {PREV_SNAPSHOT}")
    except Exception as e:
        log(f"Snapshot warning: {e}")

def _list_rel(root: pathlib.Path) -> Set[str]:
    out: Set[str] = set()
    if not root.exists():
        return out
    for p in root.rglob("*"):
        if p.is_file():
            out.add(str(p.relative_to(root)))
    return out

def write_diff_report() -> None:
    try:
        report = OUT_DIR / "diff-report.txt"
        old = PREV_SNAPSHOT
        new = CODE_DIR
        added: List[str] = []
        removed: List[str] = []
        modified: List[str] = []

        old_set = _list_rel(old)
        new_set = _list_rel(new)
        for rel in sorted(new_set - old_set):
            added.append(rel)
        for rel in sorted(old_set - new_set):
            removed.append(rel)
        for rel in sorted(new_set & old_set):
            try:
                if (old / rel).read_bytes() != (new / rel).read_bytes():
                    modified.append(rel)
            except Exception:
                modified.append(rel)
        lines = [
            "# CodePori Diff Report",
            "",
            "## Added:",
            *((f"+ {a}" for a in added) if added else ["(none)"]),
            "",
            "## Removed:",
            *((f"- {r}" for r in removed) if removed else ["(none)"]),
            "",
            "## Modified:",
            *((f"* {m}" for m in modified) if modified else ["(none)"]),
            "",
        ]
        report.write_text("\n".join(lines), encoding="utf-8")
        log("Diff report written to ./output/diff-report.txt")
    except Exception as e:
        log(f"Diff report warning: {e}")

def log_diff_report_contents() -> None:
    try:
        p = OUT_DIR / "diff-report.txt"
        if not p.exists():
            log("Diff report not found.")
            return
        log("--- BEGIN DIFF REPORT ---")
        for ln in p.read_text(encoding="utf-8").splitlines():
            log(ln)
        log("--- END DIFF REPORT ---")
    except Exception as e:
        log(f"Diff report read warning: {e}")

# ---------------------- FILE UTIL + NAMESPACE GUARD ----------------------
def ensure_dirs() -> None:
    if OUT_DIR.exists():
        shutil.rmtree(OUT_DIR)
    CODE_DIR.mkdir(parents=True, exist_ok=True)

def read_text(p: pathlib.Path, default: str = "") -> str:
    try:
        return p.read_text(encoding="utf-8")
    except Exception:
        return default

def _namespace_guard_path(path: pathlib.Path) -> pathlib.Path:
    """
    If attempting to write src/foo.py while src/foo/ exists (package),
    redirect to src/foo/__init__.py. (We never create parallel module+package.)
    """
    if path.suffix == ".py":
        # If the stem's directory exists beside it, redirect to __init__.py
        pkg_dir = path.with_suffix("")
        if pkg_dir.exists() and pkg_dir.is_dir():
            guarded = pkg_dir / "__init__.py"
            log(f"Namespace guard: redirecting write {safe_relpath(path)} -> {safe_relpath(guarded)} (package exists)")
            return guarded
    return path

def write_text(p: pathlib.Path, content: str) -> None:
    p = _namespace_guard_path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    if not content.endswith("\n"):
        content += "\n"
    p.write_text(content, encoding="utf-8")

# ---- Hardened Python writer (authorized)
_CODE_FENCE_OPEN = re.compile(r"^```[^\n]*\n", re.MULTILINE)
_CODE_FENCE_CLOSE = re.compile(r"\n```$", re.MULTILINE)
_CODE_FIELD_TRIPLE = re.compile(r'"(?:[Cc]ode)"\s*:\s*"""([\s\S]*?)"""', re.DOTALL)
_CODE_FIELD_QUOTED = re.compile(r'"(?:[Cc]ode)"\s*:\s*"([\s\S]*?)"\s*}', re.DOTALL)

def _sanitize_llm_code(raw: str) -> str:
    if not isinstance(raw, str):
        return ""
    s = raw.strip()
    s = _CODE_FENCE_OPEN.sub("", s)
    s = _CODE_FENCE_CLOSE.sub("", s)
    m = _CODE_FIELD_TRIPLE.search(s)
    if m:
        s = m.group(1)
    else:
        m2 = _CODE_FIELD_QUOTED.search(s)
        if m2:
            try:
                s = bytes(m2.group(1), "utf-8").decode("unicode_escape")
            except Exception:
                s = m2.group(1)
    return (s.rstrip() + "\n") if s else ""

def _comment_offending(lines: List[str], idx: int, marker: str) -> List[str]:
    out = lines[:]
    if 0 <= idx < len(out):
        out[idx] = f"# {marker}: {out[idx]}"
        if idx + 1 < len(out) and out[idx + 1].lstrip().startswith((")", "]", "}", "elif", "else", "except", "finally")):
            out.insert(idx + 1, "pass\n")
    return out

def _compile_ok(code: str, filename: str) -> Tuple[bool, Optional[SyntaxError]]:
    try:
        compile(code, filename, "exec")
        return True, None
    except SyntaxError as e:  # pragma: no cover
        return False, e

def write_python_file(path: pathlib.Path, code: str) -> None:
    """
    Hardened writer:
      1) sanitize LLM cruft (fences / JSON-wrapped code)
      2) try compile; if SyntaxError → auto-comment bad line (up to 5 attempts)
      3) last resort: emit a valid stub that preserves the raw content
    """
    path = _namespace_guard_path(path)
    cleaned = textwrap.dedent(_sanitize_llm_code(code))
    path.parent.mkdir(parents=True, exist_ok=True)

    attempts = 0
    src_lines = (cleaned or "\n").splitlines(keepends=True)
    while attempts < 5:
        candidate = "".join(src_lines)
        ok, err = _compile_ok(candidate, str(path))
        if ok:
            path.write_text(candidate, encoding="utf-8")
            return
        bad_idx = (err.lineno - 1) if (err and err.lineno) else max(0, len(src_lines) - 1)
        src_lines = _comment_offending(src_lines, bad_idx, "FIXME(auto-comment)")
        attempts += 1

    escaped = cleaned.replace('"""', r'\"\"\"')
    stub = (
        '"""Auto-stubbed by CodePori: original content preserved below."""\n\n'
        "def __codepori_stub__():\n    pass\n\n"
        f'RAW_CONTENT = """{escaped}"""\n'
    )
    path.write_text(stub, encoding="utf-8")

def safe_relpath(p: pathlib.Path) -> str:
    try:
        return str(p.relative_to(CODE_DIR))
    except Exception:
        return str(p)

# ---------------------- HTTP CLIENT (Proxy) ----------------------
@dataclass
class JsonCandidate:
    raw: str
    obj: dict
    code: str
    score: int
    reason: str

class ProxyGemini:
    def __init__(self, base: str, primary: str, fallback: str):
        self.base = base
        self.primary = primary
        self.fallback = fallback
        self.session = requests.Session()

    def _endpoint(self, model: str) -> str:
        return f"{self.base}/v1beta/models/{model}:generateContent"

    def _payload(self, prompt: str) -> Dict[str, Any]:
        return {
            "contents": [{"role": "user", "parts": [{"text": prompt}]}],
            "generationConfig": {"responseMimeType": "application/json"},
        }

    def _join_parts(self, data: Dict[str, Any]) -> str:
        try:
            parts = (data.get("candidates") or [{}])[0].get("content", {}).get("parts", [])
            out: List[str] = []
            for p in parts:
                t = p.get("text")
                if isinstance(t, str):
                    out.append(t)
            return "\n".join(out).strip()
        except Exception:
            return ""

    def ask(self, prompt: str) -> Optional[str]:
        for model in (self.primary, self.fallback):
            try:
                r = self.session.post(self._endpoint(model), json=self._payload(prompt), timeout=TIMEOUT_SECONDS)
                if r.ok:
                    text = self._join_parts(r.json())
                    if text:
                        if model == self.fallback:
                            log("Used fallback model successfully.")
                        return text
                    else:
                        log("Empty response text; trying fallback model." if model == self.primary else "Fallback returned empty text.")
                else:
                    log(f"Model {model} failed: HTTP {r.status_code} {(r.text or '')[:200]}")
            except Exception as e:
                log(f"Model {model} exception: {e}")
        return None

# ---------------------- JSON HELPERS ----------------------
_JSON_FENCE_RE = re.compile(r"```(?:json)?\s*(.*?)```", re.IGNORECASE | re.DOTALL)

def _balanced_json_slices(blob: str) -> List[str]:
    out: List[str] = []
    stack: List[str] = []
    start: Optional[int] = None
    for i, ch in enumerate(blob or ""):
        if ch in "{[":
            if not stack:
                start = i
            stack.append(ch)
        elif ch in "}]":
            if stack:
                opener = stack.pop()
                if (opener, ch) not in (("{", "}"), ("[", "]")):
                    stack.clear()
                    start = None
                    continue
                if not stack and start is not None:
                    out.append(blob[start : i + 1])
                    start = None
    return out

def _all_json_blobs(text: str) -> List[str]:
    blobs: List[str] = []
    for m in _JSON_FENCE_RE.finditer(text or ""):
        block = m.group(1).strip()
        if block:
            blobs.append(block)
    blobs.extend(_balanced_json_slices(text or ""))
    t = (text or "").strip()
    if t.startswith("{") or t.startswith("["):
        blobs.append(t)
    seen = set()
    uniq: List[str] = []
    for b in blobs:
        k = b.strip()
        if k and k not in seen:
            seen.add(k)
            uniq.append(k)
    return uniq

def _score_code_sanity(code: str) -> int:
    if not code or not code.strip():
        return 0
    s = code.strip()
    score = 0
    score += min(len(s), 100000) // 50
    if "\n" in s: score += 50
    if "import " in s: score += 50
    if "def " in s: score += 50
    if "class " in s: score += 30
    if "<FULL" in s.upper(): score -= 200
    return score

def parse_json_best(text: str, *, want: type = dict, require_code: bool = False, dump_dir: Optional[pathlib.Path] = None, tag: str = "generic") -> dict:
    if not isinstance(text, str):
        raise ValueError("non-string response")
    blobs = _all_json_blobs(text)
    if dump_dir:
        dump_dir.mkdir(parents=True, exist_ok=True)
        (dump_dir / f"{tag}.raw.txt").write_text(text, encoding="utf-8")
        (dump_dir / f"{tag}.blobs.count").write_text(str(len(blobs)), encoding="utf-8")
    candidates: List[JsonCandidate] = []
    last_err = None
    for blob in blobs:
        try:
            obj = json.loads(blob)
            if not isinstance(obj, want):
                continue
            code = str(obj.get("code", "")) if isinstance(obj, dict) else ""
            score = _score_code_sanity(code)
            reason = "ok"
            if require_code and not code.strip():
                reason = "empty_code"
            candidates.append(JsonCandidate(raw=blob, obj=obj, code=code, score=score, reason=reason))
        except Exception as e:
            last_err = str(e)
    candidates.sort(key=lambda c: (c.score, len(c.code)), reverse=True)
    if not candidates:
        raise ValueError(f"failed to parse {want.__name__} JSON ({last_err or 'no candidates'})")
    best = candidates[0]
    if require_code and not best.code.strip():
        raise ValueError("parsed JSON but best candidate has empty code (all candidates empty)")
    return best.obj

# ---------------------- PROMPTS ----------------------
def step_plan(llm: ProxyGemini) -> Dict[str, Any]:
    desc = read_text(PROMPTS["project"]) or "(no project_description.txt)"
    mgr = read_text(PROMPTS["manager"]) or ""
    if STRICT_CODEPORI:
        desc = (
            "Build ONLY the CodePori driver pipeline: plan → generate → repair → lint → test → finalize.\n"
            "Do NOT design or implement application/domain/UI code. All outputs must be driver code, repo scaffolding under ./output/code, "
            "and tests for the driver. Avoid app-specific modules."
        )
        mgr = (mgr + "\n" if mgr else "") + "Hard rule: stay in CodePori driver scope."
    required_shape = {
        "architecture": ["..."],
        "files": [{"path": "src/module.py", "purpose": "..."}],
        "tests": [{"path": "tests/test_something.py", "purpose": "..."}],
        "notes": "...",
    }
    base_prompt = "\n".join(
        [
            "MANAGER for a code-generation driver.",
            "\nProject description:\n" + desc,
            "\nManager directives:\n" + mgr,
            "\nReturn ONLY a JSON object with keys: architecture (list), files (list), tests (list), notes (string).",
            "No markdown fences, no prose outside JSON.",
            json.dumps(required_shape, indent=2),
        ]
    )
    text = llm.ask(base_prompt)
    if not text:
        raise RuntimeError("plan: empty response")
    log("=== RAW PLAN RESPONSE ===")
    log(text[:1200] + ("\n... (truncated)" if len(text) > 1200 else ""))
    log("=== END RAW PLAN ===")

    for _ in range(3):
        try:
            plan = parse_json_best(text, want=dict, require_code=False, dump_dir=OUT_DIR / "llm_raw" / "plan", tag="plan")
            if not isinstance(plan.get("files", []), list):
                raise ValueError("files not a list")
            if not isinstance(plan.get("tests", []), list):
                raise ValueError("tests not a list")
            log("=== PARSED PLAN ===")
            log(json.dumps(plan, indent=2)[:1200])
            log("=== END PARSED PLAN ===")
            return plan
        except Exception as e:
            log(f"Plan parse error: {e}; requesting strict reissue (retry)")
            text = llm.ask("Return ONLY valid JSON with keys architecture, files, tests, notes. No fences, no prose.")
            if not text:
                break
    raise RuntimeError("plan: could not parse JSON after retries")

def _dev_prompt_for_file(file_item: Dict[str, Any], plan_paths: Sequence[str]) -> str:
    dev1 = read_text(PROMPTS["dev1"]) or ""
    dev2 = read_text(PROMPTS["dev2"]) or ""
    target = str(file_item["path"]).strip()
    ext = pathlib.Path(target).suffix.lower()
    expected_lang = "python" if ext == ".py" else "text"
    schema = {"language": expected_lang, "code": "<FULL FILE CONTENT HERE>"}
    rules = [
        "SENIOR DEVELOPER — produce a COMPLETE file as JSON only.",
        "Scope rule: driver/scaffolding code only (no app/domain/UI).",
        dev1, dev2,
        f"Target path: {target}",
        f"Purpose: {file_item.get('purpose','')}\n",
        "Return ONLY JSON with keys {\"language\", \"code\"}.",
        "The 'code' field MUST contain the full source for this file.",
        "No markdown, no fences, no commentary.",
    ]
    if ext == ".py":
        rules += ["- Imports MUST be absolute from the repo root package (e.g., 'src.'), never relative."]
    else:
        rules += ["- Not a Python file; return raw text in 'code' and set language='text'."]
    rules.append(json.dumps(schema, indent=2))
    return "\n".join([r for r in rules if r])

def _test_prompt_for_file(test_item: Dict[str, Any], plan_paths: Sequence[str]) -> str:
    verify = read_text(PROMPTS["verify"]) or ""
    schema = {"language": "python", "code": "<FULL PYTEST FILE CONTENT HERE>"}
    return "\n".join(
        [
            "TEST ENGINEER — produce a COMPLETE pytest file as JSON only.",
            "Scope rule: tests target the driver or generic shims; avoid app/domain specifics.",
            verify,
            f"Target path: {test_item['path']}",
            f"Purpose: {test_item.get('purpose','')}\n",
            "Return ONLY JSON with {\"language\", \"code\"}.",
            "The 'code' field MUST be the full pytest file.",
            "Use absolute imports from repo root (e.g., 'src.module').",
            json.dumps(schema, indent=2),
        ]
    )

# ---------------------- GENERATION ----------------------
def _json_retry(llm: ProxyGemini, prompt: str, *, require_code: bool, dump_dir: Optional[pathlib.Path], tag: str) -> Dict[str, Any]:
    last_err: Optional[str] = None
    for i in range(JSON_RETRIES):
        txt = llm.ask(prompt)
        if not txt:
            last_err = "empty response from LLM"
            log(f"  -> LLM returned empty response; re-prompt ({i+1}/{JSON_RETRIES})")
            continue
        try:
            payload = parse_json_best(txt, want=dict, require_code=require_code, dump_dir=dump_dir, tag=f"{tag}_{i}")
            code = str(payload.get("code", ""))
            if require_code and not code.strip():
                last_err = "code field empty"
                log(f"  -> Code payload empty; re-prompt ({i+1}/{JSON_RETRIES})")
                continue
            return payload
        except Exception as e:
            last_err = str(e)
            log(f"  -> JSON invalid ({last_err}); re-prompt ({i+1}/{JSON_RETRIES})")
    raise ValueError(last_err or "no parse")

def generate_single_file_with_repair(llm: ProxyGemini, fitem: Dict[str, Any], plan_paths: Sequence[str]) -> None:
    rel = fitem["path"].strip().lstrip("/\\")
    target = CODE_DIR / rel
    ext = target.suffix.lower()
    is_python = (ext == ".py")
    tag = rel.replace("/", "_")

    original_prompt = _dev_prompt_for_file(fitem, plan_paths)
    payload = _json_retry(llm, original_prompt, require_code=True, dump_dir=OUT_DIR / "llm_raw" / "files", tag=tag)
    code = str(payload.get("code", ""))

    try:
        if is_python:
            write_python_file(target, code)
        else:
            write_text(target, code)
        log(f"WROTE {target}")
        return
    except Exception as e:
        log(f"[UNIVERSAL] Pre-write error for {rel}; reprompting fix: {type(e).__name__}: {e}")
        repair_prompt = _build_repair_prompt(original_prompt, path=rel, language=("python" if is_python else "text"), error=e, last_code=code)
        payload2 = _json_retry(llm, repair_prompt, require_code=True, dump_dir=OUT_DIR / "llm_raw" / "repairs", tag=f"repair_{tag}")
        code2 = str(payload2.get("code", ""))
        if is_python:
            write_python_file(target, code2)
        else:
            write_text(target, code2)
        log(f"WROTE (after repair) {target}")

def step_generate(plan: Dict[str, Any], llm: ProxyGemini) -> None:
    files = plan.get("files", [])
    tests = plan.get("tests", [])
    log(f"Generating {len(files)} code files and {len(tests)} test files")
    plan_paths = [f.get("path", "") for f in files]

    for i, fitem in enumerate(files, 1):
        rel = fitem["path"].strip().lstrip("/\\")
        log(f"Generating code file {i}/{len(files)}: {rel}")
        generate_single_file_with_repair(llm, fitem, plan_paths)

    for i, titem in enumerate(tests, 1):
        rel = titem["path"].strip().lstrip("/\\")
        target = CODE_DIR / rel
        log(f"Generating test file {i}/{len(tests)}: {rel}")
        payload = _json_retry(
            llm,
            _test_prompt_for_file(titem, plan_paths),
            require_code=True,
            dump_dir=OUT_DIR / "llm_raw" / "tests",
            tag=rel.replace("/", "_"),
        )
        code = str(payload.get("code", ""))
        write_python_file(target, code)
        log(f"WROTE {target}")

def _build_repair_prompt(original_prompt: str, *, path: str, language: str, error: BaseException, last_code: str) -> str:
    err_type = type(error).__name__
    err_msg = str(error)
    details = ""
    if isinstance(error, SyntaxError):
        se: SyntaxError = error  # type: ignore
        details = f"\n# SyntaxError details\nline={getattr(se, 'lineno', None)} col={getattr(se, 'offset', None)}\ntext={getattr(se, 'text', '') or ''}"
    snippet = last_code[:4000]
    return "\n".join([
        "Previous attempt failed; produce a corrected FULL file.",
        f"Target path: {path}",
        f"Language: {language}",
        f"Failure: {err_type}: {err_msg}",
        details,
        "Return ONLY JSON with keys {\"language\", \"code\"}. No fences, no prose.",
        "--- BEGIN PRIOR ATTEMPT ---",
        snippet,
        "--- END PRIOR ATTEMPT ---",
        original_prompt,
    ])

# ---------------------- SYNTAX & PACKAGING ----------------------
def _collect_python_files(root: pathlib.Path) -> List[pathlib.Path]:
    return [p for p in root.rglob("*.py") if p.is_file()]

def syntax_gate(root: pathlib.Path) -> None:
    errors: List[str] = []
    for py in _collect_python_files(root):
        try:
            src = py.read_text(encoding="utf-8")
            compile(src, str(py), "exec")
        except SyntaxError as e:
            bad = (e.text or "").rstrip("\n")
            errors.append(f"{py.relative_to(root)}: SyntaxError {e.msg} at {e.lineno}:{e.offset} -> {bad}")
        except Exception as e:
            errors.append(f"{py.relative_to(root)}: read/compile error: {e}")
    if errors:
        log("Syntax gate failed:")
        for e in errors:
            log("  - " + e)
        raise SystemExit(2)
    log("Syntax gate: clean.")

def normalize_packages(root_pkg: str = "src") -> None:
    root = CODE_DIR / root_pkg
    if not root.exists():
        return
    for py in root.rglob("*.py"):
        d = py.parent
        while True:
            init = d / "__init__.py"
            if not init.exists():
                init.write_text("# auto-added by CodePori\n", encoding="utf-8")
            if d == root:
                break
            d = d.parent
    log(f"Normalized packages under {root_pkg}/ (added __init__.py where missing).")

# ---------------------- IMPORT LINT / FIX ----------------------
ImportSpec = Tuple[str, Tuple[str, ...]]  # (module, (symbols,))

def _module_to_relpath(mod: str) -> pathlib.Path:
    return pathlib.Path(*mod.split(".")).with_suffix(".py")

def _discover_test_imports(test_path: pathlib.Path) -> List[ImportSpec]:
    text = read_text(test_path, "")
    if not text:
        return []
    try:
        tree = ast.parse(text)
    except Exception:
        return []
    specs: List[ImportSpec] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module:
            names = tuple(n.name for n in node.names if isinstance(n, ast.alias))
            specs.append((node.module, names))
        elif isinstance(node, ast.Import):
            for n in node.names:
                specs.append((n.name, ()))
    return specs

def _gather_all_test_imports(code_root: pathlib.Path) -> List[Tuple[pathlib.Path, ImportSpec]]:
    out: List[Tuple[pathlib.Path, ImportSpec]] = []
    tests_dir = code_root / "tests"
    if not tests_dir.exists():
        return out
    for test in tests_dir.rglob("test_*.py"):
        for spec in _discover_test_imports(test):
            out.append((test, spec))
    return out

def _try_import(mod: str) -> Tuple[bool, Optional[str]]:
    try:
        sys.path.insert(0, str(CODE_DIR))
        importlib.invalidate_caches()
        importlib.import_module(mod)
        return True, None
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"
    finally:
        if sys.path and sys.path[0] == str(CODE_DIR):
            sys.path.pop(0)

def _module_symbols(mod: str) -> Set[str]:
    try:
        sys.path.insert(0, str(CODE_DIR))
        importlib.invalidate_caches()
        m = importlib.import_module(mod)
        return set(dir(m))
    except Exception:
        return set()
    finally:
        if sys.path and sys.path[0] == str(CODE_DIR):
            sys.path.pop(0)

def lint_imports_and_symbols(code_root: pathlib.Path) -> Tuple[Set[str], Dict[str, Set[str]], Dict[str, str]]:
    missing_modules: Set[str] = set()
    missing_symbols: Dict[str, Set[str]] = {}
    broken_modules: Dict[str, str] = {}
    for _test_file, (mod, names) in _gather_all_test_imports(code_root):
        ok, err = _try_import(mod)
        if not ok:
            target = code_root / _module_to_relpath(mod)
            if target.exists():
                broken_modules[mod] = err or "ImportError"
            else:
                missing_modules.add(mod)
            continue
        if names:
            present = _module_symbols(mod)
            needed = set(names) - present
            if needed:
                missing_symbols.setdefault(mod, set()).update(needed)
    return missing_modules, missing_symbols, broken_modules

def _autofix_relative_imports(mod: str) -> bool:
    if not AUTOFIX_RELATIVE:
        return False
    target = CODE_DIR / pathlib.Path(*mod.split(".")).with_suffix(".py")
    if not target.exists():
        return False
    code = read_text(target, "")
    if not code:
        return False
    rel_parts = pathlib.Path(*mod.split(".")).with_suffix("").parts
    changed = False

    def replacer(match: re.Match[str]) -> str:
        nonlocal changed
        dots = match.group(1)
        rest = match.group(2)
        import_tail = match.group(3)
        level = len(dots)
        up = level - 1
        base = list(rel_parts)
        while up > 0 and len(base) > 1:
            base.pop()
            up -= 1
        if len(base) == 1:
            base = ["src"]
        abs_mod = ".".join(base + ([p for p in rest.split(".") if p] if rest else []))
        changed = True
        return f"from {abs_mod} import {import_tail}"

    new_code = re.sub(r"^\s*from\s+(\.+)([A-Za-z0-9_\.]*)\s+import\s+(.+)$", replacer, code, flags=re.MULTILINE)
    if changed and new_code != code:
        write_python_file(target, new_code)
        log(f"Auto-fixed relative imports in {safe_relpath(target)} -> absolute")
        return True
    return False

def _autofix_bad_config_imports() -> None:
    for py in CODE_DIR.rglob("*.py"):
        code = read_text(py, "")
        if not code:
            continue
        new = code
        new = re.sub(r"^\s*from\s+src\.config\s+import\s+config\s*$", "import src.config as config", new, flags=re.MULTILINE)
        new = re.sub(r"^\s*import\s+src\.config\.config\s*$", "import src.config as config", new, flags=re.MULTILINE)
        if new != code:
            write_python_file(py, new)
            log(f"Auto-fixed config imports in {safe_relpath(py)}")

# ---------------------- GENERIC TEST-DRIVEN CONTRACT ADAPTERS ----------------------
class _RequiredCtor:
    def __init__(self) -> None:
        self.kw_names: Set[str] = set()
        self.seen_positional: bool = False

def _discover_required_constructors() -> Dict[str, Dict[str, _RequiredCtor]]:
    """
    Returns: { module_name: { class_name: _RequiredCtor(...) } }
    Only for imports under 'src.' and calls found in tests.
    """
    tests_dir = CODE_DIR / "tests"
    result: Dict[str, Dict[str, _RequiredCtor]] = {}

    if not tests_dir.exists():
        return result

    for test in tests_dir.rglob("test_*.py"):
        try:
            txt = read_text(test, "")
            tree = ast.parse(txt)
        except Exception:
            continue

        from_alias: Dict[str, Tuple[str, str]] = {}
        module_alias: Dict[str, str] = {}

        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom) and node.module:
                mod = node.module
                for alias in node.names:
                    local = alias.asname or alias.name
                    from_alias[local] = (mod, alias.name)
            elif isinstance(node, ast.Import):
                for alias in node.names:
                    mod = alias.name
                    local = alias.asname or alias.name.split(".")[-1]
                    module_alias[local] = mod

        for node in ast.walk(tree):
            if not isinstance(node, ast.Call):
                continue
            mod: Optional[str] = None
            cls: Optional[str] = None

            if isinstance(node.func, ast.Name):
                name = node.func.id
                if name in from_alias:
                    mod, cls = from_alias[name]
            elif isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name):
                base = node.func.value.id
                attr = node.func.attr
                if base in module_alias:
                    mod = module_alias[base]
                    cls = attr

            if not mod or not cls:
                continue
            if not mod.startswith("src."):
                continue

            ctor = result.setdefault(mod, {}).setdefault(cls, _RequiredCtor())
            if node.args:
                ctor.seen_positional = True
            for kw in node.keywords or []:
                if kw.arg:
                    ctor.kw_names.add(kw.arg)

    return result

def _write_generic_adapter(module_name: str, class_name: str, ctor: _RequiredCtor) -> None:
    path = CODE_DIR / _module_to_relpath(module_name)
    base = module_name.split(".")[-1]
    kw_list = sorted(ctor.kw_names)
    kw_params = ", ".join(f"{k}: object = None" for k in kw_list)
    kw_unpack = ", ".join(f"{k}={k}" for k in kw_list)
    accepts_pos = "*args, " if ctor.seen_positional else ""
    code = f'''# Auto-generated adapter for tests. Driver-scope only.
try:
    from src.core.{base} import {class_name} as _Core  # optional delegation if present
except Exception:
    _Core = object  # type: ignore

class {class_name}(_Core):  # type: ignore[misc]
    def __init__(self, {accepts_pos}{kw_params}{(", " if kw_params else "")}**kwargs):
        ok = False
        try:
            super().__init__({("*args, " if ctor.seen_positional else "")}{kw_unpack}{(", " if kw_unpack else "")}**kwargs)
            ok = True
        except TypeError:
            try:
                super().__init__({("*args, " if ctor.seen_positional else "")}**kwargs)
                ok = True
            except Exception:
                pass
        except Exception:
            pass
        self.__dict__.update({{{", ".join(repr(k)+": "+k for k in kw_list)}}})
'''
    write_python_file(path, code)
    log(f"Adapter ensured: {safe_relpath(path)}::{class_name}")

def enforce_test_based_adapters() -> None:
    req = _discover_required_constructors()
    if not req:
        return
    for mod, classes in sorted(req.items()):
        for cls, ctor in sorted(classes.items()):
            _write_generic_adapter(mod, cls, ctor)

# ---------------------- TARGETED REPROMPTS (UNTIL-CONVERGED) ----------------------
def _prompt_make_module(mod: str, sym_list: Sequence[str], plan_paths: Sequence[str]) -> str:
    schema = {"language": "python", "code": "<FULL FILE HERE>"}
    target_rel = str(_module_to_relpath(mod)).replace("\\", "/")
    dev1 = read_text(PROMPTS["dev1"]) or ""
    dev2 = read_text(PROMPTS["dev2"]) or ""
    return "\n".join(
        [
            "SENIOR DEVELOPER — create a NEW Python module as JSON only.",
            "Scope: driver/shim only; no app/domain.",
            dev1, dev2,
            f"Target path (relative to repo root): {target_rel}",
            "This module is imported by tests and must exist.",
            f"Define these top-level names: {list(sym_list)}",
            "Imports MUST be absolute from 'src.'; never relative.",
            "Return ONLY JSON with {\"language\",\"code\"}. No fences, no prose.",
            json.dumps(schema, indent=2),
        ]
    )

def _prompt_edit_module_to_add_symbols(mod: str, missing: Sequence[str], existing_code: str, plan_paths: Sequence[str]) -> str:
    schema = {"language": "python", "code": "<FULL FILE HERE>"}
    target_rel = str(_module_to_relpath(mod)).replace("\\", "/")
    verify = read_text(PROMPTS["verify"]) or ""
    return "\n".join(
        [
            "SENIOR DEVELOPER — update EXISTING file to add missing exports.",
            "Scope: driver/shim only; no app/domain.",
            verify,
            f"Target path: {target_rel}",
            f"Missing symbols to add: {list(missing)}",
            "Return ONLY JSON with {\"language\",\"code\"}. No markdown/prose.",
            "Keep existing behavior; add minimal correct definitions for missing names.",
            "Use absolute imports from repo root ('src.').",
            "If a missing symbol matches a stdlib module name (e.g. subprocess), add a proper 'import <name>' at module top rather than a dummy value.",
            json.dumps(schema, indent=2),
            "\n--- BEGIN EXISTING FILE ---\n" + existing_code + "\n--- END EXISTING FILE ---\n",
        ]
    )

def _gap_signature(missing_mods: Set[str], missing_syms: Dict[str, Set[str]], broken_mods: Dict[str, str]) -> str:
    a = tuple(sorted(missing_mods))
    b = tuple(sorted((k, tuple(sorted(v))) for k, v in sorted(missing_syms.items())))
    c = tuple(sorted((k, v or "") for k, v in sorted(broken_mods.items())))
    return json.dumps({"missing": a, "symbols": b, "broken": c})

def targeted_reprompts_until_converged(plan: Dict[str, Any], llm: ProxyGemini) -> None:
    if not ENABLE_LINTER:
        log("Universal linter/reprompts disabled.")
        return

    plan_paths = [f.get("path", "") for f in plan.get("files", [])]
    llm_calls = 0
    start = time.time()
    thrash = 0
    last_sig = None
    passes = 0

    while True:
        passes += 1
        if passes > LINTER_PASS_CAP:
            log("Universal linter: reached absolute pass cap; continuing.")
            break

        log(f"Universal linter pass {passes} (budget: {LLM_CALL_BUDGET-llm_calls} llm-calls left, {int(LINTER_TIME_BUDGET-(time.time()-start))}s left)...")
        missing_mods, missing_syms, broken_mods = lint_imports_and_symbols(CODE_DIR)

        # Safety: never mutate src/__init__.py and never synthesize third-party modules
        missing_mods_src = {m for m in missing_mods if m.startswith("src.")}
        missing_mods_3p = sorted(missing_mods - missing_mods_src)
        if missing_mods_3p:
            log(f"Skipping non-src missing modules (not synthesized): {missing_mods_3p}")

        # Attempt quick auto-fixes for relative imports on broken src.* modules
        for mod, err in sorted(broken_mods.items()):
            if mod.startswith("src.") and "relative import" in (err or "").lower():
                if _autofix_relative_imports(mod):
                    ok, err2 = _try_import(mod)
                    if ok:
                        log(f"Auto-fix successful for {mod}")
                        broken_mods.pop(mod, None)

        # Make/repair src modules first
        # A) Create missing src modules (if any)
        for mod in sorted(missing_mods_src):
            if llm_calls >= LLM_CALL_BUDGET:
                break
            expected: Set[str] = set()
            for _t, (m, names) in _gather_all_test_imports(CODE_DIR):
                if m == mod and names:
                    expected.update(names)
            prompt = _prompt_make_module(mod, sorted(expected), plan_paths)
            try:
                payload = _json_retry(llm, prompt, require_code=True, dump_dir=OUT_DIR / "llm_raw" / "reprompts", tag=f"missing_{mod.replace('.', '_')}")
                llm_calls += 1
                code = str(payload.get("code", ""))
                if not code.strip():
                    raise ValueError("empty code")
                target = CODE_DIR / _module_to_relpath(mod)
                # Guard: don't create "src.py"
                if target.name == "src.py" and NO_MUTATE_SRC_INIT:
                    log("Skip write to src.py (would collide with package); ignoring.")
                else:
                    write_python_file(target, code)
                    log(f"WROTE (missing module) {safe_relpath(target)}")
            except Exception as e:
                log(f"Targeted reprompt (module {mod}) failed: {e}")

        # B) Add missing symbols to src modules
        for mod, symset in sorted(missing_syms.items()):
            if not mod.startswith("src."):
                continue
            target = CODE_DIR / _module_to_relpath(mod)
            if target.name == "__init__.py" and NO_MUTATE_SRC_INIT:
                log(f"Skip symbol edits in {safe_relpath(target)} (guard).")
                continue
            existing = read_text(target, "")
            if not existing:
                continue
            if llm_calls >= LLM_CALL_BUDGET:
                break
            prompt = _prompt_edit_module_to_add_symbols(mod, sorted(symset), existing, plan_paths)
            try:
                payload = _json_retry(llm, prompt, require_code=True, dump_dir=OUT_DIR / "llm_raw" / "reprompts", tag=f"addsyms_{mod.replace('.', '_')}")
                llm_calls += 1
                code = str(payload.get("code", ""))
                if not code.strip():
                    raise ValueError("empty code")
                write_python_file(target, code)
                log(f"WROTE (added symbols) {safe_relpath(target)}")
            except Exception as e:
                log(f"Targeted reprompt (symbols {mod}) failed: {e}")

        normalize_packages("src")
        try:
            enforce_test_based_adapters()
        except Exception as e:
            log(f"Contract enforcement warning: {e}")

        # Recompute gaps
        missing_mods2, missing_syms2, broken_mods2 = lint_imports_and_symbols(CODE_DIR)
        sig = _gap_signature(missing_mods2, missing_syms2, broken_mods2)
        if not missing_mods2 and not missing_syms2 and not broken_mods2:
            log("Universal linter: all modules/symbols satisfied.")
            return

        # Thrash detection
        if sig == last_sig:
            thrash += 1
            log(f"Universal linter: no change in gaps (thrash {thrash}/{LINTER_THRASH_LIMIT}).")
        else:
            thrash = 0
        last_sig = sig

        # Budgets
        if (time.time() - start) > LINTER_TIME_BUDGET:
            log("Universal linter: time budget exhausted; continuing.")
            break
        if llm_calls >= LLM_CALL_BUDGET:
            log("Universal linter: LLM call budget exhausted; continuing.")
            break
        if thrash >= LINTER_THRASH_LIMIT:
            log("Universal linter: thrash limit reached; continuing.")
            break

    log("Universal linter: exited (budget/limit). Proceeding to tests.")

# ---------------------- FINALIZER ----------------------
def step_finalize(llm: ProxyGemini) -> None:
    final1 = read_text(PROMPTS["final1"]) or ""
    final2 = read_text(PROMPTS["final2"]) or ""
    schema = {"readme": "# Project...", "requirements": "pytest\nrequests\nmarkdown-it-py\n"}
    prompt = "\n".join(
        [
            "FINALIZER.",
            "Scope: driver-only README; no app instructions.",
            final1, final2,
            "Return ONLY JSON with keys {\"readme\", \"requirements\"}. No fences, no prose.",
            json.dumps(schema, indent=2),
        ]
    )
    txt = llm.ask(prompt) or ""
    try:
        obj = parse_json_best(txt, want=dict, require_code=False, dump_dir=OUT_DIR / "llm_raw" / "finalizer", tag="final")
    except Exception:
        obj = {}
    readme = str(obj.get("readme", "# Project\n\n(README not returned as JSON.)\n"))
    reqs = str(obj.get("requirements", "pytest\nrequests\nmarkdown-it-py\n"))
    write_text(CODE_DIR / "README.md", readme)
    write_text(CODE_DIR / "requirements.txt", reqs)

# ---------------------- PYTEST (plugin-aware, coverage-aware) ----------------------
def _tests_need_fixture(name: str) -> bool:
    tests_dir = CODE_DIR / "tests"
    if not tests_dir.exists():
        return False
    pattern = re.compile(rf"\b{name}\b")
    for p in tests_dir.rglob("test_*.py"):
        try:
            txt = p.read_text(encoding="utf-8", errors="ignore")
            if pattern.search(txt):
                return True
        except Exception:
            pass
    return False

def _pyproject_requests_coverage() -> bool:
    pyproject = CODE_DIR / "pyproject.toml"
    if not (tomllib and pyproject.exists()):
        return False
    try:
        data = tomllib.loads(pyproject.read_text(encoding="utf-8"))
        addopts = (((data.get("tool") or {}).get("pytest") or {}).get("ini_options") or {}).get("addopts", "")
        if isinstance(addopts, str):
            return "--cov" in addopts
        if isinstance(addopts, list):
            return any("--cov" in str(x) for x in addopts)
        return False
    except Exception:
        return False

def _pip_install(pkgs: List[str]) -> None:
    if not pkgs:
        return
    log(f"Installing packages (best-effort): {', '.join(pkgs)}")
    try:
        subprocess.run([sys.executable, "-m", "pip", "install", *pkgs], check=False)
    except Exception as e:
        log(f"pip install failed (continuing): {e}")

def ensure_pytest_plugins_installed() -> List[str]:
    needed: List[str] = []
    if _tests_need_fixture("mocker"):
        needed.append("pytest-mock")
    if _tests_need_fixture("fs"):
        needed.append("pyfakefs")
    # Coverage plugin if pyproject requires --cov
    if _pyproject_requests_coverage():
        needed.append("pytest-cov")
    if not needed:
        return []
    _pip_install(needed)
    return needed

def ensure_test_deps_installed() -> None:
    """Install a tiny allowlist of deps if tests import them."""
    to_install: Set[str] = set()
    for _test, (mod, _names) in _gather_all_test_imports(CODE_DIR):
        for spec in TEST_DEP_ALLOWLIST.values():
            for imp in spec["import_names"]:
                if mod.split(".")[0] == imp:
                    to_install.add(spec["pip"])
    if to_install:
        _pip_install(sorted(to_install))

def _is_plugin_import_crash(pytest_output: str) -> bool:
    if "load_setuptools_entrypoints(\"pytest11\")" in pytest_output:
        return True
    if "pytest_flask" in pytest_output and "ImportError" in pytest_output:
        return True
    return False

def _build_safe_plugin_args(autoload_off: bool) -> List[str]:
    # Always safeload known-safe plugins when autoload is OFF, so fixtures like `fs` are present.
    args: List[str] = []
    args += ["-p", "pytest_mock"]
    args += ["-p", "pyfakefs"]
    if autoload_off and _pyproject_requests_coverage():
        args += ["-p", "pytest_cov"]
    return args

def run_pytest_once(autoload: bool, extra_args: Optional[List[str]] = None) -> Tuple[int, str]:
    env = dict(os.environ)
    if autoload:
        env.pop("PYTEST_DISABLE_PLUGIN_AUTOLOAD", None)
    else:
        env["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"

    val = env.get("PYTEST_DISABLE_PLUGIN_AUTOLOAD")
    log(f"PYTEST_DISABLE_PLUGIN_AUTOLOAD={val if val is not None else 'None'} (autoload={'ON' if autoload else 'OFF'})")

    cmd = [sys.executable, "-m", "pytest", "-q"]
    if extra_args:
        cmd += extra_args

    proc = subprocess.run(cmd, cwd=str(CODE_DIR), env=env, capture_output=True, text=True)
    out = (proc.stdout or "") + "\n" + (proc.stderr or "")
    for line in out.splitlines()[:400]:
        log(line)
    LOG_FILE.write_text(read_text(LOG_FILE) + "\n=== PYTEST FULL OUTPUT ===\n" + out, encoding="utf-8")
    return proc.returncode, out

def run_pytest_plugin_aware() -> Tuple[int, str]:
    ensure_test_deps_installed()
    ensure_pytest_plugins_installed()
    rc, out = run_pytest_once(autoload=True, extra_args=None)
    if rc == 0:
        return rc, out
    if _is_plugin_import_crash(out):
        log("Detected plugin import crash; retrying with autoload OFF and safelisted plugins only.")
        safe_args = _build_safe_plugin_args(autoload_off=True)
        rc2, out2 = run_pytest_once(autoload=False, extra_args=safe_args)
        return rc2, out2
    return rc, out

# ---- Pytest >= 8 guard (authorized)
def ensure_pytest_ok() -> None:
    try:
        import pytest  # type: ignore
        ver = getattr(pytest, "__version__", "0.0.0")
        major = int(ver.split(".")[0])
        if major >= 8:
            log(f"Pytest already OK: {ver} >= 8.0")
            return
        log(f"Upgrading pytest (current {ver})...")
    except Exception:
        log("Installing pytest>=8...")
    try:
        subprocess.run([sys.executable, "-m", "pip", "install", "-U", "pytest>=8,<9"], check=False)
    except Exception as e:
        log(f"pytest install/upgrade failed (continuing): {e}")

# ---------------------- PYTEST + REPAIR ----------------------
_MNF_RE = re.compile(r"ModuleNotFoundError:\s+No module named '([^']+)'")
_CANNOT_IMPORT_RE = re.compile(r"cannot import name '([^']+)' from '([^']+)'")
# NEW: catch AttributeError for missing attributes on modules (e.g., 'src.stages.lint.subprocess')
_ATTR_MISSING_RE = re.compile(r"AttributeError: module '([^']+)' has no attribute '([^']+)'")

def _ensure_stdlib_attr_alias(mod: str, attr: str) -> bool:
    """If tests patch e.g. 'src.stages.lint.subprocess', ensure the module exposes that name."""
    if not mod.startswith("src."):
        return False
    target = CODE_DIR / _module_to_relpath(mod)
    code = read_text(target, "")
    if not code:
        return False
    # already imported?
    if re.search(rf"^\s*import\s+{re.escape(attr)}\b", code, flags=re.MULTILINE):
        return False
    # Prepend a safe import
    new_code = f"import {attr}\n" + code
    try:
        write_python_file(target, new_code)
        log(f"Inserted 'import {attr}' into {safe_relpath(target)}")
        return True
    except Exception as e:
        log(f"Failed to insert stdlib import '{attr}' into {safe_relpath(target)}: {e}")
        return False

def run_pytest_and_maybe_repair(plan: Dict[str, Any], llm: ProxyGemini) -> int:
    # Ensure pytest is new enough to satisfy any pyproject minversion.
    ensure_pytest_ok()

    req = CODE_DIR / "requirements.txt"
    if req.exists():
        log("Installing requirements (best-effort)...")
        try:
            subprocess.run([sys.executable, "-m", "pip", "install", "-r", str(req)], check=False)
        except Exception as e:
            log(f"pip install failed (continuing): {e}")

    _autofix_bad_config_imports()
    normalize_packages("src")

    try:
        enforce_test_based_adapters()
    except Exception as e:
        log(f"Adapter enforcement warning: {e}")

    rc, pout = run_pytest_plugin_aware()
    if rc == 0:
        log("✅ Tests passed.")
        return 0

    # Parse common import/name/attribute errors
    mm = set(m.group(1) for m in _MNF_RE.finditer(pout))
    ms_pairs = list(_CANNOT_IMPORT_RE.finditer(pout))
    missing_symbols: Dict[str, Set[str]] = {}
    for m in ms_pairs:
        sym = m.group(1); mod = m.group(2)
        missing_symbols.setdefault(mod, set()).add(sym)

    # NEW: capture AttributeError about missing attributes (e.g., 'subprocess')
    attr_pairs = _ATTR_MISSING_RE.findall(pout)
    for mod, attr in attr_pairs:
        if mod.startswith("src."):
            # opportunistic deterministic fix for stdlib modules (like 'subprocess')
            if attr in {"subprocess"}:
                _ensure_stdlib_attr_alias(mod, attr)
            missing_symbols.setdefault(mod, set()).add(attr)

    # Only repair src.* modules here; skip any third-party like 'respx'
    if (mm or missing_symbols) and ENABLE_LINTER:
        log("Detected pytest import/name errors. Attempting targeted repair (src.* only)...")
        plan_paths = [f.get("path", "") for f in plan.get("files", [])]

        for mod in sorted(mm):
            if not mod.startswith("src."):
                log(f"Skip synthesizing non-src module {mod}")
                continue
            target = CODE_DIR / _module_to_relpath(mod)
            if target.exists():
                if _autofix_relative_imports(mod):
                    ok, err2 = _try_import(mod)
                    if ok:
                        log(f"Auto-fix successful for {mod}")
                        continue
                    else:
                        log(f"Auto-fix attempted for {mod} but still failing: {err2}")
            expected: Set[str] = set()
            for _t, (m, names) in _gather_all_test_imports(CODE_DIR):
                if m == mod and names:
                    expected.update(names)
            try:
                payload = _json_retry(llm, _prompt_make_module(mod, sorted(expected), plan_paths), require_code=True, dump_dir=OUT_DIR / "llm_raw" / "reprompts", tag=f"pytest_module_{mod.replace('.', '_')}")
                code = str(payload.get("code", ""))
                if not code.strip():
                    raise ValueError("empty code")
                write_python_file(target, code)
                log(f"WROTE (pytest-module) {safe_relpath(target)}")
            except Exception as e:
                log(f"pytest-module repair failed for {mod}: {e}")

        for mod, syms in sorted(missing_symbols.items()):
            if not mod.startswith("src."):
                continue
            target = CODE_DIR / _module_to_relpath(mod)
            if target.name == "__init__.py" and NO_MUTATE_SRC_INIT:
                log(f"Skip symbol edits in {safe_relpath(target)} (guard).")
                continue
            existing = read_text(target, "")
            if not existing:
                continue
            try:
                payload = _json_retry(llm, _prompt_edit_module_to_add_symbols(mod, sorted(syms), existing, plan_paths), require_code=True, dump_dir=OUT_DIR / "llm_raw" / "reprompts", tag=f"pytest_symbols_{mod.replace('.', '_')}")
                code = str(payload.get("code", ""))
                if not code.strip():
                    raise ValueError("empty code")
                write_python_file(target, code)
                log(f"WROTE (pytest-symbols) {safe_relpath(target)}")
            except Exception as e:
                log(f"pytest-symbols repair failed for {mod}: {e}")

        normalize_packages("src")
        try:
            enforce_test_based_adapters()
        except Exception as e:
            log(f"Adapter enforcement warning: {e}")

        syntax_gate(CODE_DIR)
        rc2, pout2 = run_pytest_plugin_aware()
        if rc2 == 0:
            log("✅ Tests passed after targeted repair.")
            return 0
        else:
            log("❌ Tests still failing after targeted repair. See logs above.")
            return 1

    log("❌ Tests failed. See pytest output above and ./output/run.log")
    return 1

# ---------------------- HEALTHCHECK ----------------------
def proxy_healthcheck() -> None:
    try:
        r = requests.get(f"{PROXY_BASE}/health", timeout=10)
        if r.ok:
            data = r.json()
            log(
                "Proxy health: "
                f"status={data.get('status')} "
                f"valid_keys={data.get('valid_keys') or data.get('total_keys')} "
                f"cooldown={data.get('cooldown') or data.get('cooldown_keys')} "
                f"exhausted={data.get('exhausted') or data.get('exhausted_keys_per_model')}"
            )
        else:
            log(f"Warning: /health HTTP {r.status_code}")
    except Exception as e:
        log(f"Warning: could not reach proxy /health: {e}")

# ---------------------- MAIN ----------------------
def main() -> int:
    try:
        snapshot_previous()
        ensure_dirs()
        LOG_FILE.write_text("", encoding="utf-8")
        log("Starting CodePori (Proxy/Gemini) pipeline...")
        log(f"Proxy base: {PROXY_BASE}")
        log(f"Primary model: {PRIMARY_MODEL} | Fallback: {FALLBACK_MODEL}")
        proxy_healthcheck()

        llm = ProxyGemini(PROXY_BASE, PRIMARY_MODEL, FALLBACK_MODEL)

        plan = step_plan(llm)
        log("Generated plan.")

        step_generate(plan, llm)
        log("Generated files.")

        syntax_gate(CODE_DIR)
        normalize_packages("src")

        # Adapters before linter/reprompts
        enforce_test_based_adapters()

        targeted_reprompts_until_converged(plan, llm)

        step_finalize(llm)
        log("Finalized repo.")

        write_diff_report()
        log_diff_report_contents()

        rc = run_pytest_and_maybe_repair(plan, llm)
        if rc == 0:
            log("DONE: output in ./output/code")
            return 0
        return rc

    except SystemExit as e:
        return int(e.code)
    except Exception as e:
        log(f"FATAL: {e}\n{traceback.format_exc()}")
        return 2

if __name__ == "__main__":
    sys.exit(main())
