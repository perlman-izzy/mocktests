import pytest
from unittest.mock import MagicMock
import tempfile
import shutil
from pathlib import Path

@pytest.fixture
def mock_llm_client():
    """
    A generic mock for an LLM client. Simulates interaction with an LLM service.
    Provides predictable responses for common methods like `chat_completion`.
    """
    mock = MagicMock()

    # Simulate a successful chat completion response
    mock.chat_completion.return_value = {
        "choices": [
            {"message": {"content": "This is a mock LLM response for chat completion."}}
        ]
    }

    # Simulate an embedding response
    mock.embed_text.return_value = [0.1, 0.2, 0.3, 0.4] # Example vector

    # Simulate a stream completion (e.g., for streaming interfaces)
    def mock_stream_response_generator():
        yield {'choices': [{'delta': {'content': 'Stream part 1'}}]}
        yield {'choices': [{'delta': {'content': 'Stream part 2'}}]}
        yield {'choices': [{'delta': {'content': 'Stream part 3'}}]}
    mock.stream_chat_completion.return_value = mock_stream_response_generator()

    return mock

@pytest.fixture
def fake_pipeline_context(mock_llm_client):
    """
    A generic fake for a pipeline context object. This represents a typical
    context passed through different stages or components.

    It includes:
    - A `config` object with generic settings.
    - A `state` object for mutable data storage.
    - A `logger` for capturing log messages during tests.
    - An `llm_client` (injected `mock_llm_client`).
    - A `resource_path` for simulating access to external resources.
    """
    class FakeConfig:
        """A simple mock for configuration settings."""
        def __init__(self):
            self.debug_mode = True
            self.timeout_seconds = 60
            self.api_key_name = "MOCK_API_KEY"

    class FakeState:
        """A simple mock for mutable state storage."""
        def __init__(self):
            self._data = {}

        def get(self, key, default=None):
            return self._data.get(key, default)

        def set(self, key, value):
            self._data[key] = value

        def __getitem__(self, key):
            return self._data[key]

        def __setitem__(self, key, value):
            self._data[key] = value

    class FakeLogger:
        """A simple logger that captures messages without printing."""
        def __init__(self):
            self.messages = []

        def debug(self, msg, *args, **kwargs): self.messages.append(('DEBUG', msg % args if args else msg))
        def info(self, msg, *args, **kwargs): self.messages.append(('INFO', msg % args if args else msg))
        def warning(self, msg, *args, **kwargs): self.messages.append(('WARNING', msg % args if args else msg))
        def error(self, msg, *args, **kwargs): self.messages.append(('ERROR', msg % args if args else msg))
        def critical(self, msg, *args, **kwargs): self.messages.append(('CRITICAL', msg % args if args else msg))
        def exception(self, msg, *args, **kwargs): self.messages.append(('EXCEPTION', msg % args if args else msg))

    context = MagicMock()
    context.config = FakeConfig()
    context.state = FakeState()
    context.logger = FakeLogger()
    context.llm_client = mock_llm_client
    # Simulate a path where external resources might be located
    context.resource_path = Path("/mock/resource/path")

    return context

@pytest.fixture
def temp_test_dir():
    """
    Creates a temporary directory for tests requiring filesystem interactions.
    The directory is automatically cleaned up after the test completes.
    """
    with tempfile.TemporaryDirectory() as tmpdir:
        temp_path = Path(tmpdir)
        yield temp_path
    # The TemporaryDirectory context manager handles cleanup automatically

@pytest.fixture
def empty_file_in_temp_dir(temp_test_dir):
    """
    Creates an empty file within the `temp_test_dir` fixture's directory.
    Returns the `Path` object to the created file.
    """
    file_path = temp_test_dir / "test_empty_file.txt"
    file_path.touch()
    return file_path

@pytest.fixture
def populated_text_file_in_temp_dir(temp_test_dir):
    """
    Creates a text file with predefined content within `temp_test_dir`.
    Returns the `Path` object to the created file.
    """
    file_path = temp_test_dir / "test_data.txt"
    content = "Line 1 of test data.\nLine 2 of test data.\nLast line." 
    file_path.write_text(content)
    return file_path

@pytest.fixture
def generic_data_payload():
    """
    Provides a generic dictionary payload, useful for testing functions
    that process arbitrary input data structures.
    """
    return {
        "id": "abcd-1234",
        "name": "Sample Item",
        "version": 1.0,
        "details": {
            "status": "active",
            "tags": ["test", "mock", "data"]
        },
        "values": [10, 20, 30, 40]
    }
