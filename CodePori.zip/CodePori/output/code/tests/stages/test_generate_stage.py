import pytest
from unittest.mock import MagicMock, call
from pathlib import Path

# Assuming a project structure where models and stages are in the 'src' directory
from src.stages.generate_stage import GenerateStage
from src.models.context import Context
from src.models.plan import Plan, FileAction
from src.llm.llm_client import LLMClient


@pytest.fixture
def mock_llm_client() -> MagicMock:
    """Provides a mock LLMClient instance."""
    client = MagicMock(spec=LLMClient)
    return client


@pytest.fixture
def generate_stage(mock_llm_client: MagicMock) -> GenerateStage:
    """Provides an instance of GenerateStage with a mock LLM client."""
    return GenerateStage(llm_client=mock_llm_client)


def test_generate_stage_creates_and_writes_files(
    generate_stage: GenerateStage,
    mock_llm_client: MagicMock,
    tmp_path: Path
):
    """
    Verify the stage generates code for 'create' actions and writes it to files,
    including creating necessary parent directories.
    """
    # Arrange
    plan = Plan(actions=[
        FileAction(path="src/app.py", action="create", prompt="Create a main app file."),
        FileAction(path="src/utils/helpers.py", action="create", prompt="Create a helper utility file.")
    ])
    context = Context(plan=plan)

    expected_code_app = "def main():\n    print('Hello, App!')"
    expected_code_helpers = "def helper_function():\n    return True"

    mock_llm_client.generate.side_effect = [
        expected_code_app,
        expected_code_helpers
    ]

    # Act
    generate_stage.run(context, base_dir=tmp_path)

    # Assert
    # Check if LLM was called correctly and in order
    assert mock_llm_client.generate.call_count == 2
    mock_llm_client.generate.assert_has_calls([
        call(prompt="Create a main app file."),
        call(prompt="Create a helper utility file.")
    ], any_order=False)

    # Check if files were created with the correct content
    file_app = tmp_path / "src" / "app.py"
    file_helpers = tmp_path / "src" / "utils" / "helpers.py"

    assert file_app.exists(), "The 'app.py' file should have been created."
    assert file_app.read_text() == expected_code_app

    assert file_helpers.exists(), "The 'helpers.py' file should have been created."
    assert file_helpers.read_text() == expected_code_helpers


def test_generate_stage_modifies_existing_file(
    generate_stage: GenerateStage,
    mock_llm_client: MagicMock,
    tmp_path: Path
):
    """
    Verify the stage correctly overwrites an existing file for a 'modify' action.
    """
    # Arrange
    existing_file_path = tmp_path / "config.py"
    existing_file_path.parent.mkdir(parents=True, exist_ok=True)
    existing_file_path.write_text("OLD_CONFIG = True")

    plan = Plan(actions=[
        FileAction(path="config.py", action="modify", prompt="Update the config.")
    ])
    context = Context(plan=plan)

    updated_code = "NEW_CONFIG = False\n# Updated by AI"
    mock_llm_client.generate.return_value = updated_code

    # Act
    generate_stage.run(context, base_dir=tmp_path)

    # Assert
    mock_llm_client.generate.assert_called_once_with(prompt="Update the config.")
    assert existing_file_path.exists()
    assert existing_file_path.read_text() == updated_code


def test_generate_stage_handles_empty_plan(
    generate_stage: GenerateStage,
    mock_llm_client: MagicMock,
    tmp_path: Path
):
    """
    Verify the stage does nothing and does not call the LLM when the plan has no actions.
    """
    # Arrange
    plan = Plan(actions=[])
    context = Context(plan=plan)

    # Act
    generate_stage.run(context, base_dir=tmp_path)

    # Assert
    mock_llm_client.generate.assert_not_called()
    assert not any(tmp_path.iterdir()), "No files should be created for an empty plan."


def test_generate_stage_skips_no_action_files(
    generate_stage: GenerateStage,
    mock_llm_client: MagicMock,
    tmp_path: Path
):
    """
    Verify the stage skips files marked with 'no_action' and processes others.
    """
    # Arrange
    plan = Plan(actions=[
        FileAction(path="README.md", action="no_action"),
        FileAction(path="main.py", action="create", prompt="Create a main entrypoint.")
    ])
    context = Context(plan=plan)

    expected_code = "if __name__ == '__main__':\n    pass"
    mock_llm_client.generate.return_value = expected_code

    # Act
    generate_stage.run(context, base_dir=tmp_path)

    # Assert
    mock_llm_client.generate.assert_called_once_with(prompt="Create a main entrypoint.")

    main_file = tmp_path / "main.py"
    readme_file = tmp_path / "README.md"

    assert main_file.exists()
    assert main_file.read_text() == expected_code
    assert not readme_file.exists(), "Files with 'no_action' should not be created."


def test_generate_stage_handles_plan_with_only_no_action(
    generate_stage: GenerateStage,
    mock_llm_client: MagicMock,
    tmp_path: Path
):
    """
    Verify the stage does nothing if the plan only contains 'no_action' items.
    """
    # Arrange
    plan = Plan(actions=[
        FileAction(path="README.md", action="no_action"),
        FileAction(path="LICENSE", action="no_action")
    ])
    context = Context(plan=plan)

    # Act
    generate_stage.run(context, base_dir=tmp_path)

    # Assert
    mock_llm_client.generate.assert_not_called()
    assert not any(tmp_path.iterdir())


def test_generate_stage_propagates_llm_exception(
    generate_stage: GenerateStage,
    mock_llm_client: MagicMock,
    tmp_path: Path
):
    """
    Verify the stage propagates exceptions from the LLM client and does not create partial files.
    """
    # Arrange
    plan = Plan(actions=[
        FileAction(path="src/app.py", action="create", prompt="Create a main app file.")
    ])
    context = Context(plan=plan)

    mock_llm_client.generate.side_effect = ValueError("LLM API rate limit exceeded")

    # Act & Assert
    with pytest.raises(ValueError, match="LLM API rate limit exceeded"):
        generate_stage.run(context, base_dir=tmp_path)

    # Verify no partial files were created on failure
    assert not (tmp_path / "src" / "app.py").exists()
