"""Auto-stubbed by CodePori: original content preserved below."""

def __codepori_stub__():
    pass

RAW_CONTENT = """import pytest
from unittest.mock import patch, MagicMock
import os
import textwrap

# NOTE: For the purpose of this test file, simplified versions of PipelineContext,
# LintStage, and TestStage are defined directly. In a real project, these would
# be imported from their respective source modules, e.g.,
# from src.pipeline_context import PipelineContext
# from src.pipeline_stages import LintStage, TestStage

# --- Conceptual PipelineContext (for testing interaction) ---
class PipelineContext:
    \"\"\"Simulated pipeline context to capture stage results.\"\"\"
    def __init__(self, project_root):
        self.project_root = project_root
        self.lint_results = {}
        self.test_results = {}
        self.success = True
        self.messages = []

    def add_lint_result(self, tool, result):
        self.lint_results[tool] = result
        if not result.get("passed", True):
            self.success = False

    def add_test_result(self, tool, result):
        self.test_results[tool] = result
        if not result.get("passed", True):
            self.success = False

    def add_message(self, message):
        self.messages.append(message)

# --- Conceptual LintStage and TestStage ---
# These classes simulate the expected interface and internal calls of the actual stages.
# The `_run_command` method is designed to be patched during tests.

class LintStage:
    \"\"\"Simulated LintStage for testing purposes.\"\"\"
    def __init__(self, config=None):
        self.config = config if config is not None else {}
        self.ruff_config = self.config.get("ruff", {})
        self.mypy_config = self.config.get("mypy", {})

    def _run_command(self, command, cwd):
        \"\"\"
        This method simulates running an external command. It should be patched
        in tests to control the command's output and return code.
        \"\"\"
        raise NotImplementedError("This method must be mocked for tests.")

    def run(self, context):
        project_root = context.project_root
        lint_passed = True
        lint_details = []

        # Simulate running Ruff
        ruff_command = ["ruff", "check", "."]
        if self.ruff_config.get("fix", False):
            ruff_command.append("--fix")

        ruff_result = self._run_command(ruff_command, cwd=project_root)
        if ruff_result and ruff_result.returncode is not None:
            ruff_passed = ruff_result.returncode == 0
            lint_passed = lint_passed and ruff_passed
            lint_details.append({
                "tool": "ruff",
                "passed": ruff_passed,
                "stdout": ruff_result.stdout,
                "stderr": ruff_result.stderr,
                "returncode": ruff_result.returncode
            })
            if not ruff_passed:
                context.add_message(f"Ruff linting failed:\n{ruff_result.stderr or ruff_result.stdout}")
        else:
            lint_passed = False
            context.add_message("Ruff command not found or failed to execute (mock failure).")
            lint_details.append({"tool": "ruff", "passed": False, "error": "Command not found/mock failed"})

        # Simulate running Mypy
        mypy_command = ["mypy", "--strict", "."]
        mypy_result = self._run_command(mypy_command, cwd=project_root)
        if mypy_result and mypy_result.returncode is not None:
            mypy_passed = mypy_result.returncode == 0
            lint_passed = lint_passed and mypy_passed
            lint_details.append({
                "tool": "mypy",
                "passed": mypy_passed,
                "stdout": mypy_result.stdout,
                "stderr": mypy_result.stderr,
                "returncode": mypy_result.returncode
            })
            if not mypy_passed:
                context.add_message(f"Mypy type checking failed:\n{mypy_result.stderr or mypy_result.stdout}")
        else:
            lint_passed = False
            context.add_message("Mypy command not found or failed to execute (mock failure).")
            lint_details.append({"tool": "mypy", "passed": False, "error": "Command not found/mock failed"})

        context.add_lint_result("overall", {"passed": lint_passed, "details": lint_details})
        return lint_passed


class TestStage:
    \"\"\"Simulated TestStage for testing purposes.\"\"\"
    def __init__(self, config=None):
        self.config = config if config is not None else {}
        self.pytest_config = self.config.get("pytest", {})

    def _run_command(self, command, cwd):
        \"\"\"
        This method simulates running an external command. It should be patched
        in tests to control the command's output and return code.
        \"\"\"
        raise NotImplementedError("This method must be mocked for tests.")

    def run(self, context):
        project_root = context.project_root
        tests_passed = True
        test_details = []

        # Simulate running Pytest
        pytest_command = ["pytest"]
        if self.pytest_config.get("coverage", False):
            pytest_command.extend(["--cov=.", "--cov-report=json"])

        pytest_result = self._run_command(pytest_command, cwd=project_root)
        if pytest_result and pytest_result.returncode is not None:
            pytest_passed = pytest_result.returncode == 0
            tests_passed = tests_passed and pytest_passed
            test_details.append({
                "tool": "pytest",
                "passed": pytest_passed,
                "stdout": pytest_result.stdout,
                "stderr": pytest_result.stderr,
                "returncode": pytest_result.returncode
            })
            if not pytest_passed:
                context.add_message(f"Pytest failed:\n{pytest_result.stderr or pytest_result.stdout}")
        else:
            tests_passed = False
            context.add_message("Pytest command not found or failed to execute (mock failure).")
            test_details.append({"tool": "pytest", "passed": False, "error": "Command not found/mock failed"})

        context.add_test_result("overall", {"passed": tests_passed, "details": test_details})
        return tests_passed


class CompletedProcessMock:
    \"\"\"Helper to simulate subprocess.CompletedProcess object for mocking.\"\"\"
    def __init__(self, returncode, stdout="", stderr=""):
        self.returncode = returncode
        self.stdout = stdout
        self.stderr = stderr


# --- Fixtures ---

@pytest.fixture
def sample_project_dir(tmp_path):
    \"\"\"
    Creates a temporary directory with a sample project structure for testing.
    Includes files for linting and testing, some good, some with errors/failures.
    \"\"\"
    project_root = tmp_path / "sample_project"
    project_root.mkdir()

    # Good code and tests
    (project_root / "good_module").mkdir()
    (project_root / "good_module" / "__init__.py").touch()
    (project_root / "good_module" / "clean_code.py").write_text(textwrap.dedent(\"\"\"
        def greet(name: str) -> str:
            return f"Hello, {name}!"

        def add(a: int, b: int) -> int:
            return a + b
    ""))
    (project_root / "good_module" / "test_clean_code.py").write_text(textwrap.dedent(\"\"\"
        from good_module.clean_code import greet, add

        def test_greet():
            assert greet("World") == "Hello, World!"

        def test_add():
            assert add(1, 2) == 3
    ""))

    # Code with linting errors (Ruff/Mypy)
    (project_root / "lint_error_module").mkdir()
    (project_root / "lint_error_module" / "__init__.py").touch()
    (project_root / "lint_error_module" / "dirty_code.py").write_text(textwrap.dedent(\"\"\"
        import os, sys # F401: unused import 'sys', E702: multiple statements on one line

        def calculate (  a: int , b: int ) -> int: # E201, E202, E203, E211, E225
            x = 10; y = 20 # E702
            return a+b # E225

        def type_error(name): # Missing type hints for mypy, implicitly any
            return "Hello " + name
    ""))

    # Code with failing tests
    (project_root / "failing_test_module").mkdir()
    (project_root / "failing_test_module" / "__init__.py").touch()
    (project_root / "failing_test_module" / "bad_logic.py").write_text(textwrap.dedent(\"\"\"
        def subtract(a, b):
            return a + b # Intentional bug: should be a - b
    ""))
    (project_root / "failing_test_module" / "test_bad_logic.py").write_text(textwrap.dedent(\"\"\"
        from failing_test_module.bad_logic import subtract

        def test_subtract_failure():
            assert subtract(5, 3) == 2 # This will fail (5+3=8 != 2)
    ""))

    # pyproject.toml for tool configuration (e.g., ruff, pytest)
    (project_root / "pyproject.toml").write_text(textwrap.dedent(\"\"\"
        [tool.ruff]
        target-version = "py38"
        line-length = 88
        select = ["E", "F", "W", "I"]

        [tool.pytest.ini_options]
        pythonpath = "."
        addopts = "-ra"
    ""))

    return project_root


@pytest.fixture
def mock_subprocess_run():
    \"\"\"
    A fixture to mock the `_run_command` method of LintStage and TestStage.
    It yields a MagicMock instance that can be configured with side_effect.
    \"\"\"
    # Patch the _run_command methods within the *locally defined* classes.
    # If these classes were imported from 'src.pipeline_stages', the patch path
    # would be 'src.pipeline_stages.LintStage._run_command' etc.
    with patch("test_lint_and_test_stages.LintStage._run_command") as mock_lint_run,
         patch("test_lint_and_test_stages.TestStage._run_command") as mock_test_run:

        # Use a shared MagicMock to control both patched methods from one point
        # for convenience in these tests. Tests will set side_effect on 'shared_mock'.
        shared_mock = MagicMock()
        mock_lint_run.side_effect = shared_mock.side_effect
        mock_test_run.side_effect = shared_mock.side_effect

        yield shared_mock


# --- Tests for LintStage ---

def test_lint_stage_passes_clean_code(sample_project_dir, mock_subprocess_run):
    \"\"\"
    Verifies LintStage passes when no linting errors are reported by mocked tools.
    \"\"\"
    # Configure mock to simulate clean linting results (returncode 0 for both ruff and mypy)
    mock_subprocess_run.side_effect = [
        CompletedProcessMock(0, stdout=""), # ruff output
        CompletedProcessMock(0, stdout="Success: no issues found in 2 source files"), # mypy output
    ]

    context = PipelineContext(project_root=sample_project_dir)
    lint_stage = LintStage()

    result = lint_stage.run(context)

    assert result is True
    assert context.success is True
    assert "overall" in context.lint_results
    assert context.lint_results["overall"]["passed"] is True

    ruff_detail = next(d for d in context.lint_results["overall"]["details"] if d["tool"] == "ruff")
    mypy_detail = next(d for d in context.lint_results["overall"]["details"] if d["tool"] == "mypy")

    assert ruff_detail["passed"] is True
    assert mypy_detail["passed"] is True
    assert "Ruff linting failed" not in " ".join(context.messages)
    assert "Mypy type checking failed" not in " ".join(context.messages)


def test_lint_stage_fails_on_lint_errors(sample_project_dir, mock_subprocess_run):
    \"\"\"
    Verifies LintStage fails and reports errors when mocked linting tools report issues.
    \"\"\"
    # Configure mock to simulate linting failures (returncode > 0)
    mock_subprocess_run.side_effect = [
        CompletedProcessMock(1, stdout="lint_error_module/dirty_code.py:2:1: F401 `os` imported but unused"), # ruff failure
        CompletedProcessMock(1, stdout="lint_error_module/dirty_code.py:12: error: Missing type parameters for generic type \"list\""), # mypy failure
    ]

    context = PipelineContext(project_root=sample_project_dir)
    lint_stage = LintStage()

    result = lint_stage.run(context)

    assert result is False
    assert context.success is False
    assert "overall" in context.lint_results
    assert context.lint_results["overall"]["passed"] is False

    ruff_detail = next(d for d in context.lint_results["overall"]["details"] if d["tool"] == "ruff")
    mypy_detail = next(d for d in context.lint_results["overall"]["details"] if d["tool"] == "mypy")

    assert ruff_detail["passed"] is False
    assert mypy_detail["passed"] is False
    assert "Ruff linting failed" in " ".join(context.messages)
    assert "Mypy type checking failed" in " ".join(context.messages)
    assert "F401 `os` imported but unused" in ruff_detail["stdout"]
    assert "Missing type parameters" in mypy_detail["stdout"]


def test_lint_stage_handles_command_not_found(sample_project_dir, mock_subprocess_run):
    \"\"\"
    Verifies LintStage handles cases where a linter command is not found or fails to execute.
    A returncode of None indicates that the mock simulates a FileNotFoundError or similar.
    \"\"\"
    # Simulate command not found for ruff, then mypy succeeds.
    mock_subprocess_run.side_effect = [
        CompletedProcessMock(returncode=None, stdout="", stderr="Command 'ruff' not found"), 
        CompletedProcessMock(0, stdout="Success: no issues found"), # mypy succeeds
    ]

    context = PipelineContext(project_root=sample_project_dir)
    lint_stage = LintStage()

    result = lint_stage.run(context)

    assert result is False # Overall stage should fail if any sub-tool fails to run
    assert context.success is False
    assert "overall" in context.lint_results
    assert context.lint_results["overall"]["passed"] is False

    ruff_detail = next(d for d in context.lint_results["overall"]["details"] if d["tool"] == "ruff")
    mypy_detail = next(d for d in context.lint_results["overall"]["details"] if d["tool"] == "mypy")

    assert ruff_detail["passed"] is False
    assert "Command not found/mock failed" in ruff_detail["error"]
    assert "Ruff command not found or failed to execute" in " ".join(context.messages)

    # Mypy still ran and passed, but overall stage should still be False because Ruff failed to run.
    assert mypy_detail["passed"] is True


# --- Tests for TestStage ---

def test_test_stage_passes_clean_tests(sample_project_dir, mock_subprocess_run):
    \"\"\"
    Verifies TestStage passes when all tests pass (mocked pytest).n\"\"\"
    # Configure mock to simulate passing tests
    mock_subprocess_run.side_effect = [
        CompletedProcessMock(0, stdout="============================= 2 passed in ...s =============================="), # pytest output
    ]

    context = PipelineContext(project_root=sample_project_dir)
    test_stage = TestStage()

    result = test_stage.run(context)

    assert result is True
    assert context.success is True
    assert "overall" in context.test_results
    assert context.test_results["overall"]["passed"] is True

    pytest_detail = next(d for d in context.test_results["overall"]["details"] if d["tool"] == "pytest")
    assert pytest_detail["passed"] is True
    assert "Pytest failed" not in " ".join(context.messages)


def test_test_stage_fails_on_failing_tests(sample_project_dir, mock_subprocess_run):
    \"\"\"
    Verifies TestStage fails and reports errors when mocked tests fail.
    \"\"\"
    # Configure mock to simulate failing tests
    mock_subprocess_run.side_effect = [
        CompletedProcessMock(1, stdout=textwrap.dedent(\"\"\"
        =================================== FAILURES ===================================
        ____________________________ test_subtract_failure _____________________________

            def test_subtract_failure():
        >       assert subtract(5, 3) == 2 # This will fail
        E       AssertionError: assert 8 == 2
        E        +  where 8 = subtract(5, 3)

        failing_test_module/test_bad_logic.py:5: AssertionError
        =========================== 1 failed, 1 passed in ...s ===========================
        \"\"\")), # pytest failure output
    ]

    context = PipelineContext(project_root=sample_project_dir)
    test_stage = TestStage()

    result = test_stage.run(context)

    assert result is False
    assert context.success is False
    assert "overall" in context.test_results
    assert context.test_results["overall"]["passed"] is False

    pytest_detail = next(d for d in context.test_results["overall"]["details"] if d["tool"] == "pytest")
    assert pytest_detail["passed"] is False
    assert "Pytest failed" in " ".join(context.messages)
    assert "AssertionError: assert 8 == 2" in pytest_detail["stdout"]


def test_test_stage_handles_command_not_found(sample_project_dir, mock_subprocess_run):
    \"\"\"
    Verifies TestStage handles cases where the pytest command is not found or fails to execute.
    \"\"\"
    # Simulate command not found for pytest.
    mock_subprocess_run.side_effect = [
        CompletedProcessMock(returncode=None, stdout="", stderr="Command 'pytest' not found"), # pytest command missing
    ]

    context = PipelineContext(project_root=sample_project_dir)
    test_stage = TestStage()

    result = test_stage.run(context)

    assert result is False
    assert context.success is False
    assert "overall" in context.test_results
    assert context.test_results["overall"]["passed"] is False

    pytest_detail = next(d for d in context.test_results["overall"]["details"] if d["tool"] == "pytest")
    assert pytest_detail["passed"] is False
    assert "Command not found/mock failed" in pytest_detail["error"]
    assert "Pytest command not found or failed to execute" in " ".join(context.messages)
"""
