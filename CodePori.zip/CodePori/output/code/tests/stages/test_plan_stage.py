import pytest
from unittest.mock import MagicMock

from src.stages.plan_stage import PlanStage
from src.models.context import Context


class TestPlanStage:
    """Unit tests for the PlanStage."""

    @pytest.fixture
    def mock_llm_client(self) -> MagicMock:
        """Provides a mock LLM client for dependency injection."""
        return MagicMock()

    @pytest.fixture
    def plan_stage(self, mock_llm_client: MagicMock) -> PlanStage:
        """Provides a PlanStage instance initialized with a mock client."""
        return PlanStage(llm_client=mock_llm_client)

    @pytest.fixture
    def sample_context(self) -> Context:
        """Provides a basic Context object for testing."""
        return Context(initial_prompt="Develop a marketing strategy for a new e-bike.")

    def test_execute_forms_correct_prompt_from_context(self,
                                                 plan_stage: PlanStage,
                                                 mock_llm_client: MagicMock,
                                                 sample_context: Context):
        """Verify the stage constructs the correct LLM prompt from the context."""
        # Arrange: Set a dummy return value to avoid parsing errors
        mock_llm_client.generate_plan.return_value = "1. Step One\n2. Step Two"

        # Act
        plan_stage.execute(sample_context)

        # Assert
        mock_llm_client.generate_plan.assert_called_once()
        actual_prompt = mock_llm_client.generate_plan.call_args[0][0]
        assert isinstance(actual_prompt, str)
        # Check that the core goal from the context is in the prompt
        assert sample_context.initial_prompt in actual_prompt
        # Check that the prompt contains instructions about creating a plan
        assert "plan" in actual_prompt.lower()
        assert "step-by-step" in actual_prompt.lower()

    def test_execute_parses_llm_response_and_updates_context(self,
                                                         plan_stage: PlanStage,
                                                         mock_llm_client: MagicMock,
                                                         sample_context: Context):
        """Verify the stage correctly parses the LLM response into a plan."""
        # Arrange
        mock_response = (
            "1. Identify the target audience.\n"
            "2. Create key messaging and value propositions.\n"
            "3. Launch a social media campaign."
        )
        mock_llm_client.generate_plan.return_value = mock_response

        expected_plan = [
            "1. Identify the target audience.",
            "2. Create key messaging and value propositions.",
            "3. Launch a social media campaign.",
        ]

        # Act
        updated_context = plan_stage.execute(sample_context)

        # Assert
        assert updated_context.plan is not None
        assert updated_context.plan == expected_plan

    def test_execute_handles_response_with_extra_whitespace_and_empty_lines(self,
        plan_stage: PlanStage,
        mock_llm_client: MagicMock,
        sample_context: Context):
        """Verify the parser is robust against common formatting issues."""
        # Arrange
        mock_response = "\n  1. First step.  \n\n2. Second step.\n  \n"
        mock_llm_client.generate_plan.return_value = mock_response

        expected_plan = [
            "1. First step.",
            "2. Second step.",
        ]

        # Act
        updated_context = plan_stage.execute(sample_context)

        # Assert
        assert updated_context.plan == expected_plan

    def test_execute_handles_empty_llm_response_gracefully(self,
                                                      plan_stage: PlanStage,
                                                      mock_llm_client: MagicMock,
                                                      sample_context: Context):
        """Verify an empty or whitespace-only response results in an empty plan."""
        # Arrange
        mock_llm_client.generate_plan.return_value = "  \n  "

        # Act
        updated_context = plan_stage.execute(sample_context)

        # Assert
        assert updated_context.plan == []

    def test_execute_returns_the_modified_context_object(self,
                                                   plan_stage: PlanStage,
                                                   mock_llm_client: MagicMock,
                                                   sample_context: Context):
        """Verify the stage returns the same context object it received."""
        # Arrange
        mock_llm_client.generate_plan.return_value = "1. A step."

        # Act
        result = plan_stage.execute(sample_context)

        # Assert
        assert result is sample_context
        assert isinstance(result, Context)
