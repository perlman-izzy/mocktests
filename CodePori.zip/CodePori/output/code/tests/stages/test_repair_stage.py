import pytest
from unittest.mock import MagicMock
from dataclasses import dataclass
from typing import List

# --- Hypothetical Module Definitions (for test context) ---
# In a real project, these classes would typically be imported from
# a 'src' directory, e.g., 'from src.stages.repair_stage import RepairStage'.
# They are defined here to make the pytest file self-contained and runnable.

@dataclass
class CodeAnalysisError:
    message: str
    rule: str
    line: int
    column: int
    severity: str = "error"

class LLMService:
    def generate_text(self, prompt: str) -> str:
        """Placeholder for an actual LLM API call."""
        raise NotImplementedError("This method should be mocked for tests.")

class RepairStage:
    def __init__(self, llm_service: LLMService):
        self.llm_service = llm_service
        # Template for the prompt sent to the LLM
        self.repair_prompt_template = """
The following Python code has issues. Please fix only the issues described.
Respond ONLY with the complete, corrected Python code, enclosed in ```python...``` blocks.

Original Code:
{original_code}

Issues:
{issues}
"""

    def _format_issues(self, errors: List[CodeAnalysisError]) -> str:
        """Formats a list of CodeAnalysisError objects into a string for the prompt."""
        formatted_issues = []
        for error in errors:
            formatted_issues.append(
                f"- Line {error.line}, Column {error.column}: {error.message} (Rule: {error.rule})"
            )
        return "\n".join(formatted_issues)

    def process(self, code: str, errors: List[CodeAnalysisError]) -> str:
        """Processes code to fix errors using an LLM.

        Args:
            code: The original code string.
            errors: A list of CodeAnalysisError objects representing issues.

        Returns:
            The fixed code string, or the original code if no fix is possible
            or if there are no errors to begin with.
        """
        if not errors:
            return code # No errors to fix, return original code without LLM interaction

        formatted_issues = self._format_issues(errors)
        prompt = self.repair_prompt_template.format(
            original_code=code,
            issues=formatted_issues
        )

        try:
            llm_response_text = self.llm_service.generate_text(prompt)
        except Exception as e:
            # In a production system, this would likely log the error.
            # For a repair stage, returning the original code is a safe default on failure.
            print(f"LLM service failed: {e}") # Placeholder for proper logging
            return code

        # Attempt to parse the fixed code from the LLM's response
        # We expect the LLM to return code enclosed in a ```python...``` block.
        start_tag = "```python\n"
        end_tag = "```"

        # Find the first occurrence of the Python code block
        start_index = llm_response_text.find(start_tag)

        if start_index != -1:
            start_of_code = start_index + len(start_tag)
            end_index = llm_response_text.find(end_tag, start_of_code)
            if end_index != -1:
                fixed_code = llm_response_text[start_of_code:end_index].strip()
                # Return the fixed code if it's not empty after stripping
                if fixed_code:
                    return fixed_code

        # If parsing fails (no code block, malformed, or empty code block after strip),
        # return the original code, indicating no successful fix was applied.
        return code

# --- Pytest Fixtures and Test Class ---

@pytest.fixture
def mock_llm_service() -> MagicMock:
    """Fixture for a mocked LLMService instance."""
    return MagicMock(spec=LLMService)

@pytest.fixture
def repair_stage(mock_llm_service: MagicMock) -> RepairStage:
    """Fixture for a RepairStage instance initialized with a mock LLM service."""
    return RepairStage(llm_service=mock_llm_service)

# Helper function to create an error object for test cases
def create_error(message: str, rule: str, line: int, column: int) -> CodeAnalysisError:
    return CodeAnalysisError(message=message, rule=rule, line=line, column=column)

class TestRepairStage:
    """Unit tests for the RepairStage class."""

    def test_repair_prompt_construction_single_error(self, repair_stage: RepairStage):
        """Verifies the repair prompt is correctly constructed with a single error."""
        original_code = "def foo():\n    pass"
        errors = [
            create_error("Missing docstring", "D100", 1, 0)
        ]

        expected_prompt_substrings = [
            "Original Code:",
            "```python",
            original_code, # Ensure original code is in the prompt
            "Issues:",
            "- Line 1, Column 0: Missing docstring (Rule: D100)"
        ]

        # Mock LLM response to allow inspection of the prompt passed to it
        mock_fixed_code = "def foo():\n    \"\"\"A docstring.\"\"\"\n    pass"
        repair_stage.llm_service.generate_text.return_value = f"```python\n{mock_fixed_code}\n```"

        repair_stage.process(original_code, errors)

        # Assert that generate_text was called with the correct prompt
        repair_stage.llm_service.generate_text.assert_called_once()
        called_prompt = repair_stage.llm_service.generate_text.call_args[0][0]

        for substring in expected_prompt_substrings:
            assert substring in called_prompt

        # Ensure the prompt doesn't contain the template placeholders
        assert "{original_code}" not in called_prompt
        assert "{issues}" not in called_prompt

    def test_repair_prompt_construction_multiple_errors(self, repair_stage: RepairStage):
        """Verifies the repair prompt is correctly constructed with multiple errors."""
        original_code = "def bar():\n    x = 1  \n    print(x)" # Note trailing spaces on line 2
        errors = [
            create_error("Trailing whitespace", "W291", 2, 8),
            create_error("Unused variable 'x'", "F841", 2, 4)
        ]

        expected_prompt_substrings = [
            "Original Code:",
            "```python",
            original_code, # Ensure original code is in the prompt
            "Issues:",
            "- Line 2, Column 8: Trailing whitespace (Rule: W291)",
            "- Line 2, Column 4: Unused variable 'x' (Rule: F841)"
        ]

        mock_fixed_code = "def bar():\n    print(1)"
        repair_stage.llm_service.generate_text.return_value = f"```python\n{mock_fixed_code}\n```"

        repair_stage.process(original_code, errors)

        repair_stage.llm_service.generate_text.assert_called_once()
        called_prompt = repair_stage.llm_service.generate_text.call_args[0][0]

        for substring in expected_prompt_substrings:
            assert substring in called_prompt

    def test_successful_repair_llm_returns_fixed_code(self, repair_stage: RepairStage, mock_llm_service: MagicMock):
        """Tests that the stage correctly processes a successful LLM response with fixed code."""
        original_code = "def func():\n    pass"
        errors = [create_error("Missing docstring", "D100", 1, 0)]
        fixed_code = "def func():\n    \"\"\"A docstring.\"\"\"\n    pass"

        mock_llm_service.generate_text.return_value = f"Some preamble.\n```python\n{fixed_code}\n```\nSome postamble."

        result_code = repair_stage.process(original_code, errors)

        mock_llm_service.generate_text.assert_called_once()
        assert result_code == fixed_code

    def test_llm_returns_original_code_in_block(self, repair_stage: RepairStage, mock_llm_service: MagicMock):
        """Tests handling of an LLM response where the LLM returns the original code."""
        original_code = "def func():\n    pass"
        errors = [create_error("Missing docstring", "D100", 1, 0)]

        # LLM returns the original code within a code block, implying no change or inability to fix
        mock_llm_service.generate_text.return_value = f"```python\n{original_code}\n```"

        result_code = repair_stage.process(original_code, errors)

        mock_llm_service.generate_text.assert_called_once()
        assert result_code == original_code

    def test_llm_malformed_response_no_code_block(self, repair_stage: RepairStage, mock_llm_service: MagicMock):
        """Tests handling of an LLM response that does not contain a proper code block."""
        original_code = "def func():\n    pass"
        errors = [create_error("Missing docstring", "D100", 1, 0)]

        # LLM returns text without the expected code block
        mock_llm_service.generate_text.return_value = "I tried to fix it but couldn't. Here's some text."

        result_code = repair_stage.process(original_code, errors)

        mock_llm_service.generate_text.assert_called_once()
        # Expecting the stage to return original code if it can't parse the fix
        assert result_code == original_code

    def test_no_errors_provided_llm_not_called(self, repair_stage: RepairStage, mock_llm_service: MagicMock):
        """Tests that the LLM is not called when no errors are provided."""
        original_code = "def perfect_code():\n    pass"
        errors = []

        result_code = repair_stage.process(original_code, errors)

        mock_llm_service.generate_text.assert_not_called()
        assert result_code == original_code

    def test_llm_service_exception_returns_original_code(self, repair_stage: RepairStage, mock_llm_service: MagicMock):
        """Tests robust handling when the LLM service raises an exception."""
        original_code = "def func():\n    pass"
        errors = [create_error("Some error", "E000", 1, 0)]

        mock_llm_service.generate_text.side_effect = ConnectionError("LLM API failed")

        result_code = repair_stage.process(original_code, errors)

        mock_llm_service.generate_text.assert_called_once()
        # The stage should return the original code gracefully on LLM failure
        assert result_code == original_code

    def test_llm_returns_empty_or_whitespace_code_block(self, repair_stage: RepairStage, mock_llm_service: MagicMock):
        """Tests handling when LLM returns an empty or whitespace-only code block."""
        original_code = "def func():\n    pass"
        errors = [create_error("Some error", "E000", 1, 0)]

        mock_llm_service.generate_text.return_value = "```python\n   \n```"

        result_code = repair_stage.process(original_code, errors)

        mock_llm_service.generate_text.assert_called_once()
        # An empty or whitespace-only block should be treated as no valid fix
        assert result_code == original_code

    def test_llm_response_multiple_code_blocks_first_is_used(self, repair_stage: RepairStage, mock_llm_service: MagicMock):
        """Ensures that only the first detected code block is used from LLM response."""
        original_code = "def func():\n    pass"
        errors = [create_error("Some error", "E000", 1, 0)]
        fixed_code_1 = "def func():\n    # fixed 1\n    pass"
        fixed_code_2 = "def func():\n    # fixed 2\n    pass"

        mock_llm_service.generate_text.return_value = (
            f"Here's the first attempt:\n```python\n{fixed_code_1}\n```\n"
            f"And here's a second thought:\n```python\n{fixed_code_2}\n```"
        )

        result_code = repair_stage.process(original_code, errors)

        mock_llm_service.generate_text.assert_called_once()
        assert result_code == fixed_code_1 # Should parse and return the content of the first valid block

    def test_llm_response_with_leading_trailing_newlines_in_block(self, repair_stage: RepairStage, mock_llm_service: MagicMock):
        """Tests that leading/trailing newlines within the code block are handled by strip()."""
        original_code = "def foo():\n    print('hello')"
        errors = [create_error("E100", "Lint", 1, 0)]
        fixed_code = "def foo():\n    print('world')"
        llm_response = f"```python\n\n{fixed_code}\n\n```"

        mock_llm_service.generate_text.return_value = llm_response

        result_code = repair_stage.process(original_code, errors)

        assert result_code == fixed_code
