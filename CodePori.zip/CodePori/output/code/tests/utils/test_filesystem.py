import pytest
from pyfakefs.fake_filesystem_unittest import patchfs
import os

# Assume the module exists at src/utils/filesystem.py
# For the purpose of this test, we'll use an absolute import.
# In a real production setup, ensure 'src' is part of your PYTHONPATH
# or that the project structure allows for this import during testing.
try:
    from src.utils import filesystem
except ImportError:
    # This block handles scenarios where 'src' might not be directly in the Python path
    # during certain test runner configurations. In a properly configured production
    # environment, this import should succeed without issues.
    pass

@pytest.fixture
def fs_fixture(fs):
    """
    Pyfakefs fixture that provides a fake filesystem for tests.
    'fs' is the standard fixture name provided by pyfakefs's pytest plugin.
    Renamed to 'fs_fixture' to avoid potential name clashes.
    """
    yield fs

class TestFilesystem:
    """
    Test suite for generic filesystem utility functions in `src.utils.filesystem`.
    These tests utilize `pyfakefs` to ensure complete isolation from the host filesystem.
    Assertions for specific error types (e.g., FileNotFoundError, IsADirectoryError)
    are based on typical Python `os` module behavior and may need adjustment if the
    `filesystem` module implements custom error handling.
    """

    def test_create_directory(self, fs_fixture):
        """
        Test `create_directory` function: verifies directory creation and handling of existing paths.
        """
        test_dir = "/fake/path/to/my_dir"
        filesystem.create_directory(test_dir)
        assert fs_fixture.isdir(test_dir)
        assert fs_fixture.exists(test_dir)

        # Test creating an already existing directory (should not raise an error)
        filesystem.create_directory(test_dir)
        assert fs_fixture.isdir(test_dir)

        # Test creating nested directories, ensuring all parent directories are also created
        nested_dir = "/another/nested/dir/structure"
        filesystem.create_directory(nested_dir)
        assert fs_fixture.isdir(nested_dir)
        assert fs_fixture.isdir("/another/nested/dir")
        assert fs_fixture.isdir("/another/nested")
        assert fs_fixture.isdir("/another")

    def test_write_file(self, fs_fixture):
        """
        Test `write_file` function: verifies content writing, overwriting, and parent directory creation.
        """
        test_file = "/fake/data/my_file.txt"
        content = "Hello, world!"
        filesystem.write_file(test_file, content)
        assert fs_fixture.exists(test_file)
        assert fs_fixture.isfile(test_file)
        with fs_fixture.open(test_file, 'r') as f:
            assert f.read() == content

        # Test overwriting an existing file with new content
        new_content = "New content here."
        filesystem.write_file(test_file, new_content)
        with fs_fixture.open(test_file, 'r') as f:
            assert f.read() == new_content

        # Test creating a file within a non-existent directory structure (should create parent dirs)
        deep_file = "/very/deep/path/data.log"
        deep_content = "Log entry for deep file."
        filesystem.write_file(deep_file, deep_content)
        assert fs_fixture.exists(deep_file)
        assert fs_fixture.isfile(deep_file)
        assert fs_fixture.isdir("/very/deep/path") # Verify parent directory creation
        with fs_fixture.open(deep_file, 'r') as f:
            assert f.read() == deep_content

    def test_read_file(self, fs_fixture):
        """
        Test `read_file` function: verifies correct content reading and handling of non-existent files.
        Assumes `read_file` returns None for non-existent paths or if the path is not a regular file.
        """
        test_file = "/fake/data/read_me.txt"
        content = "This is content to be read."
        fs_fixture.create_file(test_file, contents=content)

        read_content = filesystem.read_file(test_file)
        assert read_content == content

        # Test reading a non-existent file
        non_existent_file = "/fake/non_existent.txt"
        read_content_non_existent = filesystem.read_file(non_existent_file)
        assert read_content_non_existent is None

        # Test attempting to read a directory as a file
        fs_fixture.create_dir("/fake/dir_to_read")
        read_dir_content = filesystem.read_file("/fake/dir_to_read")
        # If the actual 'read_file' function raises IsADirectoryError, this assertion needs adjustment.
        assert read_dir_content is None

    def test_path_exists(self, fs_fixture):
        """
        Test `path_exists` function: verifies correct identification of existing files and directories.
        """
        file_path = "/a/b/file.txt"
        dir_path = "/a/b/c"
        fs_fixture.create_file(file_path)
        fs_fixture.create_dir(dir_path)

        assert filesystem.path_exists(file_path)
        assert filesystem.path_exists(dir_path)
        assert not filesystem.path_exists("/non/existent/path")
        assert not filesystem.path_exists("/a/b/non_existent_file.txt")

    def test_is_directory(self, fs_fixture):
        """
        Test `is_directory` function: verifies correct identification of directories and non-directories.
        """
        file_path = "/data/my_file.log"
        dir_path = "/data/my_dir"
        fs_fixture.create_file(file_path)
        fs_fixture.create_dir(dir_path)

        assert filesystem.is_directory(dir_path)
        assert not filesystem.is_directory(file_path)
        assert not filesystem.is_directory("/non/existent/path")

    def test_is_file(self, fs_fixture):
        """
        Test `is_file` function: verifies correct identification of files and non-files.
        """
        file_path = "/data/another_file.txt"
        dir_path = "/data/another_dir"
        fs_fixture.create_file(file_path)
        fs_fixture.create_dir(dir_path)

        assert filesystem.is_file(file_path)
        assert not filesystem.is_file(dir_path)
        assert not filesystem.is_file("/non/existent/path")

    def test_list_directory(self, fs_fixture):
        """
        Test `list_directory` function: verifies listing of directory contents and handling of edge cases.
        Assumes `list_directory` returns an empty list for non-existent paths or if the path is not a directory.
        """
        root_dir = "/test_listing"
        fs_fixture.create_dir(root_dir)
        fs_fixture.create_file(os.path.join(root_dir, "file1.txt"))
        fs_fixture.create_dir(os.path.join(root_dir, "subdir"))
        fs_fixture.create_file(os.path.join(root_dir, "file2.log"))

        contents = filesystem.list_directory(root_dir)
        assert set(contents) == {"file1.txt", "subdir", "file2.log"}

        # Test an empty directory
        empty_dir = "/empty_dir"
        fs_fixture.create_dir(empty_dir)
        assert filesystem.list_directory(empty_dir) == []

        # Test a non-existent directory
        non_existent_dir = "/no/such/dir"
        assert filesystem.list_directory(non_existent_dir) == []

        # Test attempting to list contents of a file as if it were a directory
        file_as_dir = "/fake/file_as_dir.txt"
        fs_fixture.create_file(file_as_dir)
        assert filesystem.list_directory(file_as_dir) == []

    def test_remove_file(self, fs_fixture):
        """
        Test `remove_file` function: verifies successful file removal and graceful handling of non-existent files.
        """
        test_file = "/temp/file_to_remove.txt"
        fs_fixture.create_file(test_file, contents="delete me")
        assert fs_fixture.exists(test_file)

        filesystem.remove_file(test_file)
        assert not fs_fixture.exists(test_file)

        # Test removing a non-existent file (should not raise an error)
        filesystem.remove_file("/temp/non_existent.txt")

        # Test attempting to remove a directory using remove_file (should not remove the directory)
        test_dir = "/temp/dir_not_file"
        fs_fixture.create_dir(test_dir)
        filesystem.remove_file(test_dir)
        assert fs_fixture.exists(test_dir)

    def test_remove_directory(self, fs_fixture):
        """
        Test `remove_directory` function: verifies removal of empty/non-empty directories and error handling.
        """
        # Test removing an empty directory
        empty_dir = "/to_remove/empty"
        fs_fixture.create_dir(empty_dir)
        assert fs_fixture.exists(empty_dir)
        filesystem.remove_directory(empty_dir)
        assert not fs_fixture.exists(empty_dir)

        # Test removing a non-empty directory (non-recursive) - should raise OSError (e.g., from os.rmdir)
        non_empty_dir_non_recursive = "/to_remove/non_empty_non_recursive"
        fs_fixture.create_dir(non_empty_dir_non_recursive)
        fs_fixture.create_file(os.path.join(non_empty_dir_non_recursive, "file.txt"))
        with pytest.raises(OSError): # os.rmdir raises OSError if directory is not empty
            filesystem.remove_directory(non_empty_dir_non_recursive, recursive=False)
        assert fs_fixture.exists(non_empty_dir_non_recursive) # Directory should still exist

        # Test removing a non-empty directory (recursive)
        non_empty_dir_recursive = "/to_remove/non_empty_recursive"
        fs_fixture.create_dir(non_empty_dir_recursive)
        fs_fixture.create_file(os.path.join(non_empty_dir_recursive, "another_file.txt"))
        filesystem.remove_directory(non_empty_dir_recursive, recursive=True)
        assert not fs_fixture.exists(non_empty_dir_recursive)

        # Test removing a non-existent directory (should not raise error for both recursive/non-recursive)
        filesystem.remove_directory("/no/such/dir_to_remove_rec", recursive=True)
        filesystem.remove_directory("/no/such/dir_to_remove_non_rec", recursive=False)

        # Test attempting to remove a file using remove_directory (should raise an OSError)
        file_not_dir = "/temp/file_not_dir.txt"
        fs_fixture.create_file(file_not_dir)
        with pytest.raises(OSError): # E.g., os.rmdir or shutil.rmtree on a file would raise OSError/NotADirectoryError
             filesystem.remove_directory(file_not_dir)
        assert fs_fixture.exists(file_not_dir) # File should still exist
