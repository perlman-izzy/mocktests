import pytest
import sys
import time
import os

# Assuming src.utils.process exists and contains run_command and CommandExecutionError
# This import path assumes 'src' is directly under the project root.
from src.utils.process import run_command, CommandExecutionError

def test_run_command_success_echo_stdout():
    """Test running a simple echo command and capturing stdout."""
    command = [sys.executable, "-c", "print('hello pytest')"]
    stdout, stderr, exit_code = run_command(command)

    assert exit_code == 0
    assert "hello pytest" in stdout
    assert stderr == ""

def test_run_command_success_echo_stderr():
    """Test running a command that outputs to stderr and capturing stderr."""
    command = [sys.executable, "-c", "import sys; print('error output', file=sys.stderr)"]
    stdout, stderr, exit_code = run_command(command)

    assert exit_code == 0
    assert stdout == ""
    assert "error output" in stderr

def test_run_command_success_mixed_output():
    """Test running a command with both stdout and stderr."""
    command = [sys.executable, "-c", "import sys; print('standard out'); print('standard error', file=sys.stderr)"]
    stdout, stderr, exit_code = run_command(command)

    assert exit_code == 0
    assert "standard out" in stdout
    assert "standard error" in stderr

def test_run_command_success_no_output():
    """Test running a command that produces no output."""
    command = [sys.executable, "-c", "pass"] # A Python script that does nothing
    stdout, stderr, exit_code = run_command(command)

    assert exit_code == 0
    assert stdout == ""
    assert stderr == ""

def test_run_command_failure_nonzero_exit_code():
    """Test running a command that exits with a non-zero status code."""
    command = [sys.executable, "-c", "import sys; sys.exit(10)"]
    stdout, stderr, exit_code = run_command(command)

    assert exit_code == 10
    assert stdout == ""
    assert stderr == ""

def test_run_command_failure_with_output():
    """Test running a command that fails and produces output to stderr."""
    command = [sys.executable, "-c", "import sys; print('critical error', file=sys.stderr); sys.exit(5)"]
    stdout, stderr, exit_code = run_command(command)

    assert exit_code == 5
    assert stdout == ""
    assert "critical error" in stderr

def test_run_command_not_found():
    """Test running a non-existent command raises CommandExecutionError."""
    # This command name is highly unlikely to exist on any system
    non_existent_command = ["non_existent_utility_1a2b3c4d5e", "arg"]
    with pytest.raises(CommandExecutionError) as excinfo:
        run_command(non_existent_command)
    # The specific error message might vary by OS, but "not found" or similar is expected.
    # Check for common messages related to command not found errors
    error_message_str = str(excinfo.value).lower()
    assert "not found" in error_message_str or \
           "no such file or directory" in error_message_str or \
           "system cannot find the file specified" in error_message_str

def test_run_command_timeout():
    """Test that a command exceeding the timeout raises CommandExecutionError."""
    # Command sleeps for 1 second, but timeout is 0.1 seconds
    sleep_duration = 1.0
    timeout_duration = 0.1
    command = [sys.executable, "-c", f"import time; time.sleep({sleep_duration})"]

    with pytest.raises(CommandExecutionError) as excinfo:
        run_command(command, timeout=timeout_duration)

    assert f"timed out after {timeout_duration} seconds" in str(excinfo.value)
    # Assuming the hypothetical implementation sets exit_code for timeout errors
    assert excinfo.value.exit_code == -999

def test_run_command_check_success():
    """Test 'check=True' for a successful command does not raise an exception."""
    command = [sys.executable, "-c", "print('all good')"]
    stdout, stderr, exit_code = run_command(command, check=True)

    assert exit_code == 0
    assert "all good" in stdout

def test_run_command_check_failure_raises():
    """Test 'check=True' for a failing command raises CommandExecutionError."""
    command = [sys.executable, "-c", "import sys; sys.exit(1)"]
    with pytest.raises(CommandExecutionError) as excinfo:
        run_command(command, check=True)

    assert excinfo.value.exit_code == 1
    assert "failed with exit code 1" in str(excinfo.value)
