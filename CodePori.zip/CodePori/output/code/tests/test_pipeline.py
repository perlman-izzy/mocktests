import pytest
from unittest.mock import Mock, call

# This test assumes the Pipeline class is located at 'src.orchestration.pipeline'.
# The import path should be adjusted if the actual location is different.
from src.orchestration.pipeline import Pipeline


class TestPipeline:
    """Unit tests for the Pipeline orchestrator class."""

    def test_pipeline_initialization(self):
        """
        Verify that the Pipeline class correctly stores the list of stages
        provided during its initialization.
        """
        mock_stage_1 = Mock()
        mock_stage_2 = Mock()
        stages = [mock_stage_1, mock_stage_2]

        pipeline = Pipeline(stages=stages)

        assert pipeline.stages is stages, "Pipeline should store the exact list of stages provided."

    def test_empty_pipeline_returns_initial_context(self):
        """
        Verify that running a pipeline with no stages returns the initial
        context object unmodified and without error.
        """
        pipeline = Pipeline(stages=[])
        initial_context = {"data": "initial_value"}

        final_context = pipeline.run(initial_context)

        assert final_context is initial_context, "Should return the same context object instance."
        assert final_context == {"data": "initial_value"}

    def test_executes_stages_in_order(self):
        """
        Verify that stages are executed in the exact sequence they are provided
        in the pipeline's stage list.
        """
        # A manager mock helps track the order of calls to its attributes
        manager = Mock()
        mock_stage_1 = manager.stage1
        mock_stage_2 = manager.stage2
        mock_stage_3 = manager.stage3

        initial_context = {"data": "start"}
        # Stages must return a context for the next stage to receive it.
        # For this test, we assume the context is not modified.
        mock_stage_1.run.return_value = initial_context
        mock_stage_2.run.return_value = initial_context
        mock_stage_3.run.return_value = initial_context

        pipeline = Pipeline(stages=[mock_stage_1, mock_stage_2, mock_stage_3])
        pipeline.run(initial_context)

        # Assert that the 'run' method of each mock was called in the expected order
        expected_calls = [
            call.stage1.run(initial_context),
            call.stage2.run(initial_context),
            call.stage3.run(initial_context),
        ]
        manager.assert_has_calls(expected_calls, any_order=False)

    def test_passes_modified_context_between_stages(self):
        """
        Verify that the context object, modified by one stage, is correctly
        passed as input to the subsequent stage.
        """
        # Define side effects to simulate context modification
        def stage_1_side_effect(context):
            context["stage1_executed"] = True
            return context

        def stage_2_side_effect(context):
            context["stage2_executed"] = True
            return context

        mock_stage_1 = Mock(name="Stage1")
        mock_stage_1.run.side_effect = stage_1_side_effect
        mock_stage_2 = Mock(name="Stage2")
        mock_stage_2.run.side_effect = stage_2_side_effect

        pipeline = Pipeline(stages=[mock_stage_1, mock_stage_2])
        initial_context = {"initial_data": 123}

        # Pass a copy to avoid modifying the original dict in the test's scope
        final_context = pipeline.run(initial_context.copy())

        # Verify calls with the correctly modified context at each step
        mock_stage_1.run.assert_called_once_with({"initial_data": 123})
        mock_stage_2.run.assert_called_once_with(
            {"initial_data": 123, "stage1_executed": True}
        )

        # Verify the final state of the context after all stages have run
        expected_final_context = {
            "initial_data": 123,
            "stage1_executed": True,
            "stage2_executed": True,
        }
        assert final_context == expected_final_context

    def test_stops_and_propagates_stage_exceptions(self):
        """
        Verify that if a stage raises an exception, the pipeline execution
        halts immediately and the exception is propagated to the caller.
        """
        mock_stage_1 = Mock(name="Stage1_Success")
        mock_stage_2 = Mock(name="Stage2_Failure")
        mock_stage_3 = Mock(name="Stage3_NotReached")

        # Configure the second stage to fail
        mock_stage_2.run.side_effect = ValueError("Stage 2 failed intentionally")

        pipeline = Pipeline(stages=[mock_stage_1, mock_stage_2, mock_stage_3])
        initial_context = {"data": "input"}

        with pytest.raises(ValueError, match="Stage 2 failed intentionally"):
            pipeline.run(initial_context)

        # Verify that the pipeline stopped after the failure
        mock_stage_1.run.assert_called_once()
        mock_stage_2.run.assert_called_once()
        mock_stage_3.run.assert_not_called(), "Pipeline should not execute stages after an exception."
