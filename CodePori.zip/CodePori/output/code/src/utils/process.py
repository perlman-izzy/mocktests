from __future__ import annotations
import subprocess
import shlex
from typing import List, Optional, Union

class CommandExecutionError(RuntimeError):
    def __init__(self, cmd: Union[str, List[str]], returncode: int, stdout: str, stderr: str):
        self.cmd = cmd
        self.returncode = returncode
        self.stdout = stdout
        self.stderr = stderr
        super().__init__(f"Command failed ({returncode}): {cmd}\n{stderr}")

def run_command(cmd: Union[str, List[str]], cwd: Optional[str] = None, timeout: Optional[int] = None) -> subprocess.CompletedProcess:
    args = shlex.split(cmd) if isinstance(cmd, str) else list(cmd)
    proc = subprocess.run(
        args,
        cwd=cwd,
        capture_output=True,
        text=True,
        timeout=timeout,
        check=False,
    )
    if proc.returncode != 0:
        raise CommandExecutionError(args, proc.returncode, proc.stdout or "", proc.stderr or "")
    return proc
