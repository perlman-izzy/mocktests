# Auto-generated adapter for tests. Driver-scope only.
try:
    from src.core.pipeline import Pipeline as _Core  # optional delegation if present
except Exception:
    _Core = object  # type: ignore

class Pipeline(_Core):  # type: ignore[misc]
    def __init__(self, stages: object = None, **kwargs):
        ok = False
        try:
            super().__init__(stages=stages, **kwargs)
            ok = True
        except TypeError:
            try:
                super().__init__(**kwargs)
                ok = True
            except Exception:
                pass
        except Exception:
            pass
        self.__dict__.update({'stages': stages})
