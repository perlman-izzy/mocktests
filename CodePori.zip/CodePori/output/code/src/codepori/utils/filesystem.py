import hashlib
import logging
import os
import shutil
from pathlib import Path
from typing import List, Optional, Union, Iterator

# Set up a logger for this module
logger = logging.getLogger(__name__)


# --- Custom Exception Hierarchy ---

class FileSystemError(IOError):
    """Base exception for all filesystem-related errors in this module."""
    def __init__(self, message: str, original_exception: Optional[Exception] = None):
        """Initializes the FileSystemError.

        Args:
            message (str): The error message.
            original_exception (Optional[Exception]): The original exception, if any.
        """
        super().__init__(message)
        self.original_exception = original_exception


class FileReadError(FileSystemError):
    """Raised when an error occurs while reading a file."""


class FileWriteError(FileSystemError):
    """Raised when an error occurs while writing to a file."""


class DirectoryOperationError(FileSystemError):
    """Raised when an error occurs during a directory operation."""


class FileOperationError(FileSystemError):
    """Raised when an error occurs during a generic file operation like copy or move."""


# --- Filesystem Utility Functions ---

def ensure_dir_exists(path: Union[str, Path]) -> None:
    """Ensures that a directory exists, creating it if necessary.

    This function will create the directory and any parent directories
    if they do not already exist.

    Args:
        path (Union[str, Path]): The path to the directory.

    Raises:
        DirectoryOperationError: If the path exists but is a file, or if there's
            a permission error during creation.
    """
    try:
        dir_path = Path(path)
        if not dir_path.exists():
            logger.info(f"Directory '{dir_path}' does not exist. Creating it.")
            dir_path.mkdir(parents=True, exist_ok=True)
        elif not dir_path.is_dir():
            msg = f"Path '{dir_path}' exists but is not a directory."
            logger.error(msg)
            raise DirectoryOperationError(msg)
    except PermissionError as e:
        msg = f"Permission denied while trying to create directory '{path}'."
        logger.exception(msg)
        raise DirectoryOperationError(msg, original_exception=e) from e
    except Exception as e:
        msg = f"An unexpected error occurred while ensuring directory '{path}' exists."
        logger.exception(msg)
        raise DirectoryOperationError(msg, original_exception=e) from e


def read_file(path: Union[str, Path], encoding: str = 'utf-8') -> str:
    """Reads the entire content of a file and returns it as a string.

    Args:
        path (Union[str, Path]): The path to the file to be read.
        encoding (str): The encoding to use when reading the file. Defaults to 'utf-8'.

    Returns:
        str: The content of the file.

    Raises:
        FileReadError: If the file is not found, cannot be read due to permissions,
            or if a decoding error occurs.
    """
    file_path = Path(path)
    logger.debug(f"Attempting to read file: '{file_path}'")
    try:
        return file_path.read_text(encoding=encoding)
    except FileNotFoundError as e:
        msg = f"File not found at path: '{file_path}'"
        logger.error(msg)
        raise FileReadError(msg, original_exception=e) from e
    except PermissionError as e:
        msg = f"Permission denied while trying to read file: '{file_path}'"
        logger.error(msg)
        raise FileReadError(msg, original_exception=e) from e
    except UnicodeDecodeError as e:
        msg = f"Could not decode file '{file_path}' with encoding '{encoding}'."
        logger.error(msg)
        raise FileReadError(msg, original_exception=e) from e
    except Exception as e:
        msg = f"An unexpected error occurred while reading file: '{file_path}'"
        logger.exception(msg)
        raise FileReadError(msg, original_exception=e) from e


def write_file(path: Union[str, Path], content: str, append: bool = False, encoding: str = 'utf-8') -> None:
    """Writes string content to a file.

    By default, this will overwrite the file if it exists. The parent directory
    will be created if it doesn't exist.

    Args:
        path (Union[str, Path]): The path to the file to be written.
        content (str): The string content to write to the file.
        append (bool): If True, appends content to the end of the file. If False
                       (default), overwrites the file.
        encoding (str): The encoding to use for writing the file. Defaults to 'utf-8'.

    Raises:
        FileWriteError: If the directory cannot be created, writing fails due to
            permissions, or another I/O error occurs.
    """
    file_path = Path(path)
    logger.debug(f"Attempting to write to file: '{file_path}' (append={append})")
    try:
        # Ensure the parent directory exists before writing
        ensure_dir_exists(file_path.parent)

        mode = 'a' if append else 'w'
        with open(file_path, mode, encoding=encoding) as f:
            f.write(content)
        logger.info(f"Successfully wrote {len(content)} characters to '{file_path}'.")
    except DirectoryOperationError as e:
        # Re-raise as a write error to show context
        msg = f"Failed to create parent directory for file '{file_path}'."
        logger.error(msg)
        raise FileWriteError(msg, original_exception=e) from e
    except PermissionError as e:
        msg = f"Permission denied when trying to write to file: '{file_path}'"
        logger.error(msg)
        raise FileWriteError(msg, original_exception=e) from e
    except Exception as e:
        msg = f"An unexpected error occurred while writing to file: '{file_path}'"
        logger.exception(msg)
        raise FileWriteError(msg, original_exception=e) from e


def delete_file(path: Union[str, Path], missing_ok: bool = False) -> None:
    """Deletes a single file.

    Args:
        path (Union[str, Path]): The path to the file to delete.
        missing_ok (bool): If False (default), a FileNotFoundError is raised if
                           the file does not exist. If True, no exception is
                           raised.

    Raises:
        FileOperationError: If the path is a directory or if a permission error occurs.
    """
    file_path = Path(path)
    logger.debug(f"Attempting to delete file: '{file_path}'")
    try:
        file_path.unlink(missing_ok=missing_ok)
        logger.info(f"Successfully deleted file: '{file_path}'")
    except IsADirectoryError as e:
        msg = f"Path '{file_path}' is a directory, not a file. Use delete_directory()."
        logger.error(msg)
        raise FileOperationError(msg, original_exception=e) from e
    except PermissionError as e:
        msg = f"Permission denied while trying to delete file: '{file_path}'"
        logger.error(msg)
        raise FileOperationError(msg, original_exception=e) from e
    except Exception as e:
        msg = f"An unexpected error occurred while deleting file: '{file_path}'"
        logger.exception(msg)
        raise FileOperationError(msg, original_exception=e) from e


def delete_directory(path: Union[str, Path], ignore_errors: bool = False) -> None:
    """Deletes a directory and all its contents recursively.

    Args:
        path (Union[str, Path]): The path to the directory to delete.
        ignore_errors (bool): If True, errors resulting from failed removals will
                              be ignored. If False (default), errors are propagated.

    Raises:
        DirectoryOperationError: If the path is not a directory or if a permission error occurs.
    """
    dir_path = Path(path)
    logger.debug(f"Attempting to recursively delete directory: '{dir_path}'")
    if not dir_path.exists():
        logger.warning(f"Attempted to delete non-existent directory: '{dir_path}'")
        return
    if not dir_path.is_dir():
        msg = f"Path '{dir_path}' is a file, not a directory. Use delete_file()."
        logger.error(msg)
        raise DirectoryOperationError(msg)

    try:
        shutil.rmtree(dir_path, ignore_errors=ignore_errors)
        logger.info(f"Successfully deleted directory: '{dir_path}'")
    except PermissionError as e:
        msg = f"Permission denied while deleting directory: '{dir_path}'"
        logger.error(msg)
        raise DirectoryOperationError(msg, original_exception=e) from e
    except Exception as e:
        msg = f"An unexpected error occurred while deleting directory: '{dir_path}'"
        logger.exception(msg)
        raise DirectoryOperationError(msg, original_exception=e) from e


def file_exists(path: Union[str, Path]) -> bool:
    """Checks if a path exists and is a file.

    Args:
        path (Union[str, Path]): The path to check.

    Returns:
        bool: True if the path exists and is a file, False otherwise.
    """
    return Path(path).is_file()


def dir_exists(path: Union[str, Path]) -> bool:
    """Checks if a path exists and is a directory.

    Args:
        path (Union[str, Path]): The path to check.

    Returns:
        bool: True if the path exists and is a directory, False otherwise.
    """
    return Path(path).is_dir()


def copy_file(src: Union[str, Path], dest: Union[str, Path]) -> None:
    """Copies a file from a source path to a destination path.

    The destination's parent directory will be created if it does not exist.

    Args:
        src (Union[str, Path]): The source file path.
        dest (Union[str, Path]): The destination file path.

    Raises:
        FileOperationError: If the source is not a file, or if any other I/O
            or permission error occurs during the copy.
    """
    src_path = Path(src)
    dest_path = Path(dest)
    logger.debug(f"Copying file from '{src_path}' to '{dest_path}'")

    if not src_path.is_file():
        msg = f"Source path '{src_path}' is not a file or does not exist."
        logger.error(msg)
        raise FileOperationError(msg)

    try:
        ensure_dir_exists(dest_path.parent)
        shutil.copy2(src_path, dest_path)
        logger.info(f"Successfully copied '{src_path}' to '{dest_path}'")
    except Exception as e:
        msg = f"An unexpected error occurred while copying '{src_path}' to '{dest_path}'."
        logger.exception(msg)
        raise FileOperationError(msg, original_exception=e) from e


def move_file(src: Union[str, Path], dest: Union[str, Path]) -> None:
    """Moves a file from a source path to a destination path.

    The destination's parent directory will be created if it does not exist.

    Args:
        src (Union[str, Path]): The source file path.
        dest (Union[str, Path]): The destination file path.

    Raises:
        FileOperationError: If the source is not a file, or if any other I/O
            or permission error occurs during the move.
    """
    src_path = Path(src)
    dest_path = Path(dest)
    logger.debug(f"Moving file from '{src_path}' to '{dest_path}'")

    if not src_path.is_file():
        msg = f"Source path '{src_path}' is not a file or does not exist."
        logger.error(msg)
        raise FileOperationError(msg)

    try:
        ensure_dir_exists(dest_path.parent)
        shutil.move(str(src_path), str(dest_path))
        logger.info(f"Successfully moved '{src_path}' to '{dest_path}'")
    except Exception as e:
        msg = f"An unexpected error occurred while moving '{src_path}' to '{dest_path}'."
        logger.exception(msg)
        raise FileOperationError(msg, original_exception=e) from e


def get_file_size(path: Union[str, Path]) -> int:
    """Gets the size of a file in bytes.

    Args:
        path (Union[str, Path]): The path to the file.

    Returns:
        int: The size of the file in bytes.

    Raises:
        FileOperationError: If the path does not exist or is not a file.
    """
    file_path = Path(path)
    try:
        return file_path.stat().st_size
    except FileNotFoundError as e:
        msg = f"Cannot get size. File not found at path: '{file_path}'"
        logger.error(msg)
        raise FileOperationError(msg, original_exception=e) from e
    except Exception as e:
        msg = f"An unexpected error occurred while getting size of file: '{file_path}'"
        logger.exception(msg)
        raise FileOperationError(msg, original_exception=e) from e


def get_file_hash(path: Union[str, Path], algorithm: str = 'sha256', chunk_size: int = 8192) -> str:
    """Calculates the hash of a file.

    Args:
        path (Union[str, Path]): The path to the file.
        algorithm (str): The hash algorithm to use (e.g., 'md5', 'sha1', 'sha256').
        chunk_size (int): The size of chunks to read from the file.

    Returns:
        str: The hexadecimal hash digest.

    Raises:
        FileReadError: If the file cannot be read.
        ValueError: If the specified algorithm is not supported.
    """
    file_path = Path(path)
    logger.debug(f"Calculating '{algorithm}' hash for file: '{file_path}'")
    try:
        hasher = hashlib.new(algorithm)
    except ValueError as e:
        msg = f"Hashing algorithm '{algorithm}' is not supported."
        logger.error(msg)
        raise ValueError(msg) from e

    try:
        with open(file_path, 'rb') as f:
            while chunk := f.read(chunk_size):
                hasher.update(chunk)
        return hasher.hexdigest()
    except FileNotFoundError as e:
        msg = f"File not found at path: '{file_path}'"
        logger.error(msg)
        raise FileReadError(msg, original_exception=e) from e
    except Exception as e:
        msg = f"An unexpected error occurred while hashing file: '{file_path}'"
        logger.exception(msg)
        raise FileReadError(msg, original_exception=e) from e


def list_directory(
    path: Union[str, Path],
    pattern: str = '*',
    recursive: bool = False
) -> Iterator[Path]:
    """Lists the contents of a directory, with optional filtering and recursion.

    Args:
        path (Union[str, Path]): The path to the directory to list.
        pattern (str): A glob-style pattern to filter the results (e.g., '*.txt').
        recursive (bool): If True, lists contents of all subdirectories as well.

    Yields:
        Iterator[Path]: An iterator of Path objects for each matching item.

    Raises:
        DirectoryOperationError: If the path does not exist or is not a directory.
    """
    dir_path = Path(path)
    if not dir_path.is_dir():
        msg = f"Provided path is not a valid directory: '{dir_path}'"
        logger.error(msg)
        raise DirectoryOperationError(msg)

    logger.debug(f"Listing directory '{dir_path}' with pattern '{pattern}' (recursive={recursive})")
    try:
        if recursive:
            yield from dir_path.rglob(pattern)
        else:
            yield from dir_path.glob(pattern)
    except Exception as e:
        msg = f"An unexpected error occurred while listing directory: '{dir_path}'"
        logger.exception(msg)
        raise DirectoryOperationError(msg, original_exception=e) from e
