import os
import sys
import logging
from pathlib import Path
from typing import Optional, Dict, Any, List

import yaml
from pydantic import (
    BaseModel, Field, ValidationError,
    computed_field, HttpUrl
)
from pydantic_settings import BaseSettings, SettingsConfigDict

# Configure logging for this module
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
handler = logging.StreamHandler(sys.stdout)
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)

class ConfigError(Exception):
    """Base exception for configuration-related errors."""
    pass

class ConfigValidationError(ConfigError):
    """Exception raised for validation errors in configuration."""
    pass

class DatabaseSettings(BaseModel):
    """
    Settings for database connection.

    Attributes:
        type (str): The type of the database (e.g., "postgresql", "sqlite").
        host (str): The database host.
        port (int): The database port.
        user (str): The database user.
        password (str): The database password.
        name (str): The database name.
    """
    type: str = Field(..., description="Type of the database (e.g., 'postgresql', 'sqlite').")
    host: str = Field("localhost", description="Database host address.")
    port: int = Field(5432, description="Database port number.")
    user: str = Field("codepori", description="Database username.")
    password: str = Field(..., description="Database user password.", json_schema_extra={"env": "DB_PASSWORD"})
    name: str = Field("codepori_db", description="Name of the database.")

    model_config = SettingsConfigDict(env_prefix="DB_", extra='forbid')

    @computed_field
    @property
    def uri(self) -> str:
        """
        Computes the database connection URI.

        Returns:
            str: The formatted database connection URI.
        """
        if self.type.lower() == "sqlite":
            return f"sqlite:///{self.name}.db"
        return f"{self.type}://{self.user}:{self.password}@{self.host}:{self.port}/{self.name}"

class APISettings(BaseModel):
    """
    Settings for external API integrations.

    Attributes:
        base_url (HttpUrl): The base URL for the API.
        api_key (str): The API key for authentication.
        timeout_seconds (int): Timeout for API requests in seconds.
    """
    base_url: HttpUrl = Field(..., description="Base URL for the external API.", json_schema_extra={"env": "API_BASE_URL"})
    api_key: str = Field(..., description="API key for authentication.", json_schema_extra={"env": "API_KEY", 'secret': True})
    timeout_seconds: int = Field(30, description="Timeout for API requests in seconds.")

    model_config = SettingsConfigDict(env_prefix="API_", extra='forbid')

class LoggingSettings(BaseModel):
    """
    Settings for application logging.

    Attributes:
        level (str): The minimum logging level (e.g., "INFO", "DEBUG", "WARNING").
        log_file (Optional[Path]): Path to the log file. If None, logs to console.
        format (str): The logging format string.
    """
    level: str = Field("INFO", description="Minimum logging level (e.g., 'INFO', 'DEBUG').")
    log_file: Optional[Path] = Field(None, description="Path to the log file. If None, logs to console.")
    format: str = Field(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        description="Logging format string."
    )

    model_config = SettingsConfigDict(extra='forbid')

class AppSettings(BaseSettings):
    """
    Main application settings, combining various configuration sections.

    Attributes:
        env (str): The application environment (e.g., "development", "production").
        debug_mode (bool): Whether debug mode is enabled.
        database (DatabaseSettings): Database connection settings.
        api (APISettings): External API integration settings.
        logging (LoggingSettings): Application logging settings.
        project_name (str): The name of the project.
        version (str): The application version.
    """
    env: str = Field("development", description="Application environment (e.g., 'development', 'production').", env="APP_ENV")
    debug_mode: bool = Field(False, description="Enable or disable debug mode.", env="APP_DEBUG_MODE")
    project_name: str = Field("CodePori", description="Name of the project.")
    version: str = Field("0.1.0", description="Current application version.")
    database: DatabaseSettings = Field(..., description="Database connection settings.")
    api: APISettings = Field(..., description="External API integration settings.")
    logging: LoggingSettings = Field(..., description="Application logging settings.")

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra='forbid',
        env_nested_delimiter='__', # For nested environment variables, e.g., DB__HOST
    )

    @computed_field
    @property
    def is_production(self) -> bool:
        """
        Checks if the current environment is production.

        Returns:
            bool: True if environment is 'production', False otherwise.
        """
        return self.env.lower() == "production"

    @classmethod
    def load_from_dict(cls, data: Dict[str, Any]) -> "AppSettings":
        """
        Loads settings from a dictionary.

        Args:
            data (Dict[str, Any]): A dictionary containing configuration values.

        Returns:
            AppSettings: An instance of AppSettings populated from the dictionary.

        Raises:
            ConfigValidationError: If the provided dictionary data is invalid.
        """
        try:
            return cls(**data)
        except ValidationError as e:
            raise ConfigValidationError(f"Configuration validation error: {e}") from e

class ConfigManager:
    """
    Manages the loading, validation, and access of application configuration.

    This class provides a singleton-like access pattern for the application settings,
    loading them from a `config.yaml` file and environment variables.
    """
    _instance: Optional[AppSettings] = None
    _config_file_names: List[str] = ["config.yaml", "config.yml"]
    _search_paths: List[Path] = [
        Path.cwd(),
        Path.cwd().parent,  # For common project structures
        Path.home() / ".codepori", # User-specific config
        Path("/etc/codepori") # System-wide config
    ]
    _config_env_var: str = "CODEPORI_CONFIG_PATH"

    @classmethod
    def get_settings(cls) -> AppSettings:
        """
        Retrieves the application settings. Loads them if not already loaded.

        Returns:
            AppSettings: The loaded application settings.

        Raises:
            ConfigError: If the configuration file cannot be found or loaded.
            ConfigValidationError: If the loaded configuration is invalid.
        """
        if cls._instance is None:
            cls._instance = cls._load_settings()
            logger.info("Application settings loaded successfully.")
        return cls._instance

    @classmethod
    def _find_config_file(cls) -> Optional[Path]:
        """
        Attempts to find the configuration file in predefined locations or via an environment variable.

        Returns:
            Optional[Path]: The path to the found configuration file, or None if not found.
        """
        # Check environment variable for explicit path
        env_config_path = os.getenv(cls._config_env_var)
        if env_config_path:
            file_path = Path(env_config_path).resolve()
            if file_path.is_file():
                logger.debug(f"Config file found via environment variable: {file_path}")
                return file_path
            logger.warning(f"Config file specified by {cls._config_env_var} not found: {file_path}")

        # Search predefined paths for config file names
        for path in cls._search_paths:
            for file_name in cls._config_file_names:
                file_path = (path / file_name).resolve()
                if file_path.is_file():
                    logger.debug(f"Config file found at: {file_path}")
                    return file_path
        logger.error(f"No configuration file found in search paths: {cls._search_paths} or via {cls._config_env_var} environment variable.")
        return None

    @classmethod
    def _load_settings(cls) -> AppSettings:
        """
        Internal method to load application settings from a config file and environment variables.

        This method attempts to load settings from a YAML file first, then overlays
        environment variables on top of them.

        Returns:
            AppSettings: An instance of AppSettings.

        Raises:
            ConfigError: If the configuration file cannot be found or loaded.
            ConfigValidationError: If the loaded configuration is invalid.
        """
        config_data: Dict[str, Any] = {}
        config_file_path = cls._find_config_file()

        if config_file_path:
            logger.info(f"Loading configuration from {config_file_path}")
            try:
                with open(config_file_path, 'r', encoding='utf-8') as f:
                    file_content = f.read()
                    if not file_content.strip():
                        logger.warning(f"Config file '{config_file_path}' is empty. Proceeding with environment variables and defaults.")
                    else:
                        config_data = yaml.safe_load(file_content) or {}
                if not isinstance(config_data, dict):
                    raise ConfigError(f"Configuration file '{config_file_path}' content is not a valid YAML dictionary.")
            except yaml.YAMLError as e:
                raise ConfigError(f"Error parsing YAML configuration file '{config_file_path}': {e}") from e
            except OSError as e:
                raise ConfigError(f"Error reading configuration file '{config_file_path}': {e}") from e
        else:
            logger.warning("No configuration file found. Attempting to load settings entirely from environment variables and defaults.")

        try:
            # Pydantic's BaseSettings automatically handles environment variables
            # overlaying values from the initial dictionary.
            settings = AppSettings.model_validate(config_data)
            return settings
        except ValidationError as e:
            raise ConfigValidationError(f"Configuration validation error: {e}\nRaw data: {config_data}") from e
        except Exception as e:
            raise ConfigError(f"An unexpected error occurred during settings loading: {e}") from e

# Example Usage (for testing purposes)
if __name__ == "__main__":
    # Create a dummy config file for demonstration
    dummy_config_content = """
    project_name: TestProject
    version: 1.0.0
    env: development
    debug_mode: true

    database:
      type: postgresql
      host: db.example.com
      port: 5432
      user: testuser
      name: test_db

    api:
      base_url: https://api.example.com
      timeout_seconds: 60

    logging:
      level: DEBUG
      log_file: logs/app.log
    """
    Path("config.yaml").write_text(dummy_config_content)
    # Also create a .env file for sensitive data
    Path(".env").write_text("""
    DB_PASSWORD=my_secret_db_password
    API_KEY=my_secret_api_key_12345
    """)

    try:
        print("\n--- Attempting to load settings for the first time ---")
        settings = ConfigManager.get_settings()
        print("\n--- Loaded Settings ---")
        print(f"Project Name: {settings.project_name}")
        print(f"Environment: {settings.env} (Is Production: {settings.is_production})")
        print(f"Debug Mode: {settings.debug_mode}")

        print("\nDatabase Settings:")
        print(f"  Type: {settings.database.type}")
        print(f"  URI: {settings.database.uri}")
        print(f"  User: {settings.database.user}")
        print(f"  Password (from ENV): {'*****' if settings.database.password else 'N/A'}")

        print("\nAPI Settings:")
        print(f"  Base URL: {settings.api.base_url}")
        print(f"  API Key (from ENV): {'*****' if settings.api.api_key else 'N/A'}")
        print(f"  Timeout: {settings.api.timeout_seconds} seconds")

        print("\nLogging Settings:")
        print(f"  Level: {settings.logging.level}")
        print(f"  Log File: {settings.logging.log_file}")
        print(f"  Format: {settings.logging.format}")

        # Test environment variable override (e.g., set APP_ENV=production)
        print("\n--- Testing ENV variable overrides ---")
        os.environ["APP_ENV"] = "production"
        os.environ["DB_PORT"] = "1234" # Override from env
        # Invalidate existing instance to force reload for demonstration
        ConfigManager._instance = None
        settings_reloaded = ConfigManager.get_settings()
        print("\n--- Reloaded Settings (with ENV overrides) ---")
        print(f"Environment: {settings_reloaded.env} (Is Production: {settings_reloaded.is_production})")
        print(f"DB Port (from ENV): {settings_reloaded.database.port}")

        # Test missing required field (should raise validation error)
        logger.info("\n--- Testing validation error (missing API base_url) ---")
        temp_broken_config = """
        project_name: BrokenConfig
        version: 1.0.0
        env: development
        database:
          type: sqlite
          name: broken
        api:
          api_key: some_key
        logging:
          level: INFO
        """
        Path("broken_config.yaml").write_text(temp_broken_config)
        os.environ["CODEPORI_CONFIG_PATH"] = str(Path("broken_config.yaml").resolve())
        ConfigManager._instance = None # Invalidate instance to force new load
        try:
            broken_settings = ConfigManager.get_settings()
        except ConfigValidationError as e:
            logger.error(f"Successfully caught expected validation error: {e.args[0].splitlines()[0]}")
        finally:
            # Clean up env variables used for testing
            if "APP_ENV" in os.environ: del os.environ["APP_ENV"]
            if "DB_PORT" in os.environ: del os.environ["DB_PORT"]
            if "CODEPORI_CONFIG_PATH" in os.environ: del os.environ["CODEPORI_CONFIG_PATH"]

    except ConfigError as e:
        logger.critical(f"Fatal Configuration Error: {e}")
    except Exception as e:
        logger.critical(f"An unexpected error occurred during config test: {e}", exc_info=True)
    finally:
        # Clean up dummy files
        if Path("broken_config.yaml").exists(): Path("broken_config.yaml").unlink()
        if Path(".env").exists(): Path(".env").unlink()
        if Path("config.yaml").exists(): Path("config.yaml").unlink()
