"""Auto-stubbed by CodePori: original content preserved below."""

def __codepori_stub__():
    pass

RAW_CONTENT = """import os
import subprocess
import logging
import re
from typing import Dict, Any, Optional, List, Type, Tuple

# Configure logging for demonstrative purposes. In a real project, this would be
# handled by a central logging configuration module, e.g., src.codepori.config.logging.
logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logging.getLogger('urllib3').setLevel(logging.WARNING) # Suppress noisy third-party logs

class PipelineContext:
    \"\"\"
    A context object to pass data and state throughout the pipeline stages.

    This class acts as a central data store for information generated or needed
    by different stages of the software development pipeline. It ensures that
    data is consistently available and mutable across the pipeline execution.

    Attributes:
        _data (Dict[str, Any]): A dictionary to store all context-specific data.
        _logger (logging.Logger): Logger instance for internal logging.
    \"\"\"
    def __init__(self):
        self._data: Dict[str, Any] = {}
        self._logger = logging.getLogger(self.__class__.__name__)
        self._logger.info("PipelineContext initialized.")

    def set_data(self, key: str, value: Any) -> None:
        \"\"\"Sets a value in the context under the given key.

        Args:
            key: The string key under which to store the value.
            value: The data to be stored. Can be of any type.
        \"\"\"
        self._data[key] = value
        self._logger.debug(f"Context data set: {key}={value}")

    def get_data(self, key: str, default: Any = None) -> Any:
        \"\"\"Retrieves a value from the context using the given key.

        Args:
            key: The string key for the data to retrieve.
            default: The default value to return if the key is not found.
                     Defaults to None.

        Returns:
            The value associated with the key, or the default value if the key
            is not present.
        \"\"\"
        value = self._data.get(key, default)
        self._logger.debug(f"Context data retrieved: {key}={value}")
        return value

    def has_data(self, key: str) -> bool:
        \"\"\"Checks if a key exists in the context.

        Args:
            key: The string key to check for existence.

        Returns:
            True if the key is in the context, False otherwise.
        \"\"\"
        return key in self._data

    def get_all_data(self) -> Dict[str, Any]:
        \"\"\"Returns a copy of all data stored in the context.

        Returns:
            A dictionary containing all key-value pairs from the context.
        \"\"\"
        return self._data.copy()

    def __str__(self) -> str:
        \"\"\"String representation of the PipelineContext."
        return f"PipelineContext with keys: {list(self._data.keys())}"


class ProcessExecutionError(Exception):
    \"\"\"Custom exception for process execution failures.

    This exception is raised when an external process fails to execute
    successfully (e.g., non-zero exit code when `check=True`, command not found,
    or timeout).

    Attributes:
        message (str): A descriptive error message.
        stdout (str): The standard output captured from the failed process.
        stderr (str): The standard error captured from the failed process.
        returncode (int): The exit code of the failed process.
    \"\"\"
    def __init__(self, message: str, stdout: str = "", stderr: str = "", returncode: int = 1):
        super().__init__(message)
        self.message = message
        self.stdout = stdout
        self.stderr = stderr
        self.returncode = returncode

    def __str__(self) -> str:
        \"\"\"String representation of the exception."
        return (f"{self.message} (Return Code: {self.returncode})\n"\
                f"--- STDOUT ---\n{self.stdout}\n"\
                f"--- STDERR ---\n{self.stderr}")


class ProcessUtility:
    \"\"\"
    Utility class for executing external processes.

    This class provides a robust way to run shell commands, capturing their
    output and handling various scenarios like timeouts and non-zero exit codes.
    It acts as a wrapper around Python's `subprocess` module.

    Attributes:
        _logger (logging.Logger): Logger instance for internal logging.
    \"\"\"
    def __init__(self):
        self._logger = logging.getLogger(self.__class__.__name__)
        self._logger.info("ProcessUtility initialized.")

    def run_command(self, command: List[str], cwd: Optional[str] = None,
                    timeout: Optional[int] = None, check: bool = True) -> Tuple[str, str, int]:
        \"\"\"
        Executes a shell command.

        This method wraps `subprocess.run` to provide standardized logging and
        error handling for external command execution.

        Args:
            command: A list of strings representing the command and its arguments.
                     Example: `['git', 'clone', 'repo_url']`.
            cwd: The current working directory for the command. If None, the
                 current process's working directory is used.
            timeout: Maximum time in seconds to wait for the command to complete.
                     If the command exceeds this time, a `ProcessExecutionError`
                     is raised.
            check: If True, raise `ProcessExecutionError` if the command returns
                   a non-zero exit code. If False, the return code is simply
                   returned and no error is raised for non-zero codes.

        Returns:
            A tuple containing (stdout, stderr, returncode). `stdout` and `stderr`
            are stripped strings.

        Raises:
            ProcessExecutionError: If `check` is True and the command fails,
                                   or if the command is not found, or if it times out.
        \"\"\"
        command_str = ' '.join(command)
        self._logger.info(f"Executing command: '{command_str}'")
        self._logger.debug(f"  - CWD: {cwd if cwd else os.getcwd()}")
        self._logger.debug(f"  - Timeout: {timeout}s")

        try:
            process = subprocess.run(
                command,
                cwd=cwd,
                capture_output=True,
                text=True, # Decode stdout/stderr as text
                check=False,  # We handle check manually to capture output on error
                timeout=timeout
            )
            stdout = process.stdout.strip()
            stderr = process.stderr.strip()
            returncode = process.returncode

            if check and returncode != 0:
                error_message = f"Command failed with exit code {returncode}. Command: '{command_str}'\n" \
                                f"STDOUT:\n{stdout}\nSTDERR:\n{stderr}"
                self._logger.error(error_message)
                raise ProcessExecutionError(error_message, stdout, stderr, returncode)
            elif returncode != 0:
                self._logger.warning(f"Command completed with non-zero exit code {returncode}. Command: '{command_str}'.")
                self._logger.debug(f"STDOUT: {stdout}")
                self._logger.debug(f"STDERR: {stderr}")
            else:
                self._logger.info(f"Command completed successfully: '{command_str}'.")

            return stdout, stderr, returncode
        except FileNotFoundError:
            msg = f"Command not found: '{command[0]}'. Please ensure it's in your system's PATH."
            self._logger.exception(msg)
            raise ProcessExecutionError(msg)
        except subprocess.TimeoutExpired as e:
            stdout_capture = e.stdout.decode('utf-8').strip() if e.stdout else ""
            stderr_capture = e.stderr.decode('utf-8').strip() if e.stderr else ""
            msg = f"Command timed out after {timeout} seconds: '{command_str}'"
            self._logger.exception(msg)
            # Common timeout exit code is 124 in some shells/contexts
            raise ProcessExecutionError(msg, stdout=stdout_capture, stderr=stderr_capture, returncode=124)
        except Exception as e:
            msg = f"An unexpected error occurred while running command '{command_str}': {e}"
            self._logger.exception(msg)
            raise ProcessExecutionError(msg)


class PipelineStage:
    \"\"\"
    Abstract base class for all pipeline stages.

    Each concrete pipeline stage should inherit from this class and implement
    the `execute` method, which defines the core logic for that stage.
    This class provides a common interface and basic logging for all stages.

    Attributes:
        _name (str): The name of the pipeline stage.
        _logger (logging.Logger): Logger instance for stage-specific logging.
    \"\"\"
    def __init__(self, name: str):
        self._name = name
        self._logger = logging.getLogger(self.__class__.__name__)
        self._logger.info(f"PipelineStage '{name}' initialized.")

    @property
    def name(self) -> str:
        \"\"\"Returns the name of the stage."
        return self._name

    def execute(self, context: PipelineContext) -> None:
        \"\"\"
        Abstract method to be implemented by concrete stages.

        This method defines the core logic of the pipeline stage. It takes a
        `PipelineContext` object as input, which can be used to read and write
        data relevant to the pipeline's execution.

        Args:
            context: The PipelineContext object providing access to shared data.

        Raises:
            NotImplementedError: If the method is not implemented by a subclass.
        \"\"\"
        raise NotImplementedError("Subclasses must implement the 'execute' method.")

    def _log_info(self, message: str, *args, **kwargs):
        \"\"\"Helper for info logging, prepending stage name."
        self._logger.info(f"[{self.name}] {message}", *args, **kwargs)

    def _log_warning(self, message: str, *args, **kwargs):
        \"\"\"Helper for warning logging, prepending stage name."
        self._logger.warning(f"[{self.name}] {message}", *args, **kwargs)

    def _log_error(self, message: str, *args, **kwargs):
        \"\"\"Helper for error logging, prepending stage name."
        self._logger.error(f"[{self.name}] {message}", *args, **kwargs)

    def _log_debug(self, message: str, *args, **kwargs):
        \"\"\"Helper for debug logging, prepending stage name."
        self._logger.debug(f"[{self.name}] {message}", *args, **kwargs)


class TestReport:
    \"\"\"
    A data class to encapsulate the results of a test run.

    This class provides a structured way to store and retrieve various metrics
    and outputs from a test execution, such as counts of passed/failed tests,
    stdout/stderr, and overall success status.

    Attributes:
        total_tests (int): Total number of tests discovered.
        passed_tests (int): Number of tests that passed.
        failed_tests (int): Number of tests that failed (assertion failures).
        skipped_tests (int): Number of tests that were skipped.
        error_tests (int): Number of tests that encountered errors (e.g., syntax errors, uncaught exceptions).
        stdout (str): Standard output captured from the test runner.
        stderr (str): Standard error captured from the test runner.
        raw_output (str): The complete raw output (stdout + stderr) from the test runner.
        success (bool): True if the test run was considered fully successful (no failures or errors).
        test_runner (str): The name of the test runner used (e.g., 'pytest', 'unittest').
    \"\"\"
    def __init__(self,
                 total_tests: int = 0,
                 passed_tests: int = 0,
                 failed_tests: int = 0,
                 skipped_tests: int = 0,
                 error_tests: int = 0,
                 stdout: str = "",
                 stderr: str = "",
                 raw_output: str = "",
                 success: bool = False,
                 test_runner: str = "unknown"):
        \"\"\"
        Initializes the TestReport.

        Args:
            total_tests: Total number of tests discovered.
            passed_tests: Number of tests that passed.
            failed_tests: Number of tests that failed (assertion failures).
            skipped_tests: Number of tests that were skipped.
            error_tests: Number of tests that encountered errors (e.g., syntax errors, uncaught exceptions).
            stdout: Standard output from the test runner.
            stderr: Standard error from the test runner.
            raw_output: The complete raw output from the test runner.
            success: True if all tests passed and no errors occurred, False otherwise.
            test_runner: The name of the test runner used (e.g., 'pytest', 'unittest').
        \"\"\"
        self.total_tests = total_tests
        self.passed_tests = passed_tests
        self.failed_tests = failed_tests
        self.skipped_tests = skipped_tests
        self.error_tests = error_tests
        self.stdout = stdout
        self.stderr = stderr
        self.raw_output = raw_output
        self.success = success
        self.test_runner = test_runner

    def to_dict(self) -> Dict[str, Any]:
        \"\"\"Converts the test report instance to a dictionary."
        return {
            "total_tests": self.total_tests,
            "passed_tests": self.passed_tests,
            "failed_tests": self.failed_tests,
            "skipped_tests": self.skipped_tests,
            "error_tests": self.error_tests,
            "success": self.success,
            "test_runner": self.test_runner,
            "stdout": self.stdout,
            "stderr": self.stderr,
            "raw_output": self.raw_output
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TestReport":
        \"\"\"Creates a TestReport instance from a dictionary."
        return cls(**data)

    def __str__(self) -> str:
        \"\"\"String representation of the test report for logging and display."
        status = "PASSED" if self.success else "FAILED"
        return (
            f"Test Report ({self.test_runner} - {status}):\n"
            f"  Total: {self.total_tests}, Passed: {self.passed_tests}, "
            f"Failed: {self.failed_tests}, Skipped: {self.skipped_tests}, "
            f"Errors: {self.error_tests}\n"
            f"  Success: {self.success}"
        )


class TestStage(PipelineStage):
    \"\"\"
    Implements the TestStage of the CoderPori pipeline.

    This stage is responsible for executing the test suite (e.g., via pytest)
    within the `./output/code` directory. It uses a `ProcessUtility` to run
    the test command, captures the test results, including failures and errors,
    and adds this detailed report to the pipeline context under the key 'test_report'.

    Attributes:
        _test_directory (str): The absolute path to the directory where tests should be executed.
        _test_command (List[str]): The base command and arguments to run the tests (e.g., ['pytest', '-v']).
        _process_utility (ProcessUtility): An instance of the utility for running external processes.
        _test_timeout (int): Maximum time in seconds to wait for tests to complete.
    \"\"\"

    DEFAULT_TEST_DIR = os.path.join(".", "output", "code")
    DEFAULT_TEST_COMMAND = ["pytest"]
    DEFAULT_TEST_TIMEOUT_SECONDS = 600  # 10 minutes
    TEST_REPORT_CONTEXT_KEY = "test_report"

    def __init__(self,
                 name: str = "TestStage",
                 test_directory: str = DEFAULT_TEST_DIR,
                 test_command: Optional[List[str]] = None,
                 test_timeout: int = DEFAULT_TEST_TIMEOUT_SECONDS,
                 process_utility: Optional[ProcessUtility] = None):
        \"\"\"
        Initializes the TestStage.

        Args:
            name: The name of this pipeline stage. Defaults to "TestStage".
            test_directory: The path to the directory containing the code and tests to be executed.
                            This path should be relative to the project root or a known base.
                            Defaults to './output/code'.
            test_command: The command (as a list of strings) to execute the test suite.
                          Defaults to ['pytest'].
            test_timeout: The maximum time in seconds to allow the test command to run.
                          Defaults to 600 seconds (10 minutes).
            process_utility: An optional pre-initialized ProcessUtility instance. If None,
                             a new instance will be created. This allows for dependency injection.
        \"\"\"
        super().__init__(name)
        self._test_directory = os.path.abspath(test_directory)
        self._test_command = test_command if test_command is not None else self.DEFAULT_TEST_COMMAND
        self._test_timeout = test_timeout
        self._process_utility = process_utility if process_utility else ProcessUtility()
        self._log_info(f"TestStage initialized with test_directory: '{self._test_directory}', "
                       f"command: '{' '.join(self._test_command)}', timeout: {self._test_timeout}s")

    def execute(self, context: PipelineContext) -> None:
        \"\"\"
        Executes the testing process within the specified test directory.

        This method orchestrates the test execution:
        1. It ensures the target test directory exists.
        2. It executes the configured test command using the `ProcessUtility`.
        3. It parses the raw output from the test runner to extract structured results.
        4. It creates a `TestReport` object and stores its dictionary representation
           in the `PipelineContext` under the key `TestStage.TEST_REPORT_CONTEXT_KEY`.
        5. It logs the outcome of the test run, indicating success or failure.

        Args:
            context: The PipelineContext object to store and retrieve data relevant to the pipeline.

        Raises:
            ProcessExecutionError: If the test command itself fails to execute due to system issues
                                   (e.g., command not found, permissions issue, timeout).
            Exception: For any other unexpected errors during TestStage execution or report parsing.
        \"\"\"
        self._log_info(f"Starting execution of {self.name} in directory: '{self._test_directory}'")

        if not os.path.isdir(self._test_directory):
            error_msg = f"Test directory '{self._test_directory}' does not exist or is not a directory. Cannot proceed with tests."
            self._log_error(error_msg)
            # Create a failed report to add to context even if directory is missing
            test_report = TestReport(
                success=False,
                raw_output=error_msg,
                test_runner=self._test_command[0] if self._test_command else "unknown"
            )
            context.set_data(self.TEST_REPORT_CONTEXT_KEY, test_report.to_dict())
            raise FileNotFoundError(error_msg) # Propagate a critical error

        try:
            self._log_debug(f"Executing command: {' '.join(self._test_command)} in '{self._test_directory}'")
            # We set check=False here because pytest returns non-zero (e.g., 1) for test failures, which is not
            # an execution error for the command itself, but a result that needs parsing.
            stdout, stderr, returncode = self._process_utility.run_command(
                command=self._test_command,
                cwd=self._test_directory,
                timeout=self._test_timeout,
                check=False
            )

            test_report = self._parse_test_output(
                stdout=stdout,
                stderr=stderr,
                returncode=returncode,
                test_runner=self._test_command[0] if self._test_command else "unknown"
            )

            context.set_data(self.TEST_REPORT_CONTEXT_KEY, test_report.to_dict())
            self._log_info(f"Test execution completed. Report: {test_report}")

            if not test_report.success:
                self._log_warning(f"Tests reported failures or errors. Test run was not fully successful.")
            else:
                self._log_info("All tests passed successfully.")

        except ProcessExecutionError as e:
            self._log_error(f"Failed to execute test command: {e.message}")
            test_report = TestReport(
                success=False,
                stdout=e.stdout,
                stderr=e.stderr,
                raw_output=f"Process failed with exit code {e.returncode}. Message: {e.message}",
                test_runner=self._test_command[0] if self._test_command else "unknown"
            )
            context.set_data(self.TEST_REPORT_CONTEXT_KEY, test_report.to_dict())
            raise # Re-raise to indicate a critical stage failure to the pipeline orchestrator

        except Exception as e:
            self._log_error(f"An unexpected error occurred during TestStage execution: {e}", exc_info=True)
            test_report = TestReport(
                success=False,
                raw_output=f"An unexpected error occurred during TestStage: {type(e).__name__}: {e}",
                test_runner=self._test_command[0] if self._test_command else "unknown"
            )
            context.set_data(self.TEST_REPORT_CONTEXT_KEY, test_report.to_dict())
            raise # Re-raise for pipeline management to catch

    def _parse_test_output(self, stdout: str, stderr: str, returncode: int, test_runner: str) -> TestReport:
        \"\"\"
        Parses the combined output from the test runner to create a TestReport.

        This method currently implements a basic parser for pytest-like output summaries.
        It aims to extract counts for total, passed, failed, skipped, and error tests.
        The overall success of the test run is determined based on these counts and the
        return code of the test command.

        Args:
            stdout: The standard output captured from the test command.
            stderr: The standard error captured from the test command.
            returncode: The exit code of the test command.
            test_runner: The name of the test runner (e.g., 'pytest').

        Returns:
            A TestReport object populated with parsed data and success status.
        \"\"\"
        self._log_debug(f"Parsing test output for {test_runner} (return code: {returncode}).")
        self._log_debug(f"STDOUT preview (first 500 chars): {stdout[:500]}...")
        self._log_debug(f"STDERR preview (first 500 chars): {stderr[:500]}...")

        total = 0
        passed = 0
        failed = 0
        skipped = 0
        errors = 0
        success = False

        raw_output = stdout + "\n" + stderr

        # Regex for pytest summary line. Example: "=== 1 passed, 1 failed, 2 skipped, 1 error in 0.50s ==="
        # This regex attempts to capture the numbers preceding keywords like 'passed', 'failed', etc.
        summary_pattern = re.compile(r"(\d+)\s+(passed|failed|skipped|error)")

        # Search for summary line in the last lines of stdout/stderr, as it usually appears at the end
        lines_to_check = (stdout + '\n' + stderr).splitlines()[-20:] # Check last 20 lines for efficiency

        for line in reversed(lines_to_check):
            line = line.strip()
            if "===" in line and ("in " in line or "tests " in line): # Heuristic for a pytest-like summary line
                matches = summary_pattern.findall(line)
                if not matches and "no tests ran" in line.lower():
                    self._log_debug("Pytest reported 'no tests ran'.")
                    # If no tests ran, and return code is 0 or 5, it's a success for the runner.
                    # Counts will remain 0.
                    if returncode in [0, 5]: # pytest returns 5 for no tests found
                        success = True
                    break

                for count_str, type_str in matches:
                    try:
                        count = int(count_str)
                        if "passed" in type_str:
                            passed += count
                        elif "failed" in type_str:
                            failed += count
                        elif "skipped" in type_str:
                            skipped += count
                        elif "error" in type_str:
                            errors += count
                    except ValueError:
                        self._log_warning(f"Could not parse count '{count_str}' from line: '{line}'")
                break # Found and processed the summary line

        total = passed + failed + skipped + errors

        # Determine overall success based on parsed counts and pytest-specific return codes
        # Pytest return codes:
        #   0: All tests passed
        #   1: Tests failed
        #   2: Internal error or usage error
        #   5: No tests were collected
        if returncode == 0 and failed == 0 and errors == 0:
            success = True  # Perfect run, all tests passed and no errors
        elif returncode == 5: # Pytest specific: No tests were collected
            # This can be considered a successful execution of the runner itself,
            # but might indicate an issue if tests were expected to exist.
            # We'll consider it successful unless explicitly told otherwise.
            success = True
        else: # Any other non-zero return code (1 for test failures, 2 for internal errors etc.)
            success = False
            # If returncode indicates an internal error (e.g., code 2) but our parser didn't catch specific 'errors',
            # we should still ensure the error count reflects this critical issue.
            if returncode == 2 and errors == 0: # Pytest internal error
                errors = 1  # Force an error count to signify runner's error
                self._log_warning(f"Pytest returned code 2 (internal error) but no errors parsed. Forcing error count.")

        # Final check: If any explicit failures or errors were parsed, the run is NOT successful.
        if failed > 0 or errors > 0:
            success = False

        report = TestReport(
            total_tests=total,
            passed_tests=passed,
            failed_tests=failed,
            skipped_tests=skipped,
            error_tests=errors,
            stdout=stdout,
            stderr=stderr,
            raw_output=raw_output,
            success=success,  # Use the computed success
            test_runner=test_runner
        )
        self._log_debug(f"Parsed TestReport: {report.to_dict()}")
        return report
"""
