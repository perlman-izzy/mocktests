import logging
from typing import Any, Dict, Optional

# Note: These imports assume the existence of corresponding modules and classes
# within the project structure, as is standard in a modular application.
from src.codepori.context import Context
from src.codepori.llm.llm_client import LLMClient
from src.codepori.stages.base_stage import PipelineStage


class RepairExecutionError(Exception):
    """Custom exception for failures during the code repair stage."""

    def __init__(self, message: str):
        """Initializes the RepairExecutionError.

        Args:
            message (str): The error message describing the failure.
        """
        super().__init__(message)


class RepairStage(PipelineStage):
    """A pipeline stage to conditionally repair code based on validation failures.

    This stage inspects the pipeline context for linting errors or test failures.
    If any are found, it formulates a detailed prompt for an LLM client,
    which includes the original code and the specific errors, to generate a
    corrected version. The stage manages a retry mechanism by tracking attempts
    within the context object. If the number of attempts exceeds a configured
    limit, it raises an exception to halt the pipeline, preventing infinite loops.

    Attributes:
        llm_client (LLMClient): The client for LLM interactions.
        max_retries (int): The maximum number of repair attempts allowed.
        logger (logging.Logger): The logger for this stage.
    """

    DEFAULT_MAX_RETRIES = 3

    def __init__(self, llm_client: LLMClient, stage_config: Dict[str, Any]):
        """Initializes the RepairStage with an LLM client and configuration.

        Args:
            llm_client (LLMClient): An instance of a class that adheres to the
                LLMClient interface, used for generating code fixes.
            stage_config (Dict[str, Any]): Configuration for this stage.
                It should contain 'max_retries' (int) to override the default.

        Raises:
            TypeError: If `llm_client` is not a valid LLMClient instance.
        """
        super().__init__(stage_config)
        if not isinstance(llm_client, LLMClient):
            raise TypeError("llm_client must be an instance of LLMClient")

        self.llm_client = llm_client
        self.max_retries = self.stage_config.get("max_retries", self.DEFAULT_MAX_RETRIES)
        self.logger = logging.getLogger(__name__)
        self.logger.info(f"RepairStage initialized with max_retries: {self.max_retries}")

    def _has_errors(self, context: Context) -> bool:
        """Checks the context for evidence of linting or testing failures.

        This method expects the context to contain 'linting_results' and
        'test_results' dictionaries, each with a 'passed' boolean key.

        Args:
            context (Context): The current pipeline context.

        Returns:
            bool: True if there are any reported errors, False otherwise.
        """
        linting_results = context.get("linting_results")
        test_results = context.get("test_results")

        linting_failed = linting_results and not linting_results.get("passed", True)
        testing_failed = test_results and not test_results.get("passed", True)

        if linting_failed:
            self.logger.debug("Linting failure detected in context.")
        if testing_failed:
            self.logger.debug("Test failure detected in context.")

        return linting_failed or testing_failed

    def _format_errors(self, context: Context) -> str:
        """Formats linting and test errors into a single, readable string.

        This string is used as part of the prompt for the LLM.

        Args:
            context (Context): The current pipeline context holding the error details.

        Returns:
            str: A formatted string containing all error details, or a default
                 message if no specific output is available.
        """
        error_messages = []
        linting_results = context.get("linting_results")
        if linting_results and not linting_results.get("passed", True):
            error_messages.append("--- LINTING ERRORS ---")
            error_messages.append(
                linting_results.get("output", "No linting output available.").strip()
            )

        test_results = context.get("test_results")
        if test_results and not test_results.get("passed", True):
            if error_messages:
                error_messages.append("\n")  # Add space between sections
            error_messages.append("--- TEST FAILURES ---")
            error_messages.append(
                test_results.get("output", "No test output available.").strip()
            )

        if not error_messages:
            return "No specific errors found, but a failure was indicated in the context."

        return "\n".join(error_messages)

    def _create_repair_prompt(
        self, code: str, errors: str, file_path: Optional[str]
    ) -> str:
        """Creates a detailed, structured prompt for the LLM to repair the code.

        Args:
            code (str): The source code that needs to be repaired.
            errors (str): The formatted string of linting and test errors.
            file_path (Optional[str]): The path to the file being repaired.

        Returns:
            str: The fully constructed prompt ready to be sent to the LLM.
        """
        prompt = f"""
You are an expert Python software engineer specializing in code quality and correctness.
You are tasked with fixing a Python file that has failed automated checks.

The file is located at: '{file_path or "unknown file"}'

Analyze the provided code and the associated errors from the linting and testing stages. Your goal is to produce a corrected version of the entire file that resolves these issues.

CRITICAL INSTRUCTIONS:
1.  Your response must contain ONLY the complete, corrected Python code for the file.
2.  Do NOT include any surrounding text, explanations, apologies, or markdown code fences like ```python ... ```.
3.  Ensure your corrected code directly addresses all the errors listed.
4.  Preserve the original logic and functionality unless the errors explicitly point to a bug that needs fixing.
5.  Follow PEP 8 guidelines and maintain a high standard of code quality.
6.  The output must be a single block of code that can be directly written back to the file.

--- ORIGINAL CODE ---

{code}

--- ERRORS AND FAILURES ---

{errors}

--- CORRECTED CODE ---
"""
        return prompt.strip()

    def execute(self, context: Context) -> Context:
        """Executes the repair logic for the stage.

        This method checks for errors in the context. If errors are found, it
        manages a retry loop. In each attempt, it generates a prompt for an LLM
        to fix the code, updates the context with the proposed fix, and sets a
        flag (`repair_attempted`) for the pipeline orchestrator. If the retry
        limit is exceeded, it raises a `RepairExecutionError`.

        Args:
            context (Context): The pipeline context containing the code, test
                results, and linting results.

        Returns:
            Context: The updated pipeline context, possibly with new code.

        Raises:
            RepairExecutionError: If the maximum number of repair retries is exhausted.
            ValueError: If the context is missing 'current_code'.
        """
        self.logger.info("--- Executing Repair Stage ---")
        context.set("repair_attempted", False)

        if not self._has_errors(context):
            self.logger.info("No errors found. Repair stage is skipping its logic.")
            context.set("repair_attempts", 0)  # Reset counter on a clean pass
            return context

        repair_attempts = context.get("repair_attempts", 0)

        if repair_attempts >= self.max_retries:
            error_details = self._format_errors(context)
            failure_message = (
                f"Maximum repair retries ({self.max_retries}) exceeded. "
                f"Code could not be fixed. Last seen errors:\n{error_details}"
            )
            self.logger.error(failure_message)
            raise RepairExecutionError(failure_message)

        current_attempt = repair_attempts + 1
        context.set("repair_attempts", current_attempt)

        self.logger.warning(
            f"Errors detected. Initiating repair attempt {current_attempt} of {self.max_retries}."
        )

        current_code = context.get("current_code")
        if not isinstance(current_code, str):
            raise ValueError("Context must contain 'current_code' as a string.")

        file_path = context.get("file_path")
        formatted_errors = self._format_errors(context)

        self.logger.debug(f"Formatted errors for repair prompt:\n{formatted_errors}")

        repair_prompt = self._create_repair_prompt(
            code=current_code, errors=formatted_errors, file_path=file_path
        )

        try:
            self.logger.info("Sending repair request to LLM client.")
            repaired_code = self.llm_client.generate_code(repair_prompt)
            self.logger.info("Received repair suggestion from LLM client.")

            if not repaired_code or not repaired_code.strip():
                self.logger.warning(
                    "LLM returned an empty response. Discarding suggestion. "
                    "The pipeline will retry with the original faulty code."
                )
                return context

            context.set("current_code", repaired_code)
            context.set("repair_attempted", True)
            self.logger.info(
                f"Completed repair attempt {current_attempt}. Context updated with new code."
            )

        except Exception as e:
            self.logger.error(
                f"An unexpected error occurred while calling the LLM client: {e}",
                exc_info=True,
            )
            # An LLM error is treated as a failed attempt, but we don't crash.
            # The retry counter has already been incremented, so the orchestrator
            # can decide to loop again. We leave the code unchanged.

        self.logger.info("--- Finished Repair Stage ---")
        return context
