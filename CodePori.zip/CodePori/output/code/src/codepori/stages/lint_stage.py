# FIXME(auto-comment): F401", "message": "`os` imported but unused",
        #  "location": {"row": 1, "column": 1},
        #  "filename": "/path/to/file.py",
        #  "rule": {"name": "UnusedImport", "code": "F401", "linter": "pyflakes
