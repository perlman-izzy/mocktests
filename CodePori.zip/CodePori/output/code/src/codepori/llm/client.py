import abc
import os
import logging
import time
from typing import Any, Dict, Optional, Type
import httpx
from tenacity import retry, wait_exponential, stop_after_attempt, retry_if_exception_type

# Configure logging for the module
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# --- Custom Exception Classes for LLM Client Operations ---
class LLMClientError(Exception):
    """Base exception for all errors originating from LLM client operations."""
    pass

class LLMServiceUnavailableError(LLMClientError):
    """Raised when the LLM service is temporarily unavailable or returns a server-side error.

    This typically indicates issues like 5xx HTTP status codes or connection failures.
    """
    pass

class LLMRequestError(LLMClientError):
    """Raised for issues related to the LLM request itself, such as invalid prompts, 
    unsupported parameters, or bad model IDs.

    Corresponds to client-side errors (e.g., 4xx HTTP status codes, excluding authentication/rate-limit).
    """
    pass

class LLMAuthenticationError(LLMClientError):
    """Raised when authentication with the LLM service fails due to invalid or missing credentials.

    Corresponds to 401 Unauthorized or similar authentication-related errors.
    """
    pass

class LLMRateLimitError(LLMClientError):
    """Raised when the LLM service indicates that a rate limit has been exceeded.

    Corresponds to 429 Too Many Requests HTTP status codes.
    """
    pass


# --- Abstract Base Class for LLM Clients ---
class LLMClient(abc.ABC):
    """
    Abstract base class defining the interface for interacting with Large Language Model services.

    All concrete LLM client implementations must inherit from this class and implement
    its abstract methods to ensure consistent interaction patterns.
    """

    @abc.abstractmethod
    def query(self, prompt: str, **kwargs: Any) -> str:
        """
        Sends a text prompt to the LLM and retrieves the generated response.

        Args:
            prompt: The primary text prompt to send to the LLM.
            **kwargs: Additional keyword arguments that can be passed to the underlying
                      LLM service API (e.g., `model`, `temperature`, `max_tokens`,
                      `system_message`). These arguments are client-specific and should
                      be documented by concrete implementations.

        Returns:
            The generated text response from the LLM.

        Raises:
            LLMClientError: A general exception for any error during the query process.
                            Specific subclasses (e.g., LLMAuthenticationError, LLMRateLimitError)
                            should be raised for more granular error handling.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_model_capabilities(self, model_name: str) -> Dict[str, Any]:
        """
        Retrieves a dictionary of capabilities or metadata for a specified LLM model.

        This can include information like context window size, supported features (e.g., vision),
        training data cut-off dates, or pricing tier.

        Args:
            model_name: The identifier of the LLM model for which capabilities are requested.

        Returns:
            A dictionary containing various capabilities or metadata about the model.

        Raises:
            LLMClientError: If the model is not found, or if an error occurs while
                            fetching its capabilities.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def get_supported_models(self) -> Dict[str, str]:
        """
        Retrieves a list of all model IDs and their user-friendly names supported by this client.

        Returns:
            A dictionary where keys are the technical model IDs (e.g., 'gpt-3.5-turbo')
            and values are human-readable display names (e.g., 'GPT-3.5 Turbo').

        Raises:
            LLMClientError: If an error occurs while attempting to fetch the list of supported models.
        """
        raise NotImplementedError


# --- Concrete OpenAI Client Implementation ---
# Attempt to import OpenAI specific libraries. This allows the module to be imported
# even if 'openai' is not installed, but raises an error if OpenAIClient is instantiated.
try:
    import openai
    from openai import OpenAI, APIError, RateLimitError, AuthenticationError as OpenAIAuthError, APIConnectionError
    logger.info("OpenAI library imported successfully. OpenAIClient functionality enabled.")
except ImportError:
    openai = None
    OpenAI = None
    APIError = None
    RateLimitError = None
    OpenAIAuthError = None
    APIConnectionError = None
    logger.warning("OpenAI library not found. OpenAIClient functionality will be unavailable.")


class OpenAIClient(LLMClient):
    """
    Concrete implementation of `LLMClient` for interacting with OpenAI's API services.

    This client handles API authentication, request execution, and robust error handling,
    including retries for transient issues like rate limits or connection problems.
    """
    DEFAULT_MODEL = "gpt-3.5-turbo"
    # Tenacity retry settings
    MAX_RETRIES = 7
    INITIAL_RETRY_DELAY = 1  # seconds

    def __init__(self, api_key: Optional[str] = None, model: str = DEFAULT_MODEL, 
                 timeout: int = 60, organization: Optional[str] = None):
        """
        Initializes the OpenAIClient.

        Args:
            api_key: Your OpenAI API key. If None, the client attempts to read it from
                     the `OPENAI_API_KEY` environment variable.
            model: The default OpenAI model to use for queries if not specified per-query.
                   Examples: "gpt-4", "gpt-3.5-turbo", "gpt-4o".
            timeout: The maximum time in seconds to wait for an API response. This applies
                     to the HTTP connection and read timeouts.
            organization: The OpenAI organization ID to use for requests, if applicable.

        Raises:
            ImportError: If the `openai` library is not installed.
            LLMAuthenticationError: If the API key is not provided and cannot be found
                                    in environment variables.
        """
        if openai is None:
            raise ImportError("The 'openai' library is not installed. Please install it with 'pip install openai'.")

        self._api_key = api_key or os.getenv("OPENAI_API_KEY")
        if not self._api_key:
            raise LLMAuthenticationError(
                "OpenAI API key not provided and OPENAI_API_KEY environment variable not set."
            )

        # Initialize the OpenAI client with specified timeout and organization
        self._client = OpenAI(api_key=self._api_key, 
                              timeout=httpx.Timeout(timeout, connect=5.0), 
                              organization=organization)
        self._model = model
        logger.info(f"OpenAIClient initialized. Default model: '{self._model}'. Timeout: {timeout}s.")

    @retry(
        wait=wait_exponential(multiplier=INITIAL_RETRY_DELAY, min=1, max=60),
        stop=stop_after_attempt(MAX_RETRIES),
        retry=(
            retry_if_exception_type(RateLimitError) |
            retry_if_exception_type(APIConnectionError) |
            retry_if_exception_type(httpx.ConnectError) |
            retry_if_exception_type(httpx.ReadTimeout) |
            retry_if_exception_type(httpx.ConnectTimeout)
        ),
        reraise=True  # Re-raise the last exception after all retries are exhausted
    )
    def _execute_chat_completion(self, messages: list, model: str, temperature: float, 
                                 max_tokens: Optional[int] = None, 
                                 top_p: Optional[float] = None, 
                                 frequency_penalty: Optional[float] = None,
                                 presence_penalty: Optional[float] = None,
                                 seed: Optional[int] = None, 
                                 **kwargs: Any) -> str:
        """
        Internal method to execute the OpenAI chat completion API call with built-in retry logic.

        This method wraps the actual `openai.chat.completions.create` call with `tenacity`
        for robust handling of transient network issues or rate limits.

        Args:
            messages: A list of message dictionaries (e.g., [{'role': 'user', 'content': 'prompt'}]).
            model: The specific OpenAI model identifier to use for this call (e.g., "gpt-3.5-turbo").
            temperature: Sampling temperature to use. Higher values make output more random.
            max_tokens: The maximum number of tokens to generate in the completion.
            top_p: An alternative to sampling with temperature, called nucleus sampling.
            frequency_penalty: Positive values penalize new tokens based on their existing
                               frequency in the text so far, decreasing the model's likelihood
                               to repeat the same line verbatim.
            presence_penalty: Positive values penalize new tokens based on whether they appear
                              in the text so far, increasing the model's likelihood to talk
                              about new topics.
            seed: If specified, the system will make a best effort to sample deterministically,
                  such that repeated requests with the same seed and parameters should return
                  the same result.
            **kwargs: Additional parameters to pass directly to OpenAI's API.

        Returns:
            The content of the AI's response message as a string.

        Raises:
            OpenAIAuthError: If authentication fails (wrapped by LLMAuthenticationError).
            RateLimitError: If rate limits are exceeded after all retries (wrapped by LLMRateLimitError).
            APIConnectionError: For network or connection related errors (wrapped by LLMServiceUnavailableError).
            APIError: For other API-specific errors (wrapped by LLMRequestError or LLMServiceUnavailableError).
            httpx.TimeoutException: If the HTTP request times out (wrapped by LLMServiceUnavailableError).
            LLMClientError: For any other unexpected errors.
        """
        try:
            logger.debug(f"Attempting OpenAI chat completion for model '{model}' with {len(messages)} messages.")

            # Prepare optional parameters for the API call
            api_params = {
                "model": model,
                "messages": messages,
                "temperature": temperature,
            }
            if max_tokens is not None: api_params["max_tokens"] = max_tokens
            if top_p is not None: api_params["top_p"] = top_p
            if frequency_penalty is not None: api_params["frequency_penalty"] = frequency_penalty
            if presence_penalty is not None: api_params["presence_penalty"] = presence_penalty
            if seed is not None: api_params["seed"] = seed

            # Merge any additional kwargs provided by the caller
            api_params.update(kwargs)

            response = self._client.chat.completions.create(**api_params)
            content = response.choices[0].message.content
            if content is None:
                logger.warning("OpenAI API returned a response with None content. Returning empty string.")
                return ""
            return content
        except OpenAIAuthError as e:
            logger.error(f"OpenAI Authentication Error: {e.args[0] if e.args else str(e)}")
            raise LLMAuthenticationError(f"Authentication with OpenAI failed: {e.args[0] if e.args else str(e)}") from e
        except RateLimitError as e:
            logger.warning(f"OpenAI Rate Limit Error (will retry): {e.args[0] if e.args else str(e)}")
            raise LLMRateLimitError(f"OpenAI rate limit exceeded: {e.args[0] if e.args else str(e)}") from e
        except APIConnectionError as e:
            logger.error(f"OpenAI API Connection Error (will retry): {e.args[0] if e.args else str(e)}")
            raise LLMServiceUnavailableError(f"OpenAI API connection failed: {e.args[0] if e.args else str(e)}") from e
        except APIError as e:
            logger.error(f"OpenAI API Error: Type={e.type}, Code={e.code}, Message={e.message}")
            if e.code == "model_not_found" or "invalid_request_error" in e.type or e.http_status == 400:
                raise LLMRequestError(f"Invalid request to OpenAI API: {e.message}") from e
            elif e.http_status >= 500:
                raise LLMServiceUnavailableError(f"OpenAI service error: {e.message} (HTTP {e.http_status})") from e
            else:
                raise LLMClientError(f"OpenAI API general error: {e.message}") from e
        except (httpx.TimeoutException, httpx.ConnectError, httpx.ReadTimeout) as e:
            logger.error(f"OpenAI HTTP Communication Error (will retry): {e}")
            raise LLMServiceUnavailableError(f"OpenAI request timed out or connection failed: {e}") from e
        except Exception as e:
            logger.exception(f"An unexpected error occurred during OpenAI API call: {e}")
            raise LLMClientError(f"An unexpected error occurred during OpenAI API call: {e}") from e

    def query(self, prompt: str, system_message: Optional[str] = None, model: Optional[str] = None, 
              temperature: float = 0.7, max_tokens: Optional[int] = None, 
              top_p: Optional[float] = None, frequency_penalty: Optional[float] = None,
              presence_penalty: Optional[float] = None, seed: Optional[int] = None, 
              **kwargs: Any) -> str:
        """
        Sends a query to the OpenAI LLM and returns the response.

        This method constructs the messages list according to OpenAI's chat completion format
        and invokes the internal `_execute_chat_completion` method with retry logic.

        Args:
            prompt: The text prompt (user's input) to send to the LLM.
            system_message: An optional system message to guide the LLM's overall behavior
                            or persona. This message is usually set once at the beginning
                            of a conversation.
            model: Overrides the default model specified during initialization for this
                   specific query. If None, the client's default model is used.
            temperature: Sampling temperature for the query. Lower values (e.g., 0.2) make
                         the output more deterministic and focused. Higher values (e.g., 0.9)
                         make it more creative and diverse. Defaults to 0.7.
            max_tokens: The maximum number of tokens to generate in the completion. If None,
                        the model's default maximum will be used. This helps control response length.
            top_p: An alternative to sampling with temperature, called nucleus sampling,
                   where the model considers the results of the tokens with `top_p` probability mass.
                   So 0.1 means only the tokens comprising the top 10% probability mass are considered.
            frequency_penalty: Number between -2.0 and 2.0. Positive values penalize new tokens
                               based on their existing frequency in the text so far.
            presence_penalty: Number between -2.0 and 2.0. Positive values penalize new tokens
                              based on whether they appear in the text so far.
            seed: If specified, the system will make a best effort to sample deterministically,
                  such that repeated requests with the same seed and parameters should return
                  the same result.
            **kwargs: Additional keyword arguments to pass directly to OpenAI's chat completions API
                      that are not explicitly listed above (e.g., `stop`, `logit_bias`).

        Returns:
            The generated text response from the LLM.

        Raises:
            LLMClientError: If the `openai` library is not installed, or any error occurs
                            during the API call. Specific subclasses will be raised for
                            authentication, rate limits, request issues, or service unavailability.
        """
        if openai is None:
            raise LLMClientError("OpenAIClient cannot query as OpenAI library is not installed.")

        messages = []
        if system_message:
            messages.append({"role": "system", "content": system_message})
        messages.append({"role": "user", "content": prompt})

        effective_model = model if model else self._model

        try:
            return self._execute_chat_completion(
                messages=messages,
                model=effective_model,
                temperature=temperature,
                max_tokens=max_tokens,
                top_p=top_p,
                frequency_penalty=frequency_penalty,
                presence_penalty=presence_penalty,
                seed=seed,
                **kwargs
            )
        except (LLMAuthenticationError, LLMRateLimitError, LLMRequestError, LLMServiceUnavailableError) as e:
            logger.error(f"Failed to query OpenAI due to specific error: {e.__class__.__name__} - {e}")
            raise  # Re-raise the specific handled exception
        except Exception as e:
            logger.exception(f"An unhandled error occurred during query to OpenAI: {e}")
            raise LLMClientError(f"An unexpected error occurred during OpenAI query: {e}") from e

    def get_model_capabilities(self, model_name: str) -> Dict[str, Any]:
        """
        Retrieves capabilities or metadata for a specific OpenAI model.

        Since OpenAI's API does not expose a direct 'capabilities' endpoint in a structured
        way (beyond basic model listing), this method provides general information for
        commonly used models based on known specifications and falls back to listing
        available models via API if a direct match isn't found.

        Args:
            model_name: The name of the LLM model (e.g., "gpt-4", "gpt-3.5-turbo").

        Returns:
            A dictionary containing capabilities or metadata.

        Raises:
            LLMClientError: If the model is not recognized or an error occurs during API access.
            LLMRequestError: If the specified model is not found via API introspection.
        """
        if openai is None:
            raise LLMClientError("OpenAIClient cannot get model capabilities as OpenAI library is not installed.")

        # A pre-defined mapping for common models with known capabilities.
        # This should be updated as OpenAI releases new models or changes capabilities.
        known_capabilities = {
            "gpt-4": {
                "name": "GPT-4",
                "description": "Our most capable model, designed for complex tasks.",
                "context_window_tokens": 8192,
                "max_output_tokens": 4096,
                "supports_vision": False,
                "training_data_cut_off": "September 2021 (Approx)",
                "pricing_input_per_million_tokens": 30.00, # Example pricing, verify with OpenAI
                "pricing_output_per_million_tokens": 60.00  # Example pricing, verify with OpenAI
            },
            "gpt-4-turbo": {
                "name": "GPT-4 Turbo",
                "description": "Improved GPT-4 with a larger context window and more up-to-date knowledge.",
                "context_window_tokens": 128000,
                "max_output_tokens": 4096,
                "supports_vision": True,
                "training_data_cut_off": "December 2023 (Approx)",
                "pricing_input_per_million_tokens": 10.00,
                "pricing_output_per_million_tokens": 30.00
            },
            "gpt-4o": {
                "name": "GPT-4o",
                "description": "Our new flagship model that can reason across audio, vision, and text in real time.",
                "context_window_tokens": 128000,
                "max_output_tokens": 4096,
                "supports_vision": True,
                "supports_audio_input": True,
                "supports_audio_output": True,
                "training_data_cut_off": "October 2023 (Approx)",
                "pricing_input_per_million_tokens": 5.00,
                "pricing_output_per_million_tokens": 15.00
            },
            "gpt-3.5-turbo": {
                "name": "GPT-3.5 Turbo",
                "description": "Our fastest and most cost-effective model, suitable for many everyday tasks.",
                "context_window_tokens": 4096,
                "max_output_tokens": 4096,
                "supports_vision": False,
                "training_data_cut_off": "September 2021 (Approx)",
                "pricing_input_per_million_tokens": 0.50,
                "pricing_output_per_million_tokens": 1.50
            },
            "gpt-3.5-turbo-16k": {
                "name": "GPT-3.5 Turbo 16k",
                "description": "GPT-3.5 Turbo with an extended context window for longer conversations.",
                "context_window_tokens": 16384,
                "max_output_tokens": 4096,
                "supports_vision": False,
                "training_data_cut_off": "September 2021 (Approx)",
                "pricing_input_per_million_tokens": 3.00,
                "pricing_output_per_million_tokens": 4.00
            }
        }

        # Check if the model is in our known capabilities map first
        if model_name in known_capabilities:
            logger.debug(f"Found known capabilities for model: {model_name}")
            return known_capabilities[model_name]

        # If not found in known map, attempt to fetch from OpenAI's models endpoint
        # This can be slower and is less detailed for capabilities like context window.
        try:
            logger.info(f"Model '{model_name}' not in known capabilities. Attempting to fetch from OpenAI API.")
            model_list = self._client.models.list()
            for model_data in model_list.data:
                if model_data.id == model_name:
                    # Extract basic information available from the models API
                    return {
                        "name": model_data.id,
                        "description": f"Dynamically retrieved details for model {model_data.id}.",
                        "owned_by": model_data.owned_by,
                        "created_at": model_data.created,
                        "object_type": model_data.object
                        # Add other fields from model_data if they are consistently useful
                    }
            raise LLMRequestError(f"Model '{model_name}' not found or recognized by OpenAI API.")
        except APIError as e:
            logger.error(f"Error fetching model list from OpenAI for capabilities: {e.message}")
            raise LLMClientError(f"Could not retrieve capabilities for model '{model_name}': {e.message}") from e
        except Exception as e:
            logger.exception(f"An unexpected error occurred while fetching capabilities for model '{model_name}': {e}")
            raise LLMClientError(f"Failed to get capabilities for model '{model_name}': {e}") from e

    def get_supported_models(self) -> Dict[str, str]:
        """
        Retrieves a list of supported OpenAI model IDs and their display names by querying the API.

        Returns:
            A dictionary where keys are model IDs (e.g., "gpt-3.5-turbo") and values are display names.

        Raises:
            LLMClientError: If an error occurs while fetching supported models from the OpenAI API.
        """
        if openai is None:
            raise LLMClientError("OpenAIClient cannot get supported models as OpenAI library is not installed.")
        try:
            logger.info("Fetching supported models from OpenAI API...")
            model_list = self._client.models.list()
            # Filter for common chat models or relevant models as needed. For simplicity, include all 'gpt' models.
            supported_models = {model.id: model.id for model in model_list.data if model.id.startswith("gpt")}
            logger.info(f"Successfully retrieved {len(supported_models)} supported models from OpenAI.")
            return supported_models
        except APIError as e:
            logger.error(f"Error fetching supported models from OpenAI: {e.message}")
            raise LLMClientError(f"Could not retrieve supported models from OpenAI: {e.message}") from e
        except Exception as e:
            logger.exception(f"An unexpected error occurred while fetching supported models from OpenAI: {e}")
            raise LLMClientError(f"Failed to get supported models from OpenAI: {e}") from e


# --- Mock LLM Client Implementation for Testing ---
class MockLLMClient(LLMClient):
    """
    Mock implementation of `LLMClient` for testing and development purposes.

    This client allows simulating LLM responses, delays, and errors without making
    actual network calls to external LLM services, making it ideal for unit tests
    and offline development.
    """

    def __init__(self, predefined_responses: Optional[Dict[str, str]] = None,
                 delay_seconds: float = 0.01, simulate_error: Optional[Type[LLMClientError]] = None,
                 mock_capabilities: Optional[Dict[str, Dict[str, Any]]] = None,
                 mock_supported_models: Optional[Dict[str, str]] = None):
        """
        Initializes the MockLLMClient.

        Args:
            predefined_responses: A dictionary mapping input prompts (or substrings of prompts)
                                  to specific mock responses. If a prompt matches multiple keys,
                                  the first found is returned. If no match, a generic response is given.
            delay_seconds: The simulated time delay in seconds before returning a response.
                           Defaults to a very small delay (0.01s) to mimic network latency.
            simulate_error: An optional `LLMClientError` subclass (e.g., `LLMRateLimitError`)
                            that will be raised for every `query` call, simulating an error condition.
            mock_capabilities: A dictionary of predefined model capabilities to return for `get_model_capabilities`.
                               Keys are model names, values are capability dictionaries.
            mock_supported_models: A dictionary of predefined supported models to return for `get_supported_models`.
                                   Keys are model IDs, values are display names.
        """
        self._responses = predefined_responses if predefined_responses is not None else {}
        self._delay = max(0.0, delay_seconds)  # Ensure delay is non-negative
        self._simulate_error = simulate_error
        self._mock_capabilities = mock_capabilities if mock_capabilities is not None else {
            "mock-model-default": {
                "name": "Mock Model Default",
                "description": "A generic mock model for testing.",
                "context_window_tokens": 4096,
                "max_output_tokens": 1024,
                "supports_vision": False
            }
        }
        self._mock_supported_models = mock_supported_models if mock_supported_models is not None else {
            "mock-model-alpha": "Mock Alpha (Fast)",
            "mock-model-beta": "Mock Beta (Accurate)",
            "mock-model-gamma": "Mock Gamma (Large Context)"
        }
        logger.info(f"MockLLMClient initialized. Responses: {len(self._responses)}, Delay: {self._delay}s, "
                    f"Simulate Error: {self._simulate_error.__name__ if self._simulate_error else 'None'}")

    def query(self, prompt: str, **kwargs: Any) -> str:
        """
        Simulates sending a query to the LLM and returns a predefined or default response.

        This method applies the configured delay and checks for a simulated error before
        attempting to return a response from the `predefined_responses` map.

        Args:
            prompt: The text prompt. The method will check if any key in `predefined_responses`
                    is a substring of this prompt.
            **kwargs: Ignored for the mock client but included for interface compatibility.

        Returns:
            A predefined response if a matching key is found in `predefined_responses`,
            otherwise a generic mock response indicating no specific match.

        Raises:
            LLMClientError: If `simulate_error` was set during the client's initialization.
        """
        if self._simulate_error:
            logger.error(f"Mock LLM configured to simulate error: {self._simulate_error.__name__}")
            raise self._simulate_error(f"Simulated error from MockLLMClient for prompt: '{prompt}'")

        time.sleep(self._delay)
        logger.debug(f"Mock LLM received query: '{prompt}' (simulating {self._delay}s delay)")

        # Find the best matching response from predefined_responses
        for key, value in self._responses.items():
            if key in prompt:
                logger.debug(f"Mock LLM found matching predefined response for key: '{key}'")
                return value

        logger.debug("No specific predefined response found. Returning default mock response.")
        return f"Mock response for prompt: '{prompt}'. (No specific match found in predefined responses.)"

    def get_model_capabilities(self, model_name: str) -> Dict[str, Any]:
        """
        Retrieves mock capabilities for a specific LLM model.

        Returns a predefined capability dictionary if `model_name` is found in
        `_mock_capabilities`, otherwise returns a default mock capability set.

        Args:
            model_name: The name of the LLM model to get capabilities for.

        Returns:
            A dictionary containing mock capabilities for the specified model.
        """
        logger.debug(f"Mock LLM received request for model capabilities for: {model_name}")
        return self._mock_capabilities.get(model_name, self._mock_capabilities.get("mock-model-default", {}))

    def get_supported_models(self) -> Dict[str, str]:
        """
        Retrieves a list of mock supported model IDs and their display names.

        Returns the dictionary of models specified during initialization or a default set.

        Returns:
            A dictionary where keys are mock model IDs and values are display names.
        """
        logger.debug("Mock LLM received request for supported models.")
        return self._mock_supported_models
