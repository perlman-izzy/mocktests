import dataclasses
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Dict, List, Any, Optional, Union
import datetime


class PipelineStage(Enum):
    """
    Enum representing the various stages a code generation pipeline can go through.

    This helps in tracking the progress and current state of the code generation process.
    """
    INITIALIZATION = auto()
    PROMPT_ANALYSIS = auto()
    PLANNING = auto()
    CODE_GENERATION = auto()
    STATIC_ANALYSIS = auto()
    TEST_GENERATION = auto()
    TEST_EXECUTION = auto()
    REFINEMENT = auto()
    FINALIZATION = auto()
    ERROR_HANDLING = auto()
    COMPLETED = auto()

    def __str__(self) -> str:
        """
        Returns a string representation of the pipeline stage.
        """
        return self.name.replace('_', ' ').title()


class PipelineStatus(Enum):
    """
    Enum representing the overall status of the code generation pipeline.

    This indicates the success or failure state of the entire process.
    """
    PENDING = auto()
    IN_PROGRESS = auto()
    SUCCESS = auto()
    FAILED = auto()
    PARTIAL_SUCCESS = auto()
    CANCELLED = auto()

    def __str__(self) -> str:
        """
        Returns a string representation of the pipeline status.
        """
        return self.name.replace('_', ' ').title()


@dataclass
class LintingResult:
    """
    Represents a single linting or static analysis issue found in the generated code.
    """
    filepath: str
    line: int
    column: int
    code: str
    message: str
    severity: str # e.g., "error", "warning", "info"
    tool: str # e.g., "pylint", "flake8", "mypy"
    details: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """
        Converts the LintingResult instance to a dictionary.

        Returns:
            Dict[str, Any]: A dictionary representation of the LintingResult.
        """
        return dataclasses.asdict(self)


@dataclass
class TestReport:
    """
    Represents the result of running tests on a generated code module or entire project.
    """
    filepath: str
    test_name: str
    status: str # e.g., "passed", "failed", "skipped", "error"
    duration_ms: float
    message: Optional[str] = None
    stacktrace: Optional[str] = None
    details: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """
        Converts the TestReport instance to a dictionary.

        Returns:
            Dict[str, Any]: A dictionary representation of the TestReport.
        """
        return dataclasses.asdict(self)


@dataclass
class PipelineContext:
    """
    PipelineContext is a dataclass that holds the state and data accumulated
    throughout the code generation pipeline.

    It serves as the central hub for all information relevant to a single
    code generation request, passed between different stages of the pipeline.

    Attributes:
        request_id (str): A unique identifier for the specific code generation request.
        initial_prompt (str): The original natural language prompt provided by the user.
        start_time (datetime.datetime): Timestamp when the pipeline context was initialized.
        end_time (Optional[datetime.datetime]): Timestamp when the pipeline completed or failed.
        current_stage (PipelineStage): The current active stage of the pipeline.
        overall_status (PipelineStatus): The overall completion status of the pipeline.
        generation_plan (Optional[Dict[str, Any]]): A structured plan derived from the prompt,
            detailing the files, classes, functions, and high-level logic to be generated.
            This might include file structures, dependencies, or architectural considerations.
        file_artifacts (Dict[str, str]): A dictionary where keys are file paths (relative to
            the project root) and values are the generated code content as strings.
            This accumulates all generated or modified files.
        linting_results (List[LintingResult]): A list of structured linting and static analysis
            results found in the generated code. Each item represents a specific issue.
        test_reports (List[TestReport]): A list of structured test execution results.
            Each item represents the outcome of a specific test case or module.
        errors (List[str]): A list of critical error messages encountered during the pipeline
            execution that prevented successful completion.
        warnings (List[str]): A list of non-critical warning messages encountered during the
            pipeline execution, indicating potential issues but not preventing completion.
        metadata (Dict[str, Any]): A flexible dictionary to store any additional,
            arbitrary metadata relevant to the pipeline run, such as user IDs,
            configuration options, or intermediate results.
    """
    request_id: str
    initial_prompt: str
    start_time: datetime.datetime = field(default_factory=lambda: datetime.datetime.now(datetime.timezone.utc))
    end_time: Optional[datetime.datetime] = field(default=None)
    current_stage: PipelineStage = field(default=PipelineStage.INITIALIZATION)
    overall_status: PipelineStatus = field(default=PipelineStatus.PENDING)
    generation_plan: Optional[Dict[str, Any]] = field(default=None)
    file_artifacts: Dict[str, str] = field(default_factory=dict)
    linting_results: List[LintingResult] = field(default_factory=list)
    test_reports: List[TestReport] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def update_stage(self, new_stage: PipelineStage) -> None:
        """
        Updates the current stage of the pipeline.

        Args:
            new_stage (PipelineStage): The new stage the pipeline has entered.

        Raises:
            TypeError: If `new_stage` is not an instance of `PipelineStage`.
        """
        if not isinstance(new_stage, PipelineStage):
            raise TypeError("new_stage must be an instance of PipelineStage.")
        self.current_stage = new_stage

    def set_overall_status(self, status: PipelineStatus) -> None:
        """
        Sets the overall completion status of the pipeline.

        If the status indicates completion (success, failure, partial success, cancelled),
        the `end_time` attribute is set to the current UTC time.

        Args:
            status (PipelineStatus): The final or current overall status.

        Raises:
            TypeError: If `status` is not an instance of `PipelineStatus`.
        """
        if not isinstance(status, PipelineStatus):
            raise TypeError("status must be an instance of PipelineStatus.")
        self.overall_status = status
        if status in [PipelineStatus.SUCCESS, PipelineStatus.FAILED, PipelineStatus.PARTIAL_SUCCESS, PipelineStatus.CANCELLED]:
            self.end_time = datetime.datetime.now(datetime.timezone.utc)

    def add_file_artifact(self, filepath: str, content: str) -> None:
        """
        Adds or updates a generated file artifact to the context.

        Args:
            filepath (str): The relative path of the file (e.g., 'src/my_module.py').
            content (str): The complete content of the file.

        Raises:
            ValueError: If `filepath` is an empty string or not a string.
            ValueError: If `content` is not a string.
        """
        if not isinstance(filepath, str) or not filepath.strip():
            raise ValueError("Filepath must be a non-empty string.")
        if not isinstance(content, str):
            raise ValueError("Content must be a string.")
        self.file_artifacts[filepath] = content

    def get_file_artifact(self, filepath: str) -> Optional[str]:
        """
        Retrieves the content of a specific file artifact.

        Args:
            filepath (str): The relative path of the file.

        Returns:
            Optional[str]: The content of the file if found, otherwise None.
        """
        return self.file_artifacts.get(filepath)

    def add_linting_result(self, result: LintingResult) -> None:
        """
        Adds a linting result to the context.

        Args:
            result (LintingResult): An instance of LintingResult detailing an issue.

        Raises:
            TypeError: If `result` is not an instance of `LintingResult`.
        """
        if not isinstance(result, LintingResult):
            raise TypeError("Result must be an instance of LintingResult.")
        self.linting_results.append(result)

    def add_test_report(self, report: TestReport) -> None:
        """
        Adds a test report to the context.

        Args:
            report (TestReport): An instance of TestReport detailing a test outcome.

        Raises:
            TypeError: If `report` is not an instance of `TestReport`.
        """
        if not isinstance(report, TestReport):
            raise TypeError("Report must be an instance of TestReport.")
        self.test_reports.append(report)

    def add_error(self, message: str) -> None:
        """
        Adds an error message to the context and immediately sets the overall status to FAILED.

        Args:
            message (str): The error description.

        Raises:
            ValueError: If `message` is an empty string or not a string.
        """
        if not isinstance(message, str) or not message.strip():
            raise ValueError("Error message cannot be empty.")
        self.errors.append(message)
        self.set_overall_status(PipelineStatus.FAILED) # Immediately fail on error

    def add_warning(self, message: str) -> None:
        """
        Adds a warning message to the context.

        Args:
            message (str): The warning description.

        Raises:
            ValueError: If `message` is an empty string or not a string.
        """
        if not isinstance(message, str) or not message.strip():
            raise ValueError("Warning message cannot be empty.")
        self.warnings.append(message)

    def has_errors(self) -> bool:
        """
        Checks if any errors have been recorded in the context.

        Returns:
            bool: True if there are errors, False otherwise.
        """
        return bool(self.errors)

    def has_warnings(self) -> bool:
        """
        Checks if any warnings have been recorded in the context.

        Returns:
            bool: True if there are warnings, False otherwise.
        """
        return bool(self.warnings)

    def get_summary(self) -> Dict[str, Any]:
        """
        Generates a summary dictionary of the pipeline context.

        Returns:
            Dict[str, Any]: A dictionary containing key summary information.
        """
        return {
            "request_id": self.request_id,
            "initial_prompt": self.initial_prompt,
            "start_time": self.start_time.isoformat(),
            "end_time": self.end_time.isoformat() if self.end_time else None,
            "current_stage": str(self.current_stage),
            "overall_status": str(self.overall_status),
            "num_files_generated": len(self.file_artifacts),
            "num_linting_issues": len(self.linting_results),
            "num_test_reports": len(self.test_reports),
            "num_errors": len(self.errors),
            "num_warnings": len(self.warnings),
            "has_errors": self.has_errors(),
            "has_warnings": self.has_warnings(),
            "metadata_keys": list(self.metadata.keys())
        }

    def to_dict(self) -> Dict[str, Any]:
        """
        Converts the entire PipelineContext instance into a serializable dictionary.

        This method deeply converts all nested dataclasses and enumerations
        into their dictionary/string representations, and `datetime` objects
        into ISO 8601 formatted strings for easy serialization (e.g., to JSON).

        Returns:
            Dict[str, Any]: A dictionary representation of the PipelineContext.
        """
        data = dataclasses.asdict(self)
        # Convert Enums to their string representation
        data['current_stage'] = str(self.current_stage)
        data['overall_status'] = str(self.overall_status)
        # Convert datetime objects to ISO format strings
        data['start_time'] = self.start_time.isoformat()
        if self.end_time:
            data['end_time'] = self.end_time.isoformat()
        # Convert nested dataclasses using their to_dict method
        data['linting_results'] = [res.to_dict() for res in self.linting_results]
        data['test_reports'] = [rep.to_dict() for rep in self.test_reports]
        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PipelineContext":
        """
        Reconstructs a PipelineContext instance from a dictionary.

        This method is a class method that takes a dictionary (typically generated
        by `to_dict()`) and recreates a `PipelineContext` instance, handling
        the conversion of strings back to Enums and `datetime` objects, and
        reconstructing nested dataclasses.

        Args:
            data (Dict[str, Any]): A dictionary representation of the PipelineContext,
                                    typically created by `to_dict()`.

        Returns:
            PipelineContext: An instance of PipelineContext.

        Raises:
            KeyError: If essential keys are missing from the input dictionary.
            ValueError: If date/time strings are not in a valid ISO format.
            TypeError: If types of nested components do not match expectations.
        """
        # Create a mutable copy to avoid modifying the original input dict
        data = data.copy()

        # Convert string representations back to Enum types
        if 'current_stage' in data:
            data['current_stage'] = PipelineStage[data['current_stage'].replace(' ', '_').upper()]
        if 'overall_status' in data:
            data['overall_status'] = PipelineStatus[data['overall_status'].replace(' ', '_').upper()]

        # Convert ISO format strings back to datetime objects
        if 'start_time' in data and data['start_time']:
            data['start_time'] = datetime.datetime.fromisoformat(data['start_time'])
        if 'end_time' in data and data['end_time']:
            data['end_time'] = datetime.datetime.fromisoformat(data['end_time'])

        # Reconstruct nested dataclass instances
        if 'linting_results' in data:
            data['linting_results'] = [LintingResult(**res_dict) for res_dict in data['linting_results']]
        if 'test_reports' in data:
            data['test_reports'] = [TestReport(**rep_dict) for rep_dict in data['test_reports']]

        return cls(**data)

    def __post_init__(self):
        """
        Post-initialization hook for the dataclass.

        This method is called automatically after `__init__` and is used to
        perform additional validation or setup.

        Raises:
            ValueError: If `request_id` or `initial_prompt` are empty.
        """
        if not self.request_id or not self.request_id.strip():
            raise ValueError("request_id cannot be empty.")
        if not self.initial_prompt or not self.initial_prompt.strip():
            raise ValueError("initial_prompt cannot be empty.")

        # Ensure start_time and end_time (if present) are timezone-aware
        if self.start_time.tzinfo is None:
            self.start_time = self.start_time.replace(tzinfo=datetime.timezone.utc)
        if self.end_time and self.end_time.tzinfo is None:
            self.end_time = self.end_time.replace(tzinfo=datetime.timezone.utc)
