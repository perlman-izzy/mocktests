import logging
from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional

# Configure a root logger for the entire application
# In a real production environment, this would be centrally managed,
# perhaps via a configuration file or a dedicated logging setup module.
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')


class PipelineException(Exception):
    """Base exception for all pipeline-related errors."""
    pass


class PipelineStageExecutionError(PipelineException):
    """Exception raised when a pipeline stage fails to execute its logic.

    Attributes:
        stage_name (str): The name of the stage that failed.
        original_exception (Exception): The underlying exception that caused the failure.
    """
    def __init__(self, stage_name: str, original_exception: Exception, *args: Any, **kwargs: Any):
        """
        Initializes the PipelineStageExecutionError.

        Args:
            stage_name (str): The name of the stage that failed.
            original_exception (Exception): The underlying exception that caused the failure.
            *args: Variable length argument list to pass to the base Exception.
            **kwargs: Arbitrary keyword arguments to pass to the base Exception.
        """
        super().__init__(f"Stage '{stage_name}' failed: {original_exception}", *args, **kwargs)
        self.stage_name = stage_name
        self.original_exception = original_exception


class PipelineConfigurationError(PipelineException):
    """Exception raised for invalid pipeline configurations or setup issues.

    This includes issues like empty stage lists, non-unique stage names,
    or invalid stage types.
    """
    pass


class PipelineContext:
    """
    A mutable context object that carries data throughout the pipeline execution.

    This class serves as the central data store that is passed from one pipeline stage
    to the next. Stages can read from and write to this context. It also maintains
    the overall status of the pipeline execution and records any errors.

    Attributes:
        data (Dict[str, Any]): A dictionary holding the arbitrary data for the pipeline.
        status (str): Current status of the pipeline (e.g., "INITIALIZED", "RUNNING", "COMPLETED", "FAILED", "STOPPED").
        error (Optional[Exception]): An exception object if an error occurred during execution.
        stage_results (Dict[str, Any]): Stores results or status specific to each stage's execution.
    """
    def __init__(self, initial_data: Optional[Dict[str, Any]] = None):
        """
        Initializes the PipelineContext.

        Args:
            initial_data (Optional[Dict[str, Any]]): Initial data to populate the context. If None, starts with an empty dictionary.
        """
        self.data: Dict[str, Any] = initial_data if initial_data is not None else {}
        self.status: str = "INITIALIZED"
        self.error: Optional[Exception] = None
        self.stage_results: Dict[str, Any] = {}
        self.logger = logging.getLogger(self.__class__.__name__)
        self.logger.debug(f"PipelineContext initialized with data keys: {list(self.data.keys())}")

    def get(self, key: str, default: Any = None) -> Any:
        """
        Retrieves a value from the context data dictionary.

        Args:
            key (str): The key of the data to retrieve.
            default (Any): The default value to return if the key is not found.

        Returns:
            Any: The value associated with the key, or the default value if the key is not present.
        """
        return self.data.get(key, default)

    def set(self, key: str, value: Any):
        """
        Sets or updates a value in the context data dictionary.

        Args:
            key (str): The key for the data.
            value (Any): The value to set.
        """
        self.data[key] = value
        self.logger.debug(f"Context data updated: '{key}' = {value}")

    def set_status(self, status: str):
        """
        Sets the overall status of the pipeline context.

        Args:
            status (str): The status string (e.g., "RUNNING", "COMPLETED", "FAILED").
        """
        if self.status != status:
            self.logger.info(f"Context status changed from '{self.status}' to '{status}'")
            self.status = status
        else:
            self.logger.debug(f"Context status remains '{status}'")

    def set_error(self, error: Exception):
        """
        Sets an error object in the context and updates the status to 'FAILED'.

        Args:
            error (Exception): The exception that occurred.
        """
        self.error = error
        self.set_status("FAILED")
        self.logger.error(f"An error has been set in the context: {error}", exc_info=True)

    def record_stage_result(self, stage_name: str, result: Any):
        """
        Records the result or status of a specific pipeline stage's execution.

        Args:
            stage_name (str): The name of the stage.
            result (Any): The result or status produced by the stage (e.g., "SUCCESS", "FAILURE", or an output value).
        """
        self.stage_results[stage_name] = result
        self.logger.debug(f"Recorded result for stage '{stage_name}': {result}")

    def is_failed(self) -> bool:
        """
        Checks if the pipeline context indicates a failed state.

        Returns:
            bool: True if the status is 'FAILED', False otherwise.
        """
        return self.status == "FAILED"

    def __repr__(self) -> str:
        """
        Returns a string representation of the PipelineContext for debugging.
        """
        data_keys_str = ', '.join(self.data.keys()) if self.data else 'No data'
        return f"PipelineContext(status='{self.status}', data_keys=[{data_keys_str}], error_set={self.error is not None})"


class PipelineStage(ABC):
    """
    Abstract Base Class for a pipeline stage.

    All concrete pipeline stages must inherit from this class and implement
    the `execute` method. Each stage represents a distinct, sequential step
    in a larger data processing or operational workflow.

    Attributes:
        name (str): The unique name of the pipeline stage.
        description (str): A brief description of what the stage does.
        logger (logging.Logger): Logger instance specific to this stage.
    """

    def __init__(self, name: str, description: str = ""):
        """
        Initializes a PipelineStage.

        Args:
            name (str): The name of the stage. This should be unique within a pipeline
                        to avoid configuration errors and for clear logging.
            description (str): An optional description of the stage's purpose. Defaults to an empty string.

        Raises:
            PipelineConfigurationError: If the stage name is not a valid string or is empty.
        """
        if not isinstance(name, str) or not name.strip():
            raise PipelineConfigurationError("Pipeline stage name cannot be empty or non-string.")
        self.name = name.strip()
        self.description = description
        self.logger = logging.getLogger(f"codepori.pipeline.stage.{self.name}")
        self.logger.debug(f"PipelineStage '{self.name}' initialized.")

    @abstractmethod
    def execute(self, context: PipelineContext) -> PipelineContext:
        """
        Executes the specific logic of the pipeline stage.

        This method must be implemented by concrete stage classes. It takes a
        `PipelineContext` object, performs its operations (e.g., data loading,
        transformation, validation, persistence), and returns an updated
        `PipelineContext` object.

        Implementations should:-
        1. Read necessary data from the input `context`.
        2. Perform the stage's specific operation.
        3. Update the `context` with new data or status changes.
        4. Return the (potentially modified) `context`.
        5. Raise `PipelineStageExecutionError` or another appropriate exception
           if a critical, unrecoverable error occurs within the stage's logic.

        Args:
            context (PipelineContext): The current pipeline context object.

        Returns:
            PipelineContext: The updated pipeline context after this stage's execution.

        Raises:
            PipelineStageExecutionError: If an error occurs that prevents the stage from completing its task.
            Exception: Any other unexpected exceptions might be caught and wrapped by the pipeline runner.
        """
        pass

    def __str__(self) -> str:
        """
        Returns a user-friendly string representation of the pipeline stage.
        """
        return f"Stage: {self.name}"

    def __repr__(self) -> str:
        """
        Returns a detailed string representation of the pipeline stage for debugging.
        """
        return f"PipelineStage(name='{self.name}', description='{self.description}')"


class Pipeline:
    """
    Orchestrates the execution of a sequence of PipelineStage instances.

    The Pipeline class is responsible for iterating through a predefined list
    of stages, executing each one in order, and passing a mutable context object
    between them. It handles errors at the stage level, logs progress, and
    provides a comprehensive view of the pipeline's execution outcome.

    Attributes:
        name (str): The descriptive name of the pipeline.
        stages (List[PipelineStage]): An ordered list of pipeline stages to execute.
        logger (logging.Logger): Logger instance for the pipeline, named after its instance.
    """

    def __init__(self, name: str, stages: List[PipelineStage]):
        """
        Initializes the Pipeline.

        Args:
            name (str): The name of the pipeline. Must be a non-empty string.
            stages (List[PipelineStage]): An ordered list of `PipelineStage` instances.
                                        The list must not be empty, and all elements
                                        must be instances of `PipelineStage`.

        Raises:
            PipelineConfigurationError: If the pipeline name is invalid, the stages list is empty,
                                      contains non-`PipelineStage` objects, or has duplicate stage names.
        """
        if not isinstance(name, str) or not name.strip():
            raise PipelineConfigurationError("Pipeline name cannot be empty or non-string.")
        if not stages:
            raise PipelineConfigurationError("Pipeline must be initialized with at least one stage.")
        if not all(isinstance(stage, PipelineStage) for stage in stages):
            raise PipelineConfigurationError("All items in 'stages' must be instances of PipelineStage.")

        self.name = name.strip()
        self.stages = stages
        self.logger = logging.getLogger(f"codepori.pipeline.{self.name}")
        self.logger.info(f"Pipeline '{self.name}' initialized with {len(self.stages)} stages.")
        self._validate_stage_names()

    def _validate_stage_names(self):
        """
        Internal method to validate that all stage names are unique within this pipeline.

        This prevents potential confusion in logging, context manipulation, or configuration
        when stages are referenced by name.

        Raises:
            PipelineConfigurationError: If duplicate stage names are found in the list of stages.
        """
        stage_names = set()
        for stage in self.stages:
            if stage.name in stage_names:
                raise PipelineConfigurationError(f"Duplicate stage name found: '{stage.name}'. Stage names must be unique within a pipeline.")
            stage_names.add(stage.name)
        self.logger.debug(f"All {len(self.stages)} pipeline stage names for '{self.name}' validated as unique.")

    def run(self, initial_context_data: Optional[Dict[str, Any]] = None) -> PipelineContext:
        """
        Executes the pipeline by running each stage sequentially.

        The pipeline execution starts with an initial context, which is then
        passed from one stage to the next. If a stage fails (raises an exception),
        the pipeline's execution will typically halt, and the final context will
        reflect the error.

        Args:
            initial_context_data (Optional[Dict[str, Any]]): Initial data to seed the pipeline context.
                                                            If None, an empty context is started.

        Returns:
            PipelineContext: The final state of the context object after pipeline execution.
                             If an error occurred, the context's status will be 'FAILED',
                             and the `error` attribute will contain the exception.
        """
        context = PipelineContext(initial_context_data)
        self.logger.info(f"Pipeline '{self.name}' starting execution with initial context data keys: {list(context.data.keys())}")
        context.set_status("RUNNING")

        for i, stage in enumerate(self.stages):
            self.logger.info(f"[{i+1}/{len(self.stages)}] Executing stage: '{stage.name}' (Description: {stage.description or 'N/A'})")
            try:
                # Execute the current stage, passing the current context.
                # The stage is expected to return an updated context.
                updated_context = stage.execute(context)

                # Basic type validation: ensure stage returns a PipelineContext
                if not isinstance(updated_context, PipelineContext):
                    error_msg = f"Stage '{stage.name}' returned an invalid type. Expected PipelineContext, got: {type(updated_context).__name__}"
                    self.logger.error(error_msg)
                    raise TypeError(error_msg) # Re-raise to be caught by the generic Exception handler

                context = updated_context
                context.record_stage_result(stage.name, "SUCCESS")
                self.logger.info(f"Stage '{stage.name}' completed successfully. Current context data keys: {list(context.data.keys())}")

                # Check if the context itself signals a stop or failure from within a stage
                if context.is_failed():
                    self.logger.warning(f"Stage '{stage.name}' completed but the context indicates a FAILED status. Halting pipeline.")
                    break

            except PipelineStageExecutionError as ps_e:
                # Catch specific stage execution errors and log them comprehensively.
                self.logger.error(f"Pipeline '{self.name}' halted due to stage '{stage.name}' execution error: {ps_e}", exc_info=True)
                context.set_error(ps_e)
                context.record_stage_result(stage.name, "FAILED")
                break  # Stop execution on critical stage failure
            except Exception as e:
                # Catch any other unexpected exceptions from a stage's execution.
                wrapped_e = PipelineStageExecutionError(stage.name, e)
                self.logger.exception(f"Pipeline '{self.name}' halted due to unexpected error in stage '{stage.name}': {wrapped_e}")
                context.set_error(wrapped_e)
                context.record_stage_result(stage.name, "FAILED")
                break  # Stop execution on any unhandled exception

        # Determine final pipeline status based on whether an error occurred
        if not context.is_failed():
            context.set_status("COMPLETED")
            self.logger.info(f"Pipeline '{self.name}' completed successfully.")
        else:
            self.logger.error(f"Pipeline '{self.name}' finished with status: FAILED. Error details: {context.error}")

        return context

    def __str__(self) -> str:
        """
        Returns a human-readable string representation of the pipeline.
        """
        return f"Pipeline: '{self.name}' with {len(self.stages)} stages."

    def __repr__(self) -> str:
        """
        Returns a detailed string representation of the pipeline for debugging.
        """
# FIXME(auto-comment):         return f"Pipeline(name='{self.name}', stages={[stage.name for stage in self.stages]})">


# --- Example Usage (for demonstrating functionality and ensuring executability) ---
# This __main__ block serves as a comprehensive test bed for the Pipeline and its components.
# In a larger project, these examples would typically be moved to a dedicated 'tests/' directory.
if __name__ == "__main__":
    # Define concrete PipelineStage implementations for demonstration
    class DataLoaderStage(PipelineStage):
        def __init__(self, name="DataLoader"):
            super().__init__(name, "Loads initial data from a simulated external source.")

        def execute(self, context: PipelineContext) -> PipelineContext:
            self.logger.info(f"[{self.name}] Simulating data loading...")
            # Simulate fetching complex data
            raw_data = {
                "user_profile": {"id": 1001, "name": "Alice", "email": "alice@example.com"},
                "orders": [
                    {"order_id": "O123", "amount": 150.75, "status": "shipped"},
                    {"order_id": "O124", "amount": 25.00, "status": "pending"}
                ],
                "preferences": {"theme": "dark", "notifications": True}
            }
            context.set("raw_input_data", raw_data)
            context.set("data_loaded_timestamp", "2023-10-27T10:00:00Z")
            self.logger.info(f"[{self.name}] Raw data loaded. Keys: {list(context.get('raw_input_data').keys())}")
            return context

    class DataValidationStage(PipelineStage):
        def __init__(self, name="DataValidation"):
            super().__init__(name, "Validates the structure and content of loaded data.")

        def execute(self, context: PipelineContext) -> PipelineContext:
            self.logger.info(f"[{self.name}] Starting data validation...")
            raw_data = context.get("raw_input_data")
            if not raw_data:
                raise PipelineStageExecutionError(self.name, ValueError("Missing 'raw_input_data' in context for validation."))

            # Example validation logic
            if not isinstance(raw_data.get("user_profile"), dict):
                raise PipelineStageExecutionError(self.name, TypeError("User profile is missing or invalid."))
            if not isinstance(raw_data.get("orders"), list) or not raw_data["orders"]:
                raise PipelineStageExecutionError(self.name, ValueError("Orders list is empty or invalid."))

            for order in raw_data["orders"]:
                if not all(k in order for k in ["order_id", "amount"]):
                    raise PipelineStageExecutionError(self.name, ValueError(f"Invalid order structure: {order}"))
                if not isinstance(order.get("amount"), (int, float)) or order["amount"] <= 0:
                    raise PipelineStageExecutionError(self.name, ValueError(f"Invalid order amount: {order.get('amount')}"))

            context.set("validation_status", "PASSED")
            self.logger.info(f"[{self.name}] Data validation completed successfully.")
            return context

    class DataTransformationStage(PipelineStage):
        def __init__(self, name="DataTransformation"):
            super().__init__(name, "Transforms raw data into a standardized format.")

        def execute(self, context: PipelineContext) -> PipelineContext:
            self.logger.info(f"[{self.name}] Starting data transformation...")
            raw_data = context.get("raw_input_data")
            validation_status = context.get("validation_status")

            if validation_status != "PASSED":
                raise PipelineStageExecutionError(self.name, RuntimeError("Data not validated; cannot transform."))

            transformed_profile = {
                "id": raw_data["user_profile"]["id"],
                "display_name": raw_data["user_profile"]["name"].upper(),
                "contact_email": raw_data["user_profile"]["email"].lower()
            }
            transformed_orders = [
                {"tx_id": order["order_id"], "value": float(order["amount"]), "order_status": order["status"].upper()}
                for order in raw_data["orders"]
            ]

            context.set("transformed_data", {
                "user": transformed_profile,
                "transactions": transformed_orders
            })
            self.logger.info(f"[{self.name}] Data transformed. Transformed user: {context.get('transformed_data')['user']['display_name']}")
            return context

    class DataAggregationStage(PipelineStage):
        def __init__(self, name="DataAggregation"):
            super().__init__(name, "Aggregates transformed data, e.g., calculates total values.")

        def execute(self, context: PipelineContext) -> PipelineContext:
            self.logger.info(f"[{self.name}] Starting data aggregation...")
            transformed_data = context.get("transformed_data")
            if not transformed_data:
                raise PipelineStageExecutionError(self.name, ValueError("Missing 'transformed_data' in context for aggregation."))

            total_order_value = sum(tx["value"] for tx in transformed_data["transactions"])
            active_orders_count = len([tx for tx in transformed_data["transactions"] if tx["order_status"] != "SHIPPED"])

            aggregated_info = {
                "user_id": transformed_data["user"]["id"],
                "total_spending": round(total_order_value, 2),
                "active_orders": active_orders_count,
                "last_updated": context.get("data_loaded_timestamp") # Reusing timestamp from initial load
            }
            context.set("aggregated_report", aggregated_info)
            self.logger.info(f"[{self.name}] Data aggregated. Total spending: {aggregated_info['total_spending']}")
            return context

    class DataPersistenceStage(PipelineStage):
        def __init__(self, name="DataPersistence"):
            super().__init__(name, "Persists the final aggregated data to a database or storage.")

        def execute(self, context: PipelineContext) -> PipelineContext:
            self.logger.info(f"[{self.name}] Simulating data persistence...")
            final_report = context.get("aggregated_report")
            if not final_report:
                raise PipelineStageExecutionError(self.name, RuntimeError("Aggregated report not found for persistence."))

            # Simulate writing to a database/file system
            self.logger.info(f"[{self.name}] Saving final report for user {final_report['user_id']}: {final_report}")
            context.set("persistence_status", "COMPLETE")
            self.logger.info(f"[{self.name}] Data persisted successfully.")
            return context


    # --- Test Case 1: Successful Pipeline Execution ---
    print("\n" + "="*50)
    print("--- Running Successful User Data Processing Pipeline ---")
    print("="*50)
    successful_stages = [
        DataLoaderStage("UserDataLoader"),
        DataValidationStage("UserDataValidator"),
        DataTransformationStage("UserDataTransformer"),
        DataAggregationStage("UserDataAggregator"),
        DataPersistenceStage("UserDataPersister")
    ]
    user_pipeline = Pipeline("UserDataPipeline", successful_stages)
    final_context_success = user_pipeline.run({"request_id": "REQ-001", "source_system": "CRM"})

    print("\n" + "-"*50)
    print(f"Final Pipeline Status (Success): {final_context_success.status}")
    print(f"Final Context Data Keys (Success): {list(final_context_success.data.keys())}")
    print(f"Final Aggregated Report (Success): {final_context_success.get('aggregated_report')}")
    print(f"Final Context Error (Success): {final_context_success.error}")
    print("-"*50)

    # --- Test Case 2: Pipeline with a Failing Stage ---
    print("\n" + "="*50)
    print("--- Running Failing User Data Processing Pipeline (Validation Error) ---")
    print("="*50)

    class FaultyDataLoaderStage(PipelineStage):
        def __init__(self):
            super().__init__("FaultyDataLoader", "Simulates loading invalid data to trigger validation error.")

        def execute(self, context: PipelineContext) -> PipelineContext:
            self.logger.info(f"[{self.name}] Simulating loading bad data...")
            # Missing 'orders' key, which DataValidationStage expects
            bad_data = {"user_profile": {"id": 1002, "name": "Bob"}, "preferences": {}}
            context.set("raw_input_data", bad_data)
            return context

    failing_stages = [
        FaultyDataLoaderStage(),
        DataValidationStage("FaultyDataValidator"), # This stage will fail due to missing data
        DataTransformationStage("FaultyDataTransformer"),
        DataAggregationStage("FaultyDataAggregator"),
        DataPersistenceStage("FaultyDataPersister")
    ]
    failing_user_pipeline = Pipeline("FailingUserDataPipeline", failing_stages)
    final_context_fail = failing_user_pipeline.run({"request_id": "REQ-002"})

    print("\n" + "-"*50)
    print(f"Final Pipeline Status (Fail): {final_context_fail.status}")
    print(f"Final Context Data Keys (Fail): {list(final_context_fail.data.keys())}")
    print(f"Final Context Error (Fail): {final_context_fail.error}")
    if final_context_fail.error: print(f"Original Exception: {final_context_fail.error.original_exception}")
    print("-"*50)

    # --- Test Case 3: Pipeline Configuration Error (Duplicate Stage Name) ---
    print("\n" + "="*50)
    print("--- Testing Pipeline Configuration Error (Duplicate Stage Name) ---")
    print("="*50)
    try:
        duplicate_stages = [
            DataLoaderStage("EntryStage"),
            DataValidationStage("EntryStage") # Deliberate duplicate name
        ]
        Pipeline("DuplicateStageTestPipeline", duplicate_stages)
    except PipelineConfigurationError as e:
        print(f"Caught expected configuration error: {e}")
    except Exception as e:
        print(f"Caught unexpected error type: {e}")
    print("-"*50)

    # --- Test Case 4: Pipeline Configuration Error (Empty Stages List) ---
    print("\n" + "="*50)
    print("--- Testing Pipeline Configuration Error (Empty Stages List) ---")
    print("="*50)
    try:
        Pipeline("EmptyStagesTestPipeline", [])
    except PipelineConfigurationError as e:
        print(f"Caught expected configuration error: {e}")
    except Exception as e:
        print(f"Caught unexpected error type: {e}")
    print("-"*50)

    # --- Test Case 5: Pipeline Configuration Error (Invalid Stage Type) ---
    print("\n" + "="*50)
    print("--- Testing Pipeline Configuration Error (Invalid Stage Type) ---")
    print("="*50)
    try:
        Pipeline("InvalidTypeTestPipeline", [DataLoaderStage(), "not_a_stage_object"])
    except PipelineConfigurationError as e:
        print(f"Caught expected configuration error: {e}")
    except Exception as e:
        print(f"Caught unexpected error type: {e}")
    print("-"*50)

    # --- Test Case 6: Stage returning wrong object type ---
    print("\n" + "="*50)
    print("--- Testing Stage Returning Wrong Object Type ---")
    print("="*50)

    class BadReturnStage(PipelineStage):
        def __init__(self):
            super().__init__("BadReturnStage", "Returns a non-PipelineContext object.")

        def execute(self, context: PipelineContext) -> Any:
            self.logger.info(f"[{self.name}] Returning a string instead of context...")
            return "This is not a context!"

    bad_return_pipeline = Pipeline("BadReturnPipeline", [DataLoaderStage(), BadReturnStage()])
    final_context_bad_return = bad_return_pipeline.run()

    print("\n" + "-"*50)
    print(f"Final Pipeline Status (Bad Return): {final_context_bad_return.status}")
    print(f"Final Context Error (Bad Return): {final_context_bad_return.error}")
    if final_context_bad_return.error: print(f"Original Exception: {final_context_bad_return.error.original_exception}")
    print("-"*50)
