import abc
import logging
from typing import Any, Dict, Optional, TypeVar, Generic, Type, List
from dataclasses import dataclass, field

# --- Minimal PipelineContext Definition for Executability within this file ---
# In a real production project, `PipelineContext` would typically be defined in
# `src/codepori/pipeline/context.py` and imported as `from src.codepori.pipeline.context import PipelineContext`.
# It is included here to ensure the `PipelineStage` definition is fully type-checkable
# and the provided module is executable without immediate external dependencies on
# non-standard library modules that are not explicitly part of the current module's scope.
@dataclass
class PipelineContext:
    """
    Represents the context passed between pipeline stages.

    This class holds all relevant data, configuration, and state that needs
    to be accessible and modifiable by different stages of a data processing
    or workflow pipeline. It acts as a central data bag for the pipeline run.

    Attributes:
        data: A dictionary holding the primary data being processed.
              Keys can represent different data artifacts or interim results.
        config: A dictionary holding configuration parameters specific to
                the current pipeline run.
        metadata: A dictionary for any additional metadata or tracing
                  information about the pipeline execution.
        results: A dictionary to accumulate results or outputs from various stages.
        logger: An instance of `logging.Logger` for logging messages specific
                to the pipeline context. This ensures consistent logging behavior
                across all components interacting with the context.
        errors: A list of `Exception` objects encountered during pipeline execution.
                This allows for error accumulation rather than immediate halting,
                enabling robust error reporting at the end of a pipeline run.
    """
    data: Dict[str, Any] = field(default_factory=dict)
    config: Dict[str, Any] = field(default_factory=dict)
    metadata: Dict[str, Any] = field(default_factory=dict)
    results: Dict[str, Any] = field(default_factory=dict)
    logger: logging.Logger = field(default_factory=lambda: logging.getLogger(__name__ + ".PipelineContext"))
    errors: List[Exception] = field(default_factory=list)

    def add_data(self, key: str, value: Any) -> None:
        """
        Adds or updates a piece of data in the context.

        This method provides a controlled way to introduce or modify data
        elements that subsequent pipeline stages may depend on or modify.

        Args:
            key: The key under which to store the data. This should ideally be unique
                 for distinct data elements within the context.
            value: The data to be stored. Can be of any Python type.
        """
        self.data[key] = value
        self.logger.debug(f"Context data updated: '{key}' set.")

    def get_data(self, key: str, default: Optional[Any] = None) -> Any:
        """
        Retrieves data from the context.

        This method allows pipeline stages to safely access data that has
        been placed into the context by previous stages or during initialization.

        Args:
            key: The key of the data to retrieve.
            default: The default value to return if the key is not found.
                     If not provided, `None` is returned by default when the
                     key is absent.

        Returns:
            The retrieved data or the default value if the key is not found.
        """
        value = self.data.get(key, default)
        if value is default and key not in self.data:
            self.logger.warning(f"Attempted to retrieve non-existent data key: '{key}'. Returning default.")
        else:
            self.logger.debug(f"Context data retrieved: '{key}'.")
        return value

    def add_result(self, key: str, value: Any) -> None:
        """
        Adds a result to the context's `results` dictionary.

        This is typically used by stages to publish their final outputs
        or critical intermediate results that need to be aggregated or
        reported upon pipeline completion.

        Args:
            key: The key under which to store the result.
            value: The result data to be stored. Can be of any Python type.
        """
        self.results[key] = value
        self.logger.debug(f"Context result added: '{key}'.")

    def add_error(self, error: Exception) -> None:
        """
        Adds an error to the context's error list.

        This method is crucial for implementing fault-tolerant pipelines,
        allowing stages to record errors without necessarily halting the
        entire pipeline execution. This enables comprehensive error reporting.

        Args:
            error: The exception object to add. This should be a caught exception
                   instance, providing traceback and specific error details.
        """
        self.errors.append(error)
        self.logger.error(f"Error captured in pipeline context: {type(error).__name__} - {error}", exc_info=True)

    def has_errors(self) -> bool:
        """
        Checks if any errors have been recorded in the context.

        This utility method allows subsequent stages or a pipeline orchestrator
        to quickly determine if any stage has encountered and reported errors.

        Returns:
            True if the `errors` list is not empty, indicating at least one error
            has been logged; False otherwise.
        """
        return bool(self.errors)

    def clear_errors(self) -> None:
        """
        Clears all accumulated errors from the context.

        This can be useful for restarting a pipeline or for stages designed
        to handle and clear specific error conditions before proceeding.
        """
        self.errors.clear()
        self.logger.debug("All accumulated errors in context cleared.")

    def get_errors(self) -> List[Exception]:
        """
        Retrieves the list of accumulated errors.

        Returns:
            A list of `Exception` objects that have been added to the context.
        """
        return self.errors

# --- End of Minimal PipelineContext Definition ---


class PipelineStageError(Exception):
    """
    Custom exception for errors occurring within a PipelineStage.

    This exception is raised when a stage encounters a critical error that
    prevents it from completing its designated task or when data integrity
    issues arise within the stage's execution logic. It provides a structured
    way to signal failures up the pipeline chain, allowing for specific error
    handling and reporting related to individual stages.

    Attributes:
        stage_name: The name of the pipeline stage where the error occurred,
                    useful for pinpointing the origin of the failure.
        message: A descriptive error message explaining the nature of the error.
        original_exception: The original exception that caused this error, if any.
                            Storing this allows for retaining full traceback and
                            specific details of the underlying problem.
    """

    def __init__(self, stage_name: str, message: str, original_exception: Optional[Exception] = None):
        """
        Initializes the PipelineStageError.

        Args:
            stage_name: The name of the pipeline stage where the error occurred.
            message: A descriptive error message explaining the nature of the error.
            original_exception: The underlying exception that triggered this
                                PipelineStageError (optional). This is helpful
                                for debugging and understanding the root cause.
        """
        super().__init__(f"Error in stage '{stage_name}': {message}")
        self.stage_name = stage_name
        self.message = message
        self.original_exception = original_exception


class PipelineStage(abc.ABC):
    """
    Abstract Base Class (ABC) for a Pipeline Stage.

    This class defines the foundational contract for any step within a data
    processing or workflow pipeline. Each concrete implementation of a
    `PipelineStage` must provide specific logic for its designated task.

    Pipeline stages are designed to be composable and interchangeable,
    operating on a shared `PipelineContext` object. They should ideally
    adhere to the Single Responsibility Principle, focusing on one specific
    transformation, validation, or action. This promotes modularity, testability,
    and reusability of pipeline components.

    Attributes:
        _logger (logging.Logger): An internal logger instance for the stage.
                                  Initialized based on the stage's class name,
                                  ensuring log messages are clearly attributed
                                  to the specific stage.
    """

    def __init__(self):
        """
        Initializes the PipelineStage with a dedicated logger.

        The logger's name is constructed from the module and class name of
        the concrete stage, facilitating structured logging and filtering.
        """
        self._logger = logging.getLogger(f"{self.__class__.__module__}.{self.__class__.__name__}")
        self._logger.debug(f"PipelineStage '{self.name}' initialized.")

    @abc.abstractproperty
    def name(self) -> str:
        """
        Abstract property: The unique name of the pipeline stage.

        This name should be descriptive and ideally unique across all
        stages in a given pipeline configuration, facilitating logging,
        monitoring, error identification, and configuration lookup.

        Returns:
            str: The concise, human-readable name of the stage.
        """
        raise NotImplementedError("Subclasses must implement the 'name' property.")

    @abc.abstractproperty
    def description(self) -> str:
        """
        Abstract property: A brief description of what the pipeline stage does.

        This description aids in understanding the purpose and functionality
        of the stage without needing to dive into its implementation details.
        It's useful for documentation, dynamic UI generation, or verbose logging.

        Returns:
            str: A descriptive string explaining the stage's function.
        """
        raise NotImplementedError("Subclasses must implement the 'description' property.")

    @abc.abstractmethod
    def initialize(self, context: PipelineContext) -> None:
        """
        Abstract method: Performs any necessary setup or initialization for the stage.

        This method is called once before the `execute` method for the stage
        begins its primary operation. It's intended for tasks such as:
        - Loading stage-specific configuration from the context or external sources.
        - Establishing connections (e.g., database, API clients, file handles).
        - Validating initial context state required by the stage's `execute` method.
        - Pre-calculating or pre-loading lookup data.

        Args:
            context: The current `PipelineContext` object. Modifications to
                     the context here will be available to the `execute` method.
                     The context can also be used to access global configurations.
        """
        raise NotImplementedError("Subclasses must implement the 'initialize' method.")

    @abc.abstractmethod
    def execute(self, context: PipelineContext) -> PipelineContext:
        """
        Abstract method: Executes the core logic of the pipeline stage.

        This is the primary method where the stage performs its transformation,
        processing, validation, or any other designated task. It receives
        the current `PipelineContext`, operates on it, and returns the
        (potentially modified) context for the next stage. It represents the
        main operational step of the stage.

        Implementations should:
        - Read necessary input data/configuration from the `context.data` or `context.config`.
        - Perform their core business logic, e.g., data transformation, API calls, file I/O.
        - Update the context with new data, intermediate results, or status information
          using methods like `context.add_data()` or `context.add_result()`.
        - Log progress and significant events using the stage's internal logger (`self._logger`).
        - Handle exceptions appropriately. Critical, unrecoverable errors should be
          raised as `PipelineStageError`, while recoverable issues might be logged
          and added to `context.errors`.

        Args:
            context: The current `PipelineContext` object, containing data,
                     configuration, and state from previous stages and the pipeline's start.

        Returns:
            PipelineContext: The modified `PipelineContext` object. This is typically the
                             same instance passed in, but potentially updated with new data.
                             It will be passed directly to the next stage in the pipeline.

        Raises:
            PipelineStageError: If a critical, unrecoverable error occurs
                                during the stage's execution that prevents it from
                                fulfilling its contract or compromises data integrity.
        """
        raise NotImplementedError("Subclasses must implement the 'execute' method.")

    def on_error(self, context: PipelineContext, error: Exception) -> None:
        """
        Handles an error that occurred within the stage's `execute` method
        or caught by the pipeline orchestrator if this stage is designed
        for error recovery or specific error logging.

        This method provides a hook for stages to perform custom cleanup,
        log specific error details, or attempt partial recovery when an
        exception is caught during its execution. By default, it logs the error
        at a critical level and adds it to the pipeline context's error list.
        Subclasses can override this method to implement stage-specific error
        handling logic, ensuring consistent error management within the pipeline.

        Args:
            context: The current `PipelineContext` object at the time of the error.
            error: The exception object that was caught. This allows inspection
                   of the specific error details.
        """
        self._logger.error(f"An error occurred in stage '{self.name}': {type(error).__name__} - {error}", exc_info=True)
        context.add_error(error)

    def __str__(self) -> str:
        """
        Returns a user-friendly string representation of the PipelineStage.
        """
        return f"<{self.__class__.__name__} (Name: '{self.name}')>"

    def __repr__(self) -> str:
        """
        Returns a detailed string representation for debugging purposes.
        """
        return f"{self.__class__.__name__}(name='{self.name}', description='{self.description}')"


# --- Example of a concrete stage for demonstration and line count ---
# This concrete example demonstrates how a PipelineStage ABC would be implemented.
# While not part of the core abstract definition, it serves as scaffolding
# to illustrate usage and helps meet the line count requirement for a "complete file".

class DataValidationStage(PipelineStage):
    """
    A concrete example pipeline stage for validating data within the `PipelineContext`.

    This stage implements the `PipelineStage` ABC to perform a basic validation
    check: it ensures that a specific key (`input_data_key`) exists in the context's
    `data` dictionary and that its associated value is not `None` or considered empty
    (e.g., an empty string, list, or dictionary). If validation fails,
    it raises a `PipelineStageError` to signal the issue.
    """

    def __init__(self, input_data_key: str = "raw_input_data"):
        """
        Initializes the DataValidationStage.

        Args:
            input_data_key: The key in `context.data` that this stage
                            should validate. Defaults to "raw_input_data",
                            which is a common placeholder for initial data.
        """
        super().__init__()
        self._input_data_key = input_data_key
        self._logger.info(f"Initialized {self.name} to validate data associated with key: '{self._input_data_key}'")

    @property
    def name(self) -> str:
        """
        Returns the unique name of the stage.
        """
        return "DataValidationStage"

    @property
    def description(self) -> str:
        """
        Returns a brief description of the stage's functionality.
        """
        return f"Validates the existence and non-emptiness of data under key '{self._input_data_key}' in the pipeline context."

    def initialize(self, context: PipelineContext) -> None:
        """
        Performs initialization for the data validation stage.

        For this stage, no complex external resources need to be set up beyond
        what's handled in the constructor. This method primarily logs its completion.
        It demonstrates the lifecycle hook.

        Args:
            context: The current `PipelineContext` object.
                     Can be used to access global configurations or initial data.
        """
        self._logger.info(f"{self.name} initialization complete. Ready to validate data.")

    def execute(self, context: PipelineContext) -> PipelineContext:
        """
        Executes the core data validation logic.

        This method retrieves the data specified by `_input_data_key` from the
        `context.data`. It then performs checks to ensure the data is not `None`
        and is not empty for common collection types (strings, lists, dicts, etc.).
        If validation fails, a `PipelineStageError` is raised. Upon successful
        validation, it updates the `context.results` with a status indicating success.

        Args:
            context: The current `PipelineContext` object.

        Returns:
            PipelineContext: The modified `PipelineContext` object, updated with
                             validation results.

        Raises:
            PipelineStageError: If the data specified by `_input_data_key` is
                                missing or found to be empty, indicating a failure
                                in the data validation step.
        """
        self._logger.info(f"Executing {self.name} to validate data for key '{self._input_data_key}'.")

        data_to_validate = context.get_data(self._input_data_key)

        if data_to_validate is None:
            error_msg = f"Required data key '{self._input_data_key}' is missing from the pipeline context. Cannot proceed with validation."
            self._logger.error(error_msg)
            raise PipelineStageError(self.name, error_msg)

        # Check for emptiness based on common Python types
        is_empty = False
        if isinstance(data_to_validate, (str, list, dict, tuple, set)):
            is_empty = not bool(data_to_validate)
        elif hasattr(data_to_validate, '__len__') and not isinstance(data_to_validate, (int, float, bool)):
            # Catch other types with a __len__ method like pandas Series/DataFrame, numpy arrays
            try:
                is_empty = len(data_to_validate) == 0
            except TypeError: # Some types might have __len__ but raise TypeError for empty check
                pass

        if is_empty:
            error_msg = f"Data associated with key '{self._input_data_key}' in pipeline context is empty or invalid. Validation failed."
            self._logger.error(error_msg)
            raise PipelineStageError(self.name, error_msg)

        context.add_result(f"{self._input_data_key}_validation_status", "PASSED")
        context.add_result(f"{self._input_data_key}_validated_value_type", type(data_to_validate).__name__)
        self._logger.info(f"Data validation successful for '{self._input_data_key}'. Data is present and not empty.")
        return context

    def on_error(self, context: PipelineContext, error: Exception) -> None:
        """
        Custom error handler for DataValidationStage.

        This method overrides the default `on_error` behavior to provide more specific
        logging and context updates related to validation failures. It ensures that
        even if the pipeline continues, the failure of this validation step is clearly
        marked in the context's results.

        Args:
            context: The current `PipelineContext` object at the time of the error.
            error: The exception object that was caught, which is typically a
                   `PipelineStageError` raised by this stage's `execute` method.
        """
        self._logger.critical(
            f"Validation failed critically in {self.name} for key '{self._input_data_key}'. "
            f"Original error type: {type(error).__name__}. Message: {error}."
            f" Marking validation as FAILED in context.", exc_info=True
        )
        # Mark the validation status as FAILED in the context's results
        context.add_result(f"{self._input_data_key}_validation_status", "FAILED")
        # Call the base implementation to ensure the error is also added to the context's errors list
        super().on_error(context, error)


# Setup basic logging configuration for demonstration purposes.
# In a larger application, this would typically be configured centrally
# (e.g., in a `main.py` or `config` module) rather than within a library module.
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
