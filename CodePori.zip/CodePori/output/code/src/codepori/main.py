import argparse
import logging
import sys
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Dict, List, Optional, Type
import yaml

# --- Constants and Configuration Defaults ---
DEFAULT_CONFIG_FILE = "config.yaml"
DEFAULT_LOG_LEVEL = "INFO"

# --- Logger Setup ---
class AppLogger:
    """Manages the application's logging configuration."""

    _logger: Optional[logging.Logger] = None

    @classmethod
    def get_logger(cls, name: str = "codepori", level: str = DEFAULT_LOG_LEVEL) -> logging.Logger:
        """
        Retrieves or creates a logger instance for the application.

        Args:
            name: The name of the logger.
            level: The logging level (e.g., 'DEBUG', 'INFO', 'WARNING', 'ERROR').

        Returns:
            A configured logging.Logger instance.
        """
        if cls._logger is None:
            cls._logger = logging.getLogger(name)
            cls._logger.setLevel(level.upper())

            # Prevent adding multiple handlers if get_logger is called multiple times
            if not cls._logger.handlers:
                formatter = logging.Formatter(
                    '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
                )
                console_handler = logging.StreamHandler(sys.stdout)
                console_handler.setFormatter(formatter)
                cls._logger.addHandler(console_handler)

        return cls._logger

# Initialize a global logger instance for convenience
logger = AppLogger.get_logger()

# --- Core Pipeline Components (Minimal Definitions for Main.py Scope) ---
# In a larger project, these would typically be imported from `src.codepori.core`
# These definitions are included here to make main.py self-contained and runnable.


class PipelineContext:
    """
    A central context object that carries data and state across pipeline stages.

    Attributes:
        data (Dict[str, Any]): A dictionary to store arbitrary data.
        logger (logging.Logger): A logger instance for the context.
    """

    def __init__(self, initial_data: Optional[Dict[str, Any]] = None):
        """
        Initializes the PipelineContext.

        Args:
            initial_data: Optional dictionary to pre-populate the context data.
        """
        self.data: Dict[str, Any] = initial_data if initial_data is not None else {}
        self.logger = AppLogger.get_logger(__name__ + ".PipelineContext")
        self.logger.info("PipelineContext initialized.")

    def get(self, key: str, default: Any = None) -> Any:
        """
        Retrieves a value from the context data.

        Args:
            key: The key of the data to retrieve.
            default: The default value to return if the key is not found.

        Returns:
            The value associated with the key, or the default value.
        """
        return self.data.get(key, default)

    def set(self, key: str, value: Any):
        """
        Sets a value in the context data.

        Args:
            key: The key for the data.
            value: The value to set.
        """
        self.data[key] = value
        self.logger.debug(f"Context updated: set '{key}'.")

    def __str__(self) -> str:
        """Returns a string representation of the context data."""
        return f"PipelineContext(data={self.data})"


class BaseStage(ABC):
    """
    Abstract base class for all pipeline stages.

    Each concrete stage must implement the `execute` method.
    """

    def __init__(self, name: str, config: Optional[Dict[str, Any]] = None):
        """
        Initializes a base pipeline stage.

        Args:
            name: The name of the stage.
            config: Configuration parameters specific to this stage.
        """
        self.name = name
        self.config = config if config is not None else {}
        self.logger = AppLogger.get_logger(f"codepori.stages.{self.name}")
        self.logger.debug(f"Stage '{self.name}' initialized with config: {self.config}")

    @abstractmethod
    def execute(self, context: PipelineContext) -> PipelineContext:
        """
        Abstract method to be implemented by concrete stages.

        This method defines the core logic of the stage, processing the context
        and returning an updated context.

        Args:
            context: The PipelineContext object containing current pipeline state.

        Returns:
            The updated PipelineContext object after stage execution.
        """
        pass

    def __str__(self) -> str:
        """Returns a string representation of the stage."""
        return f"Stage({self.name})"


class Pipeline:
    """
    Orchestrates the execution of a sequence of pipeline stages.
    """

    def __init__(self, stages: List[BaseStage]):
        """
        Initializes the Pipeline with a list of stages.

        Args:
            stages: A list of BaseStage instances to be executed sequentially.
        """
        if not all(isinstance(stage, BaseStage) for stage in stages):
            raise TypeError("All pipeline components must be instances of BaseStage.")
        self.stages = stages
        self.logger = AppLogger.get_logger(__name__ + ".Pipeline")
        self.logger.info(f"Pipeline initialized with {len(self.stages)} stages.")
        for stage in self.stages:
            self.logger.debug(f" - Added stage: {stage.name}")

    def run(self, context: PipelineContext) -> PipelineContext:
        """
        Executes the pipeline by running each stage in sequence.

        Args:
            context: The initial PipelineContext to start the pipeline with.

        Returns:
            The final PipelineContext after all stages have been executed.
        """
        self.logger.info("Starting pipeline execution.")
        current_context = context
        for i, stage in enumerate(self.stages):
            self.logger.info(f"Executing stage {i+1}/{len(self.stages)}: {stage.name}")
            try:
                current_context = stage.execute(current_context)
                self.logger.debug(f"Stage '{stage.name}' completed.")
            except Exception as e:
                self.logger.error(
                    f"Error during stage '{stage.name}' execution: {e}", exc_info=True
                )
                # Decide on error handling: re-raise, stop, or log and continue
                raise  # Re-raise to stop pipeline execution on error
        self.logger.info("Pipeline execution completed.")
        return current_context


# --- Configuration Management ---
class ConfigLoader:
    """
    Handles loading configuration from a YAML file.
    """

    def __init__(self, config_path: Path):
        """
        Initializes the ConfigLoader.

        Args:
            config_path: The path to the configuration YAML file.
        """
        self.config_path = config_path
        self.logger = AppLogger.get_logger(__name__ + ".ConfigLoader")
        self.logger.debug(f"ConfigLoader initialized for path: {self.config_path}")

    def load(self) -> Dict[str, Any]:
        """
        Loads and parses the YAML configuration file.

        Returns:
            A dictionary containing the loaded configuration.

        Raises:
            FileNotFoundError: If the configuration file does not exist.
            yaml.YAMLError: If there is an error parsing the YAML file.
        """
        if not self.config_path.exists():
            self.logger.error(f"Configuration file not found: {self.config_path}")
            raise FileNotFoundError(f"Config file not found: {self.config_path}")

        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                config_data = yaml.safe_load(f)
            self.logger.info(f"Configuration loaded successfully from {self.config_path}")
            return config_data if config_data is not None else {}
        except yaml.YAMLError as e:
            self.logger.error(f"Error parsing YAML config file {self.config_path}: {e}")
            raise
        except Exception as e:
            self.logger.error(f"An unexpected error occurred while loading config: {e}")
            raise


# --- Command-Line Interface (CLI) Application ---
class CodeporiCLI:
    """
    Main command-line interface application for the Codepori project.

    Responsible for parsing arguments, loading configuration, building the pipeline,
    creating context, and triggering pipeline execution.
    """

    def __init__(self):
        """
        Initializes the CodeporiCLI application.
        """
        self.logger = AppLogger.get_logger(__name__ + ".CodeporiCLI")
        self.config: Dict[str, Any] = {}
        self.project_description_path: Optional[Path] = None

    def _parse_args(self) -> argparse.Namespace:
        """
        Parses command-line arguments.

        Returns:
            An argparse.Namespace object containing parsed arguments.
        """
        parser = argparse.ArgumentParser(
            description="Codepori: An automated code generation pipeline."
        )
        parser.add_argument(
            "--project-description",
            type=Path,
            required=True,
            help="Path to the project description file (e.g., Markdown, Text)."
        )
        parser.add_argument(
            "--config",
            type=Path,
            default=DEFAULT_CONFIG_FILE,
            help=f"Path to the configuration YAML file (default: {DEFAULT_CONFIG_FILE})."
        )
        parser.add_argument(
            "--log-level",
            type=str,
            default=DEFAULT_LOG_LEVEL,
            choices=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
            help=f"Set the logging level (default: {DEFAULT_LOG_LEVEL})."
        )

        args = parser.parse_args()
        self.logger.debug(f"Parsed arguments: {args}")
        return args

    def _load_application_config(self, config_path: Path) -> None:
        """
        Loads the application configuration from the specified path.

        Args:
            config_path: The path to the configuration file.
        """
        try:
            config_loader = ConfigLoader(config_path)
            self.config = config_loader.load()
            self.logger.info(f"Application configuration loaded from {config_path}.")
        except (FileNotFoundError, yaml.YAMLError) as e:
            self.logger.critical(f"Failed to load application configuration: {e}")
            sys.exit(1)

    def _build_pipeline(self) -> Pipeline:
        """
        Constructs the pipeline based on the loaded configuration.

        This method assumes the config contains a 'pipeline_stages' key,
        which lists dictionaries describing each stage.
        Each stage dictionary should have 'name' and 'class' keys,
        and optionally 'config' for stage-specific parameters.
        The 'class' value should be the fully qualified name of the stage class.

        For this initial iteration, we'll use dummy stages.
        """
        pipeline_stages_config = self.config.get("pipeline_stages", [])
        if not pipeline_stages_config:
            self.logger.warning("No pipeline stages defined in config. Building an empty pipeline.")
            return Pipeline([])

        registered_stages: Dict[str, Type[BaseStage]] = {
            "example_stage_one": ExampleStageOne,
            "example_stage_two": ExampleStageTwo,
            "example_stage_three": ExampleStageThree,
            # In a real scenario, these would be dynamically loaded from modules
            # e.g., using importlib.import_module and getattr
        }

        stages_instances: List[BaseStage] = []
        for stage_conf in pipeline_stages_config:
            stage_name = stage_conf.get("name", "UnnamedStage")
            stage_class_name = stage_conf.get("class")
            stage_params = stage_conf.get("config", {})

            if not stage_class_name:
                self.logger.error(f"Stage '{stage_name}' has no 'class' specified. Skipping.")
                continue

            stage_class = registered_stages.get(stage_class_name)
            if stage_class is None:
                self.logger.error(
                    f"Unknown pipeline stage class '{stage_class_name}' for stage '{stage_name}'. Skipping."
                )
                continue

            try:
                stage_instance = stage_class(name=stage_name, config=stage_params)
                stages_instances.append(stage_instance)
                self.logger.debug(f"Instantiated stage: {stage_name} ({stage_class_name})")
            except TypeError as e:
                self.logger.error(f"Error instantiating stage '{stage_name}' ({stage_class_name}): {e}")
                sys.exit(1) # Fail fast if a stage cannot be instantiated correctly

        self.logger.info(f"Pipeline built with {len(stages_instances)} stages.")
        return Pipeline(stages_instances)

    def _create_initial_context(self) -> PipelineContext:
        """
        Creates the initial PipelineContext.

        The project description content is loaded into the context.

        Returns:
            An initialized PipelineContext object.
        """
        if not self.project_description_path or not self.project_description_path.exists():
            self.logger.critical(
                f"Project description file not found: {self.project_description_path}"
            )
            sys.exit(1)

        try:
            with open(self.project_description_path, 'r', encoding='utf-8') as f:
                project_description_content = f.read()
            self.logger.info(f"Project description loaded from {self.project_description_path}.")
        except IOError as e:
            self.logger.critical(
                f"Error reading project description file {self.project_description_path}: {e}"
            )
            sys.exit(1)

        initial_data = {
            "project_description_path": str(self.project_description_path),
            "project_description_content": project_description_content,
            "config": self.config # Pass the full config to context if needed by stages
        }
        return PipelineContext(initial_data=initial_data)

    def run(self) -> None:
        """
        Runs the main application logic:
        1. Parses arguments.
        2. Configures logging.
        3. Loads application configuration.
        4. Builds the pipeline.
        5. Creates the initial context.
        6. Executes the pipeline.
        """
        self.logger.info("Codepori CLI application started.")
        try:
            args = self._parse_args()
            AppLogger.get_logger().setLevel(args.log_level.upper()) # Re-set global log level
            self.project_description_path = args.project_description

            self._load_application_config(args.config)

            # Dummy Stage Implementations for illustration
            # In production, these would be in src/codepori/stages/ or similar
            class ExampleStageOne(BaseStage):
                def execute(self, context: PipelineContext) -> PipelineContext:
                    self.logger.info(f"[{self.name}] Executing.")
                    input_desc = context.get("project_description_content", "N/A")
                    self.logger.info(f"[{self.name}] Received description content of length {len(input_desc)}.")
                    context.set("processed_data_stage1", "Data from Stage One")
                    self.logger.info(f"[{self.name}] Finished execution.")
                    return context

            class ExampleStageTwo(BaseStage):
                def execute(self, context: PipelineContext) -> PipelineContext:
                    self.logger.info(f"[{self.name}] Executing.")
                    data_from_prev = context.get("processed_data_stage1")
                    self.logger.info(f"[{self.name}] Received data: '{data_from_prev}'.")
                    context.set("processed_data_stage2", "Data from Stage Two")
                    self.logger.info(f"[{self.name}] Finished execution.")
                    return context

            class ExampleStageThree(BaseStage):
                def execute(self, context: PipelineContext) -> PipelineContext:
                    self.logger.info(f"[{self.name}] Executing.")
                    data_from_prev = context.get("processed_data_stage2")
                    self.logger.info(f"[{self.name}] Received data: '{data_from_prev}'.")
                    context.set("final_output", "Final data from Stage Three")
                    self.logger.info(f"[{self.name}] Finished execution. Final Context: {context}")
                    return context
            # End Dummy Stage Implementations

            pipeline = self._build_pipeline()
            initial_context = self._create_initial_context()
            final_context = pipeline.run(initial_context)

            self.logger.info("Codepori pipeline executed successfully.")
            self.logger.info(f"Final context data: {final_context.data}")

        except Exception as e:
            self.logger.critical(f"An unhandled error occurred: {e}", exc_info=True)
            sys.exit(1)


# --- Main Entry Point ---
if __name__ == "__main__":
    # Create a dummy config.yaml and project_description.md for local testing
    # In a real scenario, these would be pre-existing files.
    dummy_config_content = """
    pipeline_stages:
      - name: Stage A - Initial Processing
        class: example_stage_one
        config:
          param1: valueA
      - name: Stage B - Intermediate Logic
        class: example_stage_two
        config:
          param2: valueB
      - name: Stage C - Final Output
        class: example_stage_three
          config:
            param3: valueC
    """
    dummy_project_desc_content = """
# Project Description for Codepori

This is a sample project description to test the Codepori application.
It outlines the high-level requirements for the code to be generated.

## Module 1: Core Utilities
- Functionality A
- Functionality B

## Module 2: Data Processing
- Data Ingestion
- Data Transformation

Expected output is a set of Python files adhering to best practices.
"""

    config_path_for_test = Path(DEFAULT_CONFIG_FILE)
    project_desc_path_for_test = Path("project_description.md")

    if not config_path_for_test.exists():
        with open(config_path_for_test, "w", encoding="utf-8") as f:
            f.write(dummy_config_content)
        AppLogger.get_logger().info(f"Created dummy config file: {config_path_for_test}")

    if not project_desc_path_for_test.exists():
        with open(project_desc_path_for_test, "w", encoding="utf-8") as f:
            f.write(dummy_project_desc_content)
        AppLogger.get_logger().info(f"Created dummy project description file: {project_desc_path_for_test}")

    # To run this script:
    # python src/codepori/main.py --project-description project_description.md --config config.yaml --log-level INFO
    cli = CodeporiCLI()
    cli.run()
