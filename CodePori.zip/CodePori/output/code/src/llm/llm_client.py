import os
import logging
import json
import httpx
import asyncio
from enum import Enum
from typing import Dict, Any, Optional, Union, List, AsyncGenerator

# Configure a module-level logger
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Prevent adding multiple handlers if the module is reloaded
if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)

class LLMClientError(Exception):
    """Base exception for LLMClient operations."""
    pass

class LLMAPIError(LLMClientError):
    """Exception raised for errors returned by the LLM API (4xx, 5xx)."""
    def __init__(self, message: str, status_code: int = 500, details: Optional[Dict] = None):
        """
        Initializes the LLMAPIError.

        Args:
            message (str): The error message.
            status_code (int): The HTTP status code returned by the API.
            details (Optional[Dict]): Additional details from the API response.
        """
        super().__init__(message)
        self.status_code = status_code
        self.details = details or {}

class LLMConfigurationError(LLMClientError):
    """Exception raised for invalid LLM client configuration."""
    pass

class LLMTooManyRequestsError(LLMAPIError):
    """Exception raised for 429 Too Many Requests errors."""
    pass

class LLMNetworkError(LLMClientError):
    """Exception raised for network-related issues (e.g., connection errors)."""
    pass

class LLMModelError(LLMAPIError):
    """Exception raised when the requested model is unavailable or invalid (e.g., 404 with model message)."""
    pass

class LLMClient:
    """
    A robust and flexible asynchronous client for interacting with Large Language Models (LLMs).

    This client acts as a shim/driver, providing a high-level abstraction over HTTP communication
    with LLM providers. It handles API key management, base URL configuration, timeouts, retries
    with exponential backoff, and comprehensive error handling. It is designed to be provider-agnostic
    where possible, using common request/response patterns (e.g., OpenAI-compatible chat completions).

    Attributes:
        _base_url (str): The base URL for the LLM API endpoint.
        _api_key (str): The API key for authentication with the LLM service.
        _default_model (str): The default LLM model to use for requests.
        _timeout (float): The default timeout for HTTP requests in seconds.
        _max_retries (int): The maximum number of retries for transient errors.
        _backoff_factor (float): The factor by which to multiply the delay between retries.
        _client (httpx.AsyncClient): The underlying asynchronous HTTP client instance.
    """

    DEFAULT_TIMEOUT_SECONDS: float = 60.0
    DEFAULT_MAX_RETRIES: int = 3
    DEFAULT_BACKOFF_FACTOR: float = 0.5
    # Default model is set to a common chat model, adjust if targeting a different LLM type
    DEFAULT_MODEL: str = "gpt-3.5-turbo"

    def __init__(
        self,
        base_url: Optional[str] = None,
        api_key: Optional[str] = None,
        default_model: Optional[str] = None,
        timeout: Optional[float] = None,
        max_retries: Optional[int] = None,
        backoff_factor: Optional[float] = None,
        verify_ssl: bool = True
    ):
        """
        Initializes the LLMClient with necessary configuration.

        Configuration values can be provided directly as arguments. If not provided,
        the client will attempt to load them from environment variables:
        - `LLM_BASE_URL` for `base_url`
        - `LLM_API_KEY` for `api_key`
        - `LLM_DEFAULT_MODEL` for `default_model`

        Args:
            base_url (str, optional): The base URL for the LLM API. Defaults to env var `LLM_BASE_URL`.
            api_key (str, optional): The API key for authentication. Defaults to env var `LLM_API_KEY`.
            default_model (str, optional): The default model to use. Defaults to env var `LLM_DEFAULT_MODEL` or "gpt-3.5-turbo".
            timeout (float, optional): Request timeout in seconds. Defaults to 60.0.
            max_retries (int, optional): Maximum number of retries for transient errors. Defaults to 3.
            backoff_factor (float, optional): Factor for exponential backoff (delay = (2 ** retries) * factor). Defaults to 0.5.
            verify_ssl (bool): Whether to verify SSL certificates for HTTPS connections. Defaults to True.

        Raises:
            LLMConfigurationError: If essential configuration like `base_url` or `api_key` is missing.
        """
        self._base_url = base_url or os.getenv("LLM_BASE_URL")
        self._api_key = api_key or os.getenv("LLM_API_KEY")
        self._default_model = default_model or os.getenv("LLM_DEFAULT_MODEL", self.DEFAULT_MODEL)
        self._timeout = timeout if timeout is not None else self.DEFAULT_TIMEOUT_SECONDS
        self._max_retries = max_retries if max_retries is not None else self.DEFAULT_MAX_RETRIES
        self._backoff_factor = backoff_factor if backoff_factor is not None else self.DEFAULT_BACKOFF_FACTOR

        if not self._base_url:
            raise LLMConfigurationError(
                "LLM base URL must be provided or set via LLM_BASE_URL environment variable."
            )
        if not self._api_key:
            raise LLMConfigurationError(
                "LLM API key must be provided or set via LLM_API_KEY environment variable."
            )

        # Prepare default headers for the httpx client
        default_headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json"
        }

        self._client = httpx.AsyncClient(
            base_url=self._base_url,
            timeout=self._timeout,
            headers=default_headers,
            verify=verify_ssl
        )
        logger.info(f"LLMClient initialized successfully. Base URL: {self._base_url}, Default Model: {self._default_model}")

    async def _send_request(
        self,
        endpoint: str,
        method: str,
        payload: Dict[str, Any],
        stream: bool = False,
        extra_headers: Optional[Dict[str, str]] = None
    ) -> httpx.Response:
        """
        Sends an HTTP request to the LLM API with built-in retry logic and error handling.

        Args:
            endpoint (str): The API endpoint path relative to the client's base URL (e.g., "/v1/chat/completions").
            method (str): The HTTP method to use (e.g., "POST", "GET").
            payload (Dict[str, Any]): The JSON payload to send with the request body.
            stream (bool): If True, enables streaming of the response. Useful for server-sent events.
            extra_headers (Optional[Dict[str, str]]): Additional headers to merge with default client headers.

        Returns:
            httpx.Response: The HTTP response object from the LLM API.

        Raises:
            LLMAPIError: If the LLM API returns a non-success status code (4xx or 5xx, excluding 429).
            LLMTooManyRequestsError: If a 429 (Too Many Requests) status code is received, even after retries.
            LLMNetworkError: If a network-related issue prevents the request from completing.
            LLMClientError: For any other unexpected errors during the request sending process.
        """
        url = self._client.base_url.join(endpoint)
        headers = self._client.headers.copy()
        if extra_headers:
            headers.update(extra_headers)

        retries = 0
        while retries <= self._max_retries:
            try:
                logger.debug(f"Attempt {retries + 1}/{self._max_retries + 1}: Sending {method} request to {url} with payload: {json.dumps(payload)}")
                response = await self._client.request(
                    method=method,
                    url=url,
                    json=payload,
                    timeout=self._timeout,
                    headers=headers,
                    stream=stream
                )
                response.raise_for_status()  # Raises HTTPStatusError for 4xx/5xx responses
                return response
            except httpx.HTTPStatusError as e:
                status_code = e.response.status_code
                response_text = e.response.text
                logger.warning(f"HTTP error {status_code} for {url}: {response_text}")

                error_details = {"status_code": status_code, "response": response_text}

                if status_code == 429:  # Too Many Requests
                    delay = (2 ** retries) * self._backoff_factor
                    logger.info(f"Rate limited. Retrying in {delay:.2f} seconds... (attempt {retries + 1}/{self._max_retries})")
                    await asyncio.sleep(delay)
                    retries += 1
                    if retries > self._max_retries:
                        raise LLMTooManyRequestsError(
                            f"Too many requests after {self._max_retries} retries.",
                            status_code=status_code, details=error_details
                        )
                elif 400 <= status_code < 500:
                    # Client errors (4xx) generally indicate a bad request and are not retried (except 429).
                    if status_code == 404 and "model" in response_text.lower():
                        raise LLMModelError(
                            f"Model not found or invalid: {response_text}",
                            status_code=status_code, details=error_details
                        )
                    raise LLMAPIError(
                        f"LLM API client error: {response_text}",
                        status_code=status_code, details=error_details
                    )
                else:  # Server errors (5xx)
                    delay = (2 ** retries) * self._backoff_factor
                    logger.error(
                        f"Server error {status_code} for {url}. Retrying in {delay:.2f} seconds... "
                        f"(attempt {retries + 1}/{self._max_retries})"
                    )
                    await asyncio.sleep(delay)
                    retries += 1
                    if retries > self._max_retries:
                        raise LLMAPIError(
                            f"LLM API server error after {self._max_retries} retries: {response_text}",
                            status_code=status_code, details=error_details
                        )
            except httpx.RequestError as e:
                # Network errors (connection refused, DNS errors, timeout before response headers, etc.)
                delay = (2 ** retries) * self._backoff_factor
                logger.error(
                    f"Network error during request to {url}: {e}. Retrying in {delay:.2f} seconds... "
                    f"(attempt {retries + 1}/{self._max_retries})"
                )
                await asyncio.sleep(delay)
                retries += 1
                if retries > self._max_retries:
                    raise LLMNetworkError(f"Network error after {self._max_retries} retries: {e}")
            except Exception as e:
                logger.exception(f"An unexpected error occurred during request to {url}: {e}")
                raise LLMClientError(f"An unexpected error occurred during LLM request: {e}")

        raise LLMClientError("Failed to send request after maximum allowed retries.") # Fallback, should ideally not be reached

    async def generate(
        self,
        prompt: str,
        model: Optional[str] = None,
        temperature: float = 0.7,
        max_tokens: int = 150,
        stop_sequences: Optional[List[str]] = None,
        stream: bool = False,
        **kwargs: Any
    ) -> Union[str, AsyncGenerator[str, None]]:
        """
        Generates text using the configured LLM, primarily targeting chat completion-style APIs.

        This method constructs a request payload suitable for many modern LLM APIs (e.g., OpenAI's
        `chat/completions` endpoint) and sends it. If `messages` is provided in `kwargs`,
        it will override the default `prompt` to `messages` conversion.

        Args:
            prompt (str): The input text prompt for the LLM. This will be wrapped into a user message.
            model (str, optional): The specific model to use for this request. Defaults to the client's `_default_model`.
            temperature (float): Controls the randomness of the output. Higher values lead to more creative results.
                                 Defaults to 0.7.
            max_tokens (int): The maximum number of tokens to generate in the response. Defaults to 150.
            stop_sequences (List[str], optional): A list of string sequences that, if generated, will cause the
                                                  model to stop generating further tokens.
            stream (bool): If True, the response will be streamed back as an asynchronous generator yielding text chunks.
                           If False, the complete generated text is returned as a single string. Defaults to False.
            **kwargs (Any): Additional parameters to pass directly into the LLM API call's JSON payload.
                            This allows for fine-grained control over specific API features (e.g., `top_p`, `n`,
                            or custom `messages` array for complex chat scenarios).

        Returns:
            Union[str, AsyncGenerator[str, None]]: The generated text as a string (if `stream` is False) or
            an asynchronous generator yielding strings (if `stream` is True).

        Raises:
            LLMClientError: If any error occurs during the text generation process, including configuration,
                            network, or API-specific errors.
        """
        model_to_use = model or self._default_model

        payload: Dict[str, Any] = {
            "model": model_to_use,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": stream,
            **kwargs
        }

        # Standardize 'prompt' into a 'messages' array for chat completion endpoints
        if "messages" not in kwargs: # If user didn't provide custom messages in kwargs
            payload["messages"] = [
                {"role": "user", "content": prompt}
            ]
        else:
            # If 'messages' is provided in kwargs, it overrides the simple 'prompt' conversion
            # We'll also ensure 'prompt' isn't redundantly passed if 'messages' is present
            pass # kwargs already handled it

        if stop_sequences:
            payload["stop"] = stop_sequences  # Common name for stop sequences

        # Assuming a common chat completion endpoint structure
        endpoint = "/v1/chat/completions"

        logger.info(f"Initiating LLM text generation request for model: {model_to_use}, stream: {stream}")

        try:
            response = await self._send_request(
                endpoint=endpoint,
                method="POST",
                payload=payload,
                stream=stream
            )

            if stream:
                return self._parse_streamed_response(response)
            else:
                return self._parse_non_streamed_response(response)
        except Exception as e:
            logger.error(f"Failed to generate text from LLM: {e}", exc_info=True)
            raise

    async def _parse_streamed_response(self, response: httpx.Response) -> AsyncGenerator[str, None]:
        """
        Parses a streamed response from the LLM API, typically in Server-Sent Events (SSE) format.

        Args:
            response (httpx.Response): The streaming HTTP response object.

        Yields:
            str: Chunks of generated text content as they are received.

        Raises:
            LLMClientError: If there's an error decoding or parsing the streamed chunks.
        """
        async for chunk_bytes in response.aiter_bytes():
            try:
                # Decode the chunk as UTF-8
                decoded_chunk = chunk_bytes.decode("utf-8")

                # Process each line, assuming 'data: ' prefix for JSON payloads
                for line in decoded_chunk.splitlines():
                    line = line.strip()
                    if not line: # Skip empty lines
                        continue
                    if line.startswith("data: "):
                        data_str = line[len("data: "):]
                        if data_str == "[DONE]": # Standard signal for stream end
                            return
                        try:
                            data = json.loads(data_str)
                            # Extract content from common OpenAI-like streaming structure
                            if "choices" in data and data["choices"]:
                                delta = data["choices"][0].get("delta", {})
                                content = delta.get("content")
                                if content:
                                    yield content
                        except json.JSONDecodeError:
                            logger.warning(f"Could not decode JSON from streamed chunk data: '{data_str}'")
                    else:
                        logger.debug(f"Received non-data line in stream: '{line}'")
            except UnicodeDecodeError as e:
                logger.error(f"UnicodeDecodeError while processing streamed chunk: {e}")
                raise LLMClientError(f"Failed to decode streamed LLM response: {e}")
            except Exception as e:
                logger.error(f"Error processing streamed chunk: {e}", exc_info=True)
                raise LLMClientError(f"Error processing streamed LLM response: {e}")

    def _parse_non_streamed_response(self, response: httpx.Response) -> str:
        """
        Parses a non-streamed HTTP response from the LLM API to extract the generated text.

        Args:
            response (httpx.Response): The complete HTTP response object.

        Returns:
            str: The extracted generated text content.

        Raises:
            LLMClientError: If the response cannot be decoded as JSON or if the expected
                            structure (e.g., 'choices') is missing or malformed.
        """
        try:
            data = response.json()
            if "choices" in data and data["choices"]:
                choice = data["choices"][0]
                # Handle both chat completion ('message' field) and standard completion ('text' field)
                if "message" in choice and "content" in choice["message"]:
                    return choice["message"]["content"]
                elif "text" in choice:
                    return choice["text"]
                else:
                    raise LLMClientError(f"Unexpected response structure in choice: {choice}. Expected 'message' or 'text'.")
            else:
                raise LLMClientError(f"No 'choices' found in LLM response: {data}")
        except json.JSONDecodeError as e:
            logger.error(f"Failed to decode JSON from LLM response: {e}. Response text: {response.text}")
            raise LLMClientError(f"Invalid JSON response from LLM API: {e}")
        except Exception as e:
            logger.error(f"Error parsing LLM response: {e}. Full response text: {response.text}", exc_info=True)
            raise LLMClientError(f"Failed to parse LLM response due to unexpected error: {e}")

    async def __aenter__(self):
        """Asynchronous context manager entry point, returns self."""
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Asynchronous context manager exit point, ensures the httpx client is closed."""
        await self.close()

    async def close(self):
        """Closes the underlying httpx client, releasing network resources."""
        if self._client:
            await self._client.aclose()
            logger.info("LLMClient httpx client closed.")

# Example usage for direct execution and basic testing
async def main():
    # Set dummy environment variables for demonstration purposes.
    # In a real scenario, these would be properly configured (e.g., in a .env file or deployment config).
    os.environ["LLM_BASE_URL"] = "http://localhost:8000"  # Replace with actual LLM server URL
    os.environ["LLM_API_KEY"] = "sk-dummykey"

    print("\n--- Initializing LLMClient for demonstration ---")
    try:
        # Using async with ensures the client is properly closed
        async with LLMClient(timeout=10.0, max_retries=1) as client:
            print("LLMClient instance created successfully.")
            print(f"Configured Base URL: {client._base_url}")
            print(f"Configured Default Model: {client._default_model}")

            # --- Demonstrate non-streamed generation ---
            print("\n--- Attempting non-streamed text generation ---")
            try:
                prompt_non_stream = "What is the main goal of clean code practices?"
                print(f"Prompt: '{prompt_non_stream}'")
                response_content = await client.generate(
                    prompt=prompt_non_stream,
                    model="gpt-3.5-turbo",  # Use a common chat model name
                    max_tokens=100,
                    temperature=0.5
                )
                print(f"Generated (non-streamed): {response_content[:200]}...")
            except LLMClientError as e:
                print(f"Error during non-streamed generation: {e}")
            except httpx.HTTPStatusError as e:
                print(f"HTTP Status Error: {e.response.status_code} - {e.response.text}")
            except httpx.RequestError as e:
                print(f"Network/Request Error during non-streamed generation: {e}. Please ensure an LLM server is running at {os.environ['LLM_BASE_URL']}.")
            except Exception as e:
                print(f"An unexpected error occurred during non-streamed generation: {e}")

            # --- Demonstrate streamed generation ---
            print("\n--- Attempting streamed text generation ---")
            try:
                prompt_stream = "Explain the concept of Dependency Inversion Principle in software design."
                print(f"Prompt: '{prompt_stream}'")
                full_streamed_content = []
                async for chunk in await client.generate(
                    prompt=prompt_stream,
                    model="gpt-3.5-turbo",
                    max_tokens=200,
                    stream=True,
                    temperature=0.7
                ):
                    print(chunk, end='', flush=True) # Print chunks as they arrive
                    full_streamed_content.append(chunk)
                print(f"\n\nGenerated (streamed, total length: {len(''.join(full_streamed_content))} chars)")
            except LLMClientError as e:
                print(f"Error during streamed generation: {e}")
            except httpx.HTTPStatusError as e:
                print(f"HTTP Status Error: {e.response.status_code} - {e.response.text}")
            except httpx.RequestError as e:
                print(f"Network/Request Error during streamed generation: {e}. Please ensure an LLM server is running at {os.environ['LLM_BASE_URL']}.")
            except Exception as e:
                print(f"An unexpected error occurred during streamed generation: {e}")

    except LLMConfigurationError as e:
        print(f"Configuration Error: {e}. Please set LLM_BASE_URL and LLM_API_KEY environment variables.")
    except Exception as e:
        print(f"An unhandled error occurred during LLMClient initialization: {e}")
    finally:
        # Clean up environment variables set for demonstration
        os.environ.pop("LLM_BASE_URL", None)
        os.environ.pop("LLM_API_KEY", None)
        os.environ.pop("LLM_DEFAULT_MODEL", None)

# This block allows the module to be executed directly for demonstration or testing.
if __name__ == "__main__":
    # Ensure logging is configured when running directly
    if not logger.handlers:
        logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    asyncio.run(main())
