from __future__ import annotations
from pathlib import Path
from typing import Any
import inspect, asyncio

from src.models.plan import Plan, FileAction, normalize_plan

def _syncify(awaitable):
    try:
        # If no running loop -> safe to asyncio.run()
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(awaitable)
    # Running loop exists; create a new loop in a thread is heavy;
    # for our tests we don't expect this branch. As a fallback:
    loop = asyncio.new_event_loop()
    try:
        return loop.run_until_complete(awaitable)
    finally:
        loop.close()

class GenerateStage:
    def __init__(self, llm_client: Any):
        self.llm = llm_client

    def _gen(self, prompt: str) -> str:
        res = self.llm.generate(prompt)
        if inspect.isawaitable(res):
            res = _syncify(res)
        return "" if res is None else str(res)

    def run(self, context: Any, base_dir: str | Path) -> Any:
        base = Path(base_dir)
        plan = normalize_plan(getattr(context, "plan", None) or Plan(actions=[]))

        for a in plan.actions:
            act = (a.action or "create").lower()
            target = base / a.path

            if act in ("no_action", "skip", "none"):
                continue

            if act in ("create", "overwrite", "write"):
                prompt = a.prompt or f"Create file {a.path}"
                code = self._gen(prompt)
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_text(code, encoding="utf-8")

            elif act == "append":
                prompt = a.prompt or f"Append to file {a.path}"
                code = self._gen(prompt)
                target.parent.mkdir(parents=True, exist_ok=True)
                with target.open("a", encoding="utf-8") as f:
                    f.write(code)

            elif act in ("modify", "update", "edit"):
                before = target.read_text(encoding="utf-8") if target.exists() else ""
                prompt = a.prompt or f"Modify {a.path}.\n\nCurrent:\n```\n{before}\n```\n"
                code = self._gen(prompt)
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_text(code, encoding="utf-8")

            else:
                if a.content is not None:
                    target.parent.mkdir(parents=True, exist_ok=True)
                    target.write_text(a.content, encoding="utf-8")

        setattr(context, "plan", plan)
        return context

__all__ = ["GenerateStage"]
