# /Users/williamwhite/CodePori/output/code/src/stages/generate.py
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Union, List

from src.models.plan import Plan, FileAction, normalize_plan


@dataclass
class GenerateResult:
    written: List[str]
    overwritten: List[str]


class GenerateStage:
    """
    Writes files described by a Plan.
    - CREATE fails if the file exists.
    - OVERWRITE replaces existing content.
    """

    def run(self, plan_like: Union[Plan, Mapping[str, Any]]) -> GenerateResult:
        plan = normalize_plan(plan_like)
        written: List[str] = []
        overwritten: List[str] = []

        for spec in plan.files:
            p = Path(spec.path)
            p.parent.mkdir(parents=True, exist_ok=True)

            if p.exists():
                if spec.action == FileAction.CREATE:
                    raise FileExistsError(f"Refusing to CREATE existing file: {p}")
                elif spec.action == FileAction.OVERWRITE:
                    p.write_text(spec.content, encoding="utf-8")
                    overwritten.append(str(p))
                else:
                    raise ValueError(f"Unknown action {spec.action!r}")
            else:
                p.write_text(spec.content, encoding="utf-8")
                written.append(str(p))

        return GenerateResult(written=written, overwritten=overwritten)
