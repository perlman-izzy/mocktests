import json
from typing import Any, Dict, List, Optional

class PlanStage:
    def __init__(self, llm_client: Any, **kwargs):
        self._llm_client = llm_client

    def run(self, context: Any) -> Any:
        project_description = context.initial_prompt
        if not project_description:
            return context

        llm_prompt = self._construct_llm_prompt(project_description)
        
        llm_response = self._llm_client.invoke(llm_prompt)

        parsed_plan = self._parse_llm_output(llm_response)
        context.plan = parsed_plan

        return context

    def _construct_llm_prompt(self, project_description: str) -> str:
        return f"Create a step-by-step plan for: {project_description}"

    def _parse_llm_output(self, llm_response: Any) -> List[str]:
        if not llm_response:
            return []
            
        if isinstance(llm_response, str):
            lines = llm_response.strip().split('\n')
            return [line.strip() for line in lines if line.strip()]
        
        return []

