from __future__ import annotations
from dataclasses import dataclass
from typing import List, Optional, Any

@dataclass
class FileAction:
    path: str
    action: str
    prompt: Optional[str] = None
    content: Optional[str] = None

@dataclass
class FileSpec:
    path: str
    content: str
    action: str = "create"

@dataclass
class Plan:
    actions: List[FileAction]

    @property
    def files(self) -> List[FileSpec]:
        out: List[FileSpec] = []
        for a in self.actions:
            act = (a.action or "create").lower()
            out.append(FileSpec(path=a.path, content=a.content or "", action=act))
        return out

def normalize_plan(obj: Any) -> Plan:
    if isinstance(obj, Plan):
        return obj
    if isinstance(obj, dict):
        if "actions" in obj:
            return Plan(actions=[_to_action(x) for x in obj.get("actions", [])])
        if "files" in obj:
            acts: List[FileAction] = []
            for f in obj.get("files", []):
                fs = _to_filespec(f)
                acts.append(FileAction(path=fs.path, action=fs.action or "create", content=fs.content))
            return Plan(actions=acts)
    if isinstance(obj, list):
        return Plan(actions=[_to_action(x) for x in obj])
    raise TypeError("Unsupported plan format for normalize_plan")

def _to_action(x: Any) -> FileAction:
    if isinstance(x, FileAction):
        return x
    if isinstance(x, dict):
        path = x.get("path")
        if not path:
            raise ValueError("FileAction missing 'path'")
        return FileAction(
            path=path,
            action=str(x.get("action") or "create"),
            prompt=x.get("prompt"),
            content=x.get("content"),
        )
    raise TypeError("Invalid FileAction")

def _to_filespec(x: Any) -> FileSpec:
    if isinstance(x, FileSpec):
        return x
    if isinstance(x, dict):
        path = x.get("path")
        if not path:
            raise ValueError("FileSpec missing 'path'")
        return FileSpec(
            path=path,
            content=x.get("content", ""),
            action=str(x.get("action", "create")),
        )
    raise TypeError("Invalid FileSpec")
