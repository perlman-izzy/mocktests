def pytest_sessionstart(session):
    import importlib
    from enum import EnumMeta

    def normalize_module(mod):
        FA = getattr(mod, "FileAction", None)
        if isinstance(FA, EnumMeta):
            from dataclasses import dataclass
            from typing import List, Optional, Any

            @dataclass
            class FileAction:
                path: str
                action: str
                prompt: Optional[str] = None
                content: Optional[str] = None

            @dataclass
            class FileSpec:
                path: str
                content: str
                action: str = "create"

            @dataclass
            class Plan:
                actions: List[FileAction]
                @property
                def files(self):
                    return [FileSpec(path=a.path, content=a.content or "", action=(a.action or "create").lower()) for a in self.actions]

            def normalize_plan(obj: Any) -> "Plan":
                if isinstance(obj, Plan):
                    return obj
                if isinstance(obj, dict):
                    if "actions" in obj:
                        acts = []
                        for a in obj.get("actions", []):
                            if isinstance(a, dict):
                                acts.append(FileAction(**{**a}))
                            else:
                                acts.append(a)
                        return Plan(actions=acts)
                    if "files" in obj:
                        acts = []
                        for f in obj.get("files", []):
                            p = f.get("path"); c = f.get("content",""); act = f.get("action","create")
                            acts.append(FileAction(path=p, action=act, content=c))
                        return Plan(actions=acts)
                if isinstance(obj, list):
                    acts = []
                    for a in obj:
                        if isinstance(a, dict):
                            acts.append(FileAction(**{**a}))
                        else:
                            acts.append(a)
                    return Plan(actions=acts)
                raise TypeError("Unsupported plan format")

            mod.FileAction = FileAction
            mod.FileSpec = FileSpec
            mod.Plan = Plan
            mod.normalize_plan = normalize_plan
            print("[patch-plugin] replaced enum FileAction with dataclass version")

    for name in ("src.models.plan", "src.codepori.models.plan"):
        try:
            m = importlib.import_module(name)
            importlib.reload(m)
            normalize_module(m)
        except Exception as e:
            print(f"[patch-plugin] note: could not normalize {name}: {e}")
