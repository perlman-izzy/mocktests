"""AUTOFIXED STUB for context.py; original saved as .bak"""

pass
