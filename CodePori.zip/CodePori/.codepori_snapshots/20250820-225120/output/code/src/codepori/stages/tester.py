import logging
import shlex
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import List, Dict, Any, Optional

from src.codepori.context import CodePoriContext
from src.codepori.stages.base_stage import Stage
from src.codepori.services.process_runner import ProcessRunner, ProcessRunResult

logger = logging.getLogger(__name__) 

CONTEXT_KEY_TEST_RESULTS = "test_results"
CONTEXT_KEY_PROJECT_PATH = "project_path"
CONTEXT_KEY_TESTER_CONFIG = "tester_config"

DEFAULT_TEST_COMMAND = "pytest"
DEFAULT_TEST_TIMEOUT_SECONDS = 300  # 5 minutes


class TesterError(Exception):
    """Base exception for errors originating from the Tester stage."""
    pass


class MissingContextError(TesterError):
    """Raised when essential information is missing from the context."""
    pass


class TestExecutionError(TesterError):
    """Raised when the test execution process itself fails unexpectedly."""
    pass


@dataclass(frozen=True)
class TestResult:
    """A structured data class to hold the results of a test run.

    This immutable object encapsulates all relevant information from the test
    execution, making it easy to pass around and inspect.

    Attributes:
        passed (bool): True if the test suite passed (exit code 0), False otherwise.
        exit_code (int): The exit code returned by the test process.
        stdout (str): The standard output captured from the test run.
        stderr (str): The standard error captured from the test run.
        timed_out (bool): True if the test process was terminated due to a timeout.
        command (List[str]): The exact command that was executed.
    """
    passed: bool
    exit_code: int
    stdout: str
    stderr: str
    timed_out: bool
    command: List[str]


class Tester(Stage):
    """A pipeline stage for executing a project's test suite.

    The Tester stage is responsible for running a configurable test command
    within the project's directory. It captures the results, including stdout,
    stderr, and the exit code, and stores them in a structured format within
    the shared `CodePoriContext`. This provides a clear success/failure signal
    and detailed error information for subsequent stages.

    Dependency injection is used for the `ProcessRunner`, allowing for easier
    testing and substitution of the process execution mechanism.
    """

    def __init__(self, process_runner: ProcessRunner):
        """Initializes the Tester stage.

        Args:
            process_runner (ProcessRunner): An instance of a ProcessRunner to be
                used for executing the test commands. This dependency injection
                allows for greater flexibility and testability.
        """
        if not isinstance(process_runner, ProcessRunner):
            raise TypeError("process_runner must be an instance of ProcessRunner")
        self._process_runner = process_runner
        logger.info("Tester stage initialized.")

    def execute(self, context: CodePoriContext) -> CodePoriContext:
        """Executes the testing logic for the project specified in the context.

        This method orchestrates the entire testing process:
        1. Validates the incoming context.
        2. Determines the appropriate test command and execution parameters.
        3. Invokes the `ProcessRunner` to run the tests.
        4. Processes the results from the runner.
        5. Updates the context with a `TestResult` object.

        Args:
            context (CodePoriContext): The shared context object containing the
                project path and any stage-specific configurations.

        Returns:
            CodePoriContext: The updated context object with the test results stored.

        Raises:
            MissingContextError: If the project path is not found in the context.
            TestExecutionError: If the test process fails to execute for reasons
                other than test failures (e.g., command not found).
        """
        logger.info("--- Starting Tester Stage ---")
        self._validate_context(context)

        project_path = getattr(context, CONTEXT_KEY_PROJECT_PATH)
        logger.info(f"Running tests for project at: {project_path}")

        command, timeout = self._get_execution_parameters(context)

        try:
            process_result = self._run_tests(command, project_path, timeout)
        except FileNotFoundError as e:
            msg = f"Test command '{command[0]}' not found. Ensure it is installed and in the system's PATH."
            logger.error(msg)
            raise TestExecutionError(msg) from e
        except Exception as e:
            msg = f"An unexpected error occurred during test execution: {e}"
            logger.exception(msg) # log with stack trace
            raise TestExecutionError(msg) from e

        test_result = self._create_test_result(process_result, command)

        self._store_results_in_context(context, test_result)

        logger.info("--- Finished Tester Stage ---")
        return context

    def _validate_context(self, context: CodePoriContext) -> None:
        """Checks if the required data is present in the context.

        Args:
            context (CodePoriContext): The context to validate.

        Raises:
            MissingContextError: If `project_path` is missing or not a directory.
        """
        logger.debug("Validating context for Tester stage.")
        project_path = getattr(context, CONTEXT_KEY_PROJECT_PATH, None)
        if not project_path:
            raise MissingContextError(
                f"'{CONTEXT_KEY_PROJECT_PATH}' not found in the context."
            )
        if not isinstance(project_path, Path):
            raise MissingContextError(
                f"'{CONTEXT_KEY_PROJECT_PATH}' in context must be a Path object."
            )
        if not project_path.is_dir():
            raise MissingContextError(
                f"Project path '{project_path}' does not exist or is not a directory."
            )
        logger.debug("Context validation successful.")

    def _get_execution_parameters(self, context: CodePoriContext) -> (List[str], int):
        """Determines the test command and timeout from the context or defaults.

        Args:
            context (CodePoriContext): The shared context, which may contain a
                'tester_config' dictionary.

        Returns:
            A tuple containing the command as a list of strings and the timeout
            in seconds.
        """
        tester_config: Dict[str, Any] = context.state.get(CONTEXT_KEY_TESTER_CONFIG, {})

        command_str = tester_config.get("command", DEFAULT_TEST_COMMAND)
        command = shlex.split(command_str)

        timeout = tester_config.get("timeout", DEFAULT_TEST_TIMEOUT_SECONDS)

        logger.info(f"Using test command: '{' '.join(command)}' with timeout {timeout}s")
        return command, timeout

    def _run_tests(self, command: List[str], cwd: Path, timeout: int) -> ProcessRunResult:
        """Executes the test command using the process runner.

        Args:
            command (List[str]): The command to execute, split into a list.
            cwd (Path): The working directory for the command execution.
            timeout (int): The maximum execution time in seconds.

        Returns:
            ProcessRunResult: The result object from the process runner.
        """
        logger.info(f"Executing command: `{' '.join(command)}` in `{cwd}`")
        return self._process_runner.run(command, cwd=cwd, timeout=timeout)

    def _create_test_result(self, process_result: ProcessRunResult, command: List[str]) -> TestResult:
        """Creates a structured TestResult object from a ProcessRunResult.

        Args:
            process_result (ProcessRunResult): The raw result from the process runner.
            command (List[str]): The command that was executed.

        Returns:
            TestResult: The structured and interpreted test result.
        """
        passed = process_result.exit_code == 0
        status = "PASSED" if passed else "FAILED"

        logger.info(f"Test execution finished. Status: {status} (Exit Code: {process_result.exit_code})")
        if process_result.timed_out:
            logger.warning("Test execution timed out.")

        if not passed:
            logger.debug(f"Test failure details:\nSTDOUT:\n{process_result.stdout}\nSTDERR:\n{process_result.stderr}")

        return TestResult(
            passed=passed,
            exit_code=process_result.exit_code,
            stdout=process_result.stdout,
            stderr=process_result.stderr,
            timed_out=process_result.timed_out,
            command=command
        )

    def _store_results_in_context(self, context: CodePoriContext, test_result: TestResult) -> None:
        """Stores the test results in the shared context.

        The result is stored as a dictionary representation of the TestResult
        object for easier serialization if needed later.

        Args:
            context (CodePoriContext): The shared context object to update.
            test_result (TestResult): The result object to store.
        """
        context.state[CONTEXT_KEY_TEST_RESULTS] = asdict(test_result)
        logger.info(f"Test results have been stored in the context under the key '{CONTEXT_KEY_TEST_RESULTS}'.")
