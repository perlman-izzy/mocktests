import logging
import os
import shutil
from datetime import datetime
from pathlib import Path
from typing import List, Union, Iterator

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger(__name__)


class FileSystemError(Exception):
    """Custom base exception for filesystem-related errors."""
    pass


class PathTraversalError(FileSystemError):
    """Raised when an operation attempts to access a path outside the allowed base directory."""
    def __init__(self, requested_path: Union[str, Path], base_path: Union[str, Path]):
        message = (
            f"Security violation: Attempted to access path '{requested_path}' "
            f"which is outside the safe base directory '{base_path}'."
        )
        super().__init__(message)


class OperationNotForcedError(FileSystemError):
    """Raised when a potentially destructive operation is attempted without explicit confirmation."""
    def __init__(self, operation_name: str):
        message = (
            f"The destructive operation '{operation_name}' was blocked. "
            f"To proceed, you must set the 'force' parameter to True."
        )
        super().__init__(message)


class FileSystemManager:
    """Manages filesystem operations within a designated, sandboxed directory.

    This class provides a secure interface for file and directory operations,
    ensuring that all actions are confined to a specific base directory.
    It is designed to prevent path traversal attacks and accidental modification
    of files outside the intended scope, making it suitable for applications
    that generate or manage code and other artifacts.

    Attributes:
        base_dir (Path): The absolute, resolved path to the root directory for all operations.
    """

    def __init__(self, base_path: Union[str, Path] = "./output/code"):
        """Initializes the FileSystemManager and creates the base directory.

        Args:
            base_path (Union[str, Path]): The relative or absolute path to the directory
                that will serve as the root for all filesystem operations. Defaults to
                './output/code'.

        Raises:
            FileSystemError: If the base path cannot be created or accessed.
        """
        try:

            self.base_dir = Path(base_path).resolve()
            logger.info(f"FileSystemManager initialized with base directory: {self.base_dir}")

            self.base_dir.mkdir(parents=True, exist_ok=True)
            logger.info(f"Base directory '{self.base_dir}' is ready.")

        except (OSError, IOError) as e:
            logger.error(f"Failed to create or access base directory '{self.base_dir}': {e}", exc_info=True)
            raise FileSystemError(f"Could not initialize filesystem manager at '{base_path}': {e}") from e

    def _get_safe_path(self, relative_path: Union[str, Path]) -> Path:
        """Constructs and validates a path to ensure it's within the base directory.

        This is a critical security method to prevent directory traversal attacks.
        It joins the given relative path with the base directory, resolves it to
        an absolute path, and verifies that it is still a child of the base directory.

        Args:
            relative_path (Union[str, Path]): The path relative to the base directory.

        Returns:
            Path: An absolute, validated Path object.

        Raises:
            PathTraversalError: If the resulting path is outside the base directory.
        """
        if isinstance(relative_path, str) and os.path.isabs(relative_path):
            logger.warning(f"Received an absolute path '{relative_path}'. It will be treated as relative.")

        combined_path = self.base_dir.joinpath(relative_path)

        safe_path = combined_path.resolve()

        if not str(safe_path).startswith(str(self.base_dir)):
            raise PathTraversalError(requested_path=safe_path, base_path=self.base_dir)

        return safe_path

    def write_file(self, file_path: Union[str, Path], content: str, encoding: str = 'utf-8') -> None:
        """Writes content to a file within the base directory, creating parent directories if necessary.

        Args:
            file_path (Union[str, Path]): The relative path of the file to write.
            content (str): The string content to write to the file.
            encoding (str): The file encoding to use. Defaults to 'utf-8'.

        Raises:
            FileSystemError: If the file cannot be written due to I/O errors.
            PathTraversalError: If the file path is outside the safe directory.
        """
        safe_path = self._get_safe_path(file_path)
        logger.info(f"Writing file to safe path: {safe_path}")
        try:
            safe_path.parent.mkdir(parents=True, exist_ok=True)
            safe_path.write_text(content, encoding=encoding)
            logger.info(f"Successfully wrote {len(content)} bytes to {safe_path}")
        except (IOError, OSError) as e:
            logger.error(f"Failed to write file to '{safe_path}': {e}", exc_info=True)
            raise FileSystemError(f"Could not write to file '{file_path}': {e}") from e

    def read_file(self, file_path: Union[str, Path], encoding: str = 'utf-8') -> str:
        """Reads the content of a file from within the base directory.

        Args:
            file_path (Union[str, Path]): The relative path of the file to read.
            encoding (str): The file encoding to use. Defaults to 'utf-8'.

        Returns:
            str: The content of the file.

        Raises:
            FileSystemError: If the file does not exist or cannot be read.
            PathTraversalError: If the file path is outside the safe directory.
        """
        safe_path = self._get_safe_path(file_path)
        logger.info(f"Reading file from safe path: {safe_path}")
        if not safe_path.is_file():
            logger.warning(f"Attempted to read a non-existent file: {safe_path}")
            raise FileSystemError(f"File not found at path: '{file_path}'")

        try:
            content = safe_path.read_text(encoding=encoding)
            logger.info(f"Successfully read {len(content)} bytes from {safe_path}")
            return content
        except (IOError, OSError) as e:
            logger.error(f"Failed to read file from '{safe_path}': {e}", exc_info=True)
            raise FileSystemError(f"Could not read file '{file_path}': {e}") from e

    def delete_file(self, file_path: Union[str, Path]) -> None:
        """Deletes a single file within the base directory.

        Args:
            file_path (Union[str, Path]): The relative path of the file to delete.

        Raises:
            FileSystemError: If the path does not point to a file or cannot be deleted.
            PathTraversalError: If the file path is outside the safe directory.
        """
        safe_path = self._get_safe_path(file_path)
        logger.info(f"Attempting to delete file: {safe_path}")
        if not safe_path.is_file():
            logger.warning(f"Delete operation failed: path is not a file or does not exist: {safe_path}")
            raise FileSystemError(f"Path '{file_path}' is not a file or does not exist.")

        try:
            safe_path.unlink()
            logger.info(f"Successfully deleted file: {safe_path}")
        except (IOError, OSError) as e:
            logger.error(f"Error deleting file '{safe_path}': {e}", exc_info=True)
            raise FileSystemError(f"Could not delete file '{file_path}': {e}") from e

    def delete_directory(self, dir_path: Union[str, Path], force: bool = False) -> None:
        """Deletes a directory and its contents recursively within the base directory.

        This is a destructive operation. For safety, it requires the 'force'
        parameter to be set to True.

        Args:
            dir_path (Union[str, Path]): The relative path of the directory to delete.
            force (bool): A flag to confirm the deletion. Defaults to False.

        Raises:
            FileSystemError: If the path is not a directory or deletion fails.
            PathTraversalError: If the directory path is outside the safe directory.
            OperationNotForcedError: If 'force' is not set to True.
        """
        if not force:
            raise OperationNotForcedError('delete_directory')

        safe_path = self._get_safe_path(dir_path)
        logger.warning(f"Attempting to recursively delete directory: {safe_path}")
        if not safe_path.is_dir():
            logger.warning(f"Delete operation failed: path is not a directory or does not exist: {safe_path}")
            raise FileSystemError(f"Path '{dir_path}' is not a directory or does not exist.")

        try:
            shutil.rmtree(safe_path)
            logger.info(f"Successfully deleted directory: {safe_path}")
        except (IOError, OSError) as e:
            logger.error(f"Error deleting directory '{safe_path}': {e}", exc_info=True)
            raise FileSystemError(f"Could not delete directory '{dir_path}': {e}") from e

    def path_exists(self, item_path: Union[str, Path]) -> bool:
        """Checks if a file or directory exists at the given relative path.

        Args:
            item_path (Union[str, Path]): The relative path to check.

        Returns:
            bool: True if the path exists, False otherwise.
        """
        try:
            safe_path = self._get_safe_path(item_path)
            return safe_path.exists()
        except PathTraversalError:

            return False

    def list_items(self, dir_path: Union[str, Path] = '.') -> Iterator[Path]:
        """Lists all files and directories within a given relative path.

        Args:
            dir_path (Union[str, Path]): The relative path of the directory to list.
                                         Defaults to the base directory itself.

        Returns:
            Iterator[Path]: An iterator of Path objects for each item in the directory.

        Raises:
            FileSystemError: If the provided path is not a directory.
            PathTraversalError: If the directory path is outside the safe directory.
        """
        safe_path = self._get_safe_path(dir_path)
        if not safe_path.is_dir():
            raise FileSystemError(f"Path '{dir_path}' is not a valid directory.")

        return safe_path.iterdir()

    def get_file_size(self, file_path: Union[str, Path]) -> int:
        """Gets the size of a file in bytes.

        Args:
            file_path (Union[str, Path]): The relative path of the file.

        Returns:
            int: The size of the file in bytes.

        Raises:
            FileSystemError: If the path is not a file or does not exist.
            PathTraversalError: If the file path is outside the safe directory.
        """
        safe_path = self._get_safe_path(file_path)
        if not safe_path.is_file():
            raise FileSystemError(f"Path '{file_path}' is not a file or does not exist.")
        try:
            return safe_path.stat().st_size
        except OSError as e:
            logger.error(f"Could not get size for file '{safe_path}': {e}", exc_info=True)
            raise FileSystemError(f"Could not stat file '{file_path}': {e}") from e

    def get_modification_time(self, item_path: Union[str, Path]) -> datetime:
        """Gets the last modification time of a file or directory.

        Args:
            item_path (Union[str, Path]): The relative path of the item.

        Returns:
            datetime: A datetime object representing the last modification time.

        Raises:
            FileSystemError: If the path does not exist.
            PathTraversalError: If the path is outside the safe directory.
        """
        safe_path = self._get_safe_path(item_path)
        if not safe_path.exists():
            raise FileSystemError(f"Path '{item_path}' does not exist.")
        try:
            mtime_timestamp = safe_path.stat().st_mtime
            return datetime.fromtimestamp(mtime_timestamp)
        except OSError as e:
            logger.error(f"Could not get modification time for '{safe_path}': {e}", exc_info=True)
            raise FileSystemError(f"Could not stat path '{item_path}': {e}") from e
