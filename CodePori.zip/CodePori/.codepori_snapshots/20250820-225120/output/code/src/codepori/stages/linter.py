import logging
import os
import pathlib
import shutil
import tempfile
from dataclasses import dataclass
from typing import List, Optional

from src.codepori.context import Context, File
from src.codepori.stages.stage import Stage
from src.codepori.utils.process_runner import ProcessRunner, ProcessResult

logger = logging.getLogger(__name__)


class LinterStageError(Exception):
    """Custom exception for errors occurring within the Linter stage."""
    pass


@dataclass(frozen=True)
class LinterStageResult:
    """Data class to hold the results of the linter execution.

    Attributes:
        success (bool): True if the linter passed, False otherwise.
        command (List[str]): The exact command that was executed.
        return_code (int): The return code from the linter process.
        stdout (str): The standard output from the linter process.
        stderr (str): The standard error from the linter process.
    """
    success: bool
    command: List[str]
    return_code: int
    stdout: str
    stderr: str


class Linter(Stage):
    """A pipeline stage that runs a configurable linter on the generated code.

    This stage writes the files from the context to a temporary directory, executes a
    specified linter command (e.g., ruff, black) within that directory, and then
    captures the results. The outcome is stored back in the context.

    Attributes:
        linter_command (List[str]): The linter command to execute, as a list of strings.
    """

    def __init__(self, linter_command: List[str]):
        """Initializes the Linter stage.

        Args:
            linter_command (List[str]): The linter command and its arguments.
                For example: ['ruff', 'check', '.'] or ['black', '--check', '.']

        Raises:
            ValueError: If the linter_command is empty or not a list.
        """
        if not linter_command or not isinstance(linter_command, list):
            raise ValueError("linter_command must be a non-empty list of strings.")

        super().__init__()
        self.linter_command: List[str] = linter_command
        self.process_runner: ProcessRunner = ProcessRunner()
        logger.info(f"Linter stage initialized with command: {' '.join(linter_command)}")

    def execute(self, context: Context) -> Context:
        """Executes the linting process on the files in the context.

        This method performs the following steps:
        1. Creates a temporary directory.
        2. Writes all files from `context.files` into this directory.
        3. Executes the configured linter command in the directory.
        4. Captures the result (stdout, stderr, return code).
        5. Creates a `LinterStageResult` and attaches it to the context.
        6. The temporary directory is automatically cleaned up.

        Args:
            context (Context): The current execution context, containing the files
                to be linted.

        Returns:
            Context: The updated context with the linter results.

        Raises:
            LinterStageError: If there's an issue writing files or running the linter.
        """
        logger.info("Executing Linter stage...")

        if not context.files:
            logger.warning("No files in context to lint. Skipping Linter stage.")

            result = LinterStageResult(
                success=True,
                command=self.linter_command,
                return_code=0,
                stdout="No files to lint.",
                stderr="",
            )
            context.linter_result = result
            return context

        try:
            with tempfile.TemporaryDirectory() as temp_dir_str:
                temp_dir = pathlib.Path(temp_dir_str)
                logger.debug(f"Created temporary directory for linting: {temp_dir}")

                self._write_files_to_disk(context.files, temp_dir)

                process_result = self._run_linter(temp_dir)

                linter_passed = process_result.return_code == 0
                if linter_passed:
                    logger.info("Linter execution successful (exit code 0).")
                else:
                    logger.warning(
                        f"Linter execution failed with exit code {process_result.return_code}."
                    )
                    logger.warning(f"Linter stdout:\n{process_result.stdout}")
                    logger.warning(f"Linter stderr:\n{process_result.stderr}")

                stage_result = LinterStageResult(
                    success=linter_passed,
                    command=self.linter_command,
                    return_code=process_result.return_code,
                    stdout=process_result.stdout,
                    stderr=process_result.stderr,
                )

                context.linter_result = stage_result

        except (IOError, OSError) as e:
            logger.error(f"File system error during linter stage: {e}", exc_info=True)
            raise LinterStageError(f"Failed to write files for linting: {e}") from e
        except Exception as e:
            logger.error(f"An unexpected error occurred in Linter stage: {e}", exc_info=True)
            raise LinterStageError(f"An unexpected error occurred: {e}") from e

        logger.info("Linter stage finished.")
        return context

    def _write_files_to_disk(self, files: List[File], target_dir: pathlib.Path) -> None:
        """Writes a list of File objects to a specified directory.

        This helper method iterates through each file, creates its parent directories
        if they don't exist, and writes its content to the disk.

        Args:
            files (List[File]): A list of File objects to be written.
            target_dir (pathlib.Path): The root directory where files will be created.

        Raises:
            IOError: If there's an error creating directories or writing a file.
        """
        logger.info(f"Writing {len(files)} files to {target_dir} for linting.")
        for file in files:
            try:

                full_path = target_dir.joinpath(file.path)

                full_path.parent.mkdir(parents=True, exist_ok=True)

                with open(full_path, "w", encoding="utf-8") as f:
                    f.write(file.content)

                logger.debug(f"Successfully wrote file: {full_path}")
            except (IOError, OSError) as e:
                logger.error(f"Failed to write file {file.path} to {target_dir}: {e}", exc_info=True)

                raise

    def _run_linter(self, working_dir: pathlib.Path) -> ProcessResult:
        """Runs the configured linter command in the specified directory.

        Args:
            working_dir (pathlib.Path): The directory from which to run the command.

        Returns:
            ProcessResult: An object containing the command's stdout, stderr, and return code.

        Raises:
            LinterStageError: If the linter command cannot be found or executed.
        """
        logger.info(f"Running command: `{' '.join(self.linter_command)}` in `{working_dir}`")
        try:
            process_result = self.process_runner.run(
                self.linter_command,
                cwd=str(working_dir)  # ProcessRunner expects string path
            )
            return process_result
        except FileNotFoundError as e:
            logger.error(
                f"Linter command not found: '{self.linter_command[0]}'. "
                f"Please ensure it is installed and in the system's PATH.",
                exc_info=True
            )
            raise LinterStageError(
                f"Linter command '{self.linter_command[0]}' not found. Is it installed?"
            ) from e
        except Exception as e:
            logger.error(
                f"An error occurred while trying to run the linter: {e}",
                exc_info=True
            )
            raise LinterStageError(
                f"Failed to execute linter command: {e}"
            ) from e

    @property
    def name(self) -> str:
        """Provides the name of the stage.

        Returns:
            str: The name 'linter'.
        """
        return "linter"
