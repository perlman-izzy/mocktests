import asyncio
import logging
import shlex
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Union

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class ProcessResult:
    """Represents the result of an executed external process.

    This is an immutable data class that holds all relevant information
    about a completed process, including its output, exit code, and the
    original command that was run.

    Attributes:
        command (List[str]): The command and its arguments that were executed.
        stdout (str): The standard output from the process, decoded as UTF-8.
        stderr (str): The standard error from the process, decoded as UTF-8.
        return_code (int): The exit code returned by the process.
        timed_out (bool): True if the process was terminated due to a timeout.
    """
    command: List[str]
    stdout: str
    stderr: str
    return_code: int
    timed_out: bool = False

    def __str__(self) -> str:
        """Provides a human-readable summary of the process result."""
        cmd_str = ' '.join(shlex.quote(arg) for arg in self.command)
        return (
            f"Command: '{cmd_str}'\n"
            f"Return Code: {self.return_code}\n"
            f"Timed Out: {self.timed_out}\n"
            f"--- STDOUT ---\n{self.stdout.strip()}\n"
            f"--- STDERR ---\n{self.stderr.strip()}"
        )


class ProcessRunnerError(Exception):
    """Base exception for all errors originating from the ProcessRunner."""
    pass


class ProcessExecutionError(ProcessRunnerError):
    """Exception raised when a process execution fails for a specific reason.

    This exception provides more context than a standard subprocess error,
    including any partial results that might have been captured before the
    failure.

    Attributes:
        message (str): A description of the error.
        result (Optional[ProcessResult]): The partial or complete process
            result, if available. This can be useful for debugging.
    """
    def __init__(self, message: str, result: Optional[ProcessResult] = None):
        super().__init__(message)
        self.message = message
        self.result = result

    def __str__(self) -> str:
        if self.result:
            return f"{self.message}\nResult:\n{self.result}"
        return self.message


class ProcessRunner:
    """A utility for running external command-line processes.

    This class provides both synchronous and asynchronous methods for executing
    external commands, capturing their output, and handling errors in a
    structured way. It is designed to be a reliable and testable interface
    for interacting with command-line tools.
    """

    def __init__(self):
        """Initializes the ProcessRunner."""
        self._logger = logging.getLogger(f"{__name__}.{self.__class__.__name__}")

    def run(
        self,
        command: List[str],
        cwd: Optional[Union[str, Path]] = None,
        timeout: Optional[float] = None,
        env: Optional[Dict[str, str]] = None
    ) -> ProcessResult:
        """Executes a command synchronously.

        Args:
            command (List[str]): The command to execute as a list of strings.
            cwd (Optional[Union[str, Path]]): The working directory to run the
                command in. Defaults to the current working directory.
            timeout (Optional[float]): The maximum number of seconds to wait
                for the command to complete.
            env (Optional[Dict[str, str]]): A dictionary of environment
                variables to set for the process. If None, the parent
                process's environment is inherited.

        Returns:
            ProcessResult: An object containing the results of the execution.

        Raises:
            ProcessExecutionError: If the command cannot be found or if another
                OS-level error occurs during execution.
        """
        if not command:
            raise ValueError("Command list cannot be empty.")

        cmd_str = ' '.join(shlex.quote(arg) for arg in command)
        self._logger.info(f"Running synchronous command: '{cmd_str}' in '{cwd or '.'}'")

        try:
            process = subprocess.run(
                command,
                cwd=str(cwd) if cwd else None,
                timeout=timeout,
                capture_output=True,
                text=True,
                encoding='utf-8',
                errors='replace',
                env=env,
            )
            result = ProcessResult(
                command=command,
                stdout=process.stdout,
                stderr=process.stderr,
                return_code=process.returncode,
                timed_out=False
            )
            self._logger.debug(f"Command '{cmd_str}' finished with code {result.return_code}")
            return result

        except FileNotFoundError:
            err_msg = f"Command not found: '{command[0]}'. Please ensure it is installed and in your PATH."
            self._logger.error(err_msg)
            error_result = ProcessResult(
                command=command, stdout="", stderr=err_msg, return_code=-1
            )
            raise ProcessExecutionError(err_msg, result=error_result) from None

        except subprocess.TimeoutExpired as e:
            err_msg = f"Command '{cmd_str}' timed out after {timeout} seconds."
            self._logger.warning(err_msg)
            result = ProcessResult(
                command=command,
                stdout=e.stdout.decode('utf-8', errors='replace') if e.stdout else "",
                stderr=e.stderr.decode('utf-8', errors='replace') if e.stderr else "",
                return_code=-1,  # Convention for timeout
                timed_out=True
            )
            raise ProcessExecutionError(err_msg, result=result) from e

        except OSError as e:
            err_msg = f"An OS error occurred while running '{cmd_str}': {e}"
            self._logger.error(err_msg, exc_info=True)
            error_result = ProcessResult(
                command=command, stdout="", stderr=str(e), return_code=-1
            )
            raise ProcessExecutionError(err_msg, result=error_result) from e

    async def run_async(
        self,
        command: List[str],
        cwd: Optional[Union[str, Path]] = None,
        timeout: Optional[float] = None,
        env: Optional[Dict[str, str]] = None
    ) -> ProcessResult:
        """Executes a command asynchronously.

        Args:
            command (List[str]): The command to execute as a list of strings.
            cwd (Optional[Union[str, Path]]): The working directory to run the
                command in. Defaults to the current working directory.
            timeout (Optional[float]): The maximum number of seconds to wait
                for the command to complete.
            env (Optional[Dict[str, str]]): A dictionary of environment
                variables to set for the process. If None, the parent
                process's environment is inherited.

        Returns:
            ProcessResult: An object containing the results of the execution.

        Raises:
            ProcessExecutionError: If the command cannot be found, times out,
                or if another OS-level error occurs.
        """
        if not command:
            raise ValueError("Command list cannot be empty.")

        cmd_str = ' '.join(shlex.quote(arg) for arg in command)
        self._logger.info(f"Running asynchronous command: '{cmd_str}' in '{cwd or '.'}'")

        try:
            process = await asyncio.create_subprocess_exec(
                *command,
                cwd=str(cwd) if cwd else None,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=env,
            )

            stdout_bytes, stderr_bytes = await asyncio.wait_for(
                process.communicate(),
                timeout=timeout
            )

            stdout = stdout_bytes.decode('utf-8', errors='replace')
            stderr = stderr_bytes.decode('utf-8', errors='replace')

            return_code = process.returncode or 0

            result = ProcessResult(
                command=command,
                stdout=stdout,
                stderr=stderr,
                return_code=return_code,
                timed_out=False
            )
            self._logger.debug(f"Async command '{cmd_str}' finished with code {result.return_code}")
            return result

        except FileNotFoundError:
            err_msg = f"Command not found: '{command[0]}'. Please ensure it is installed and in your PATH."
            self._logger.error(err_msg)
            error_result = ProcessResult(
                command=command, stdout="", stderr=err_msg, return_code=-1
            )
            raise ProcessExecutionError(err_msg, result=error_result) from None

        except asyncio.TimeoutError:
            err_msg = f"Async command '{cmd_str}' timed out after {timeout} seconds."
            self._logger.warning(err_msg)

            if 'process' in locals() and process.returncode is None:
                try:
                    process.kill()
                    await process.wait()
                except ProcessLookupError:
                    pass
                except Exception as kill_exc:
                    self._logger.error(f"Error while killing timed-out process: {kill_exc}")

            result = ProcessResult(
                command=command,
                stdout="",
                stderr=f"Process timed out after {timeout} seconds.",
                return_code=-1,
                timed_out=True
            )
            raise ProcessExecutionError(err_msg, result=result) from None

        except OSError as e:
            err_msg = f"An OS error occurred while running '{cmd_str}': {e}"
            self._logger.error(err_msg, exc_info=True)
            error_result = ProcessResult(
                command=command, stdout="", stderr=str(e), return_code=-1
            )
            raise ProcessExecutionError(err_msg, result=error_result) from e
