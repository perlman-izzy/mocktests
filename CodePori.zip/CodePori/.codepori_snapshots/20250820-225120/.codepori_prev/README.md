# Code Refinement Bot System

## Overview

This project provides a driver to manage a collaborative workflow between two AI agents, `bot_1` and `bot_2`, designed to iteratively refine Python code to a production-ready standard. The system takes an initial module, a project description, and a code review as input, and orchestrates the conversation between the bots to produce high-quality, finalized code.

This README provides instructions for setting up and using the driver for this system. It does not cover the application-specific code that the bots will generate.

## Features

-   **Automated Code Refinement**: Leverages AI agents to automatically improve code based on provided requirements and feedback.
-   **Iterative Process**: The bots engage in a back-and-forth conversation, progressively enhancing the code until it meets production-level criteria.
-   **Role-Based Collaboration**: `bot_1` acts as a senior developer initiating and finalizing changes, while `bot_2` acts as a collaborator, implementing and suggesting improvements.
-   **Configurable and Extensible**: The driver is designed to be adaptable to different AI models and interaction patterns.

## Prerequisites

-   Python 3.9+
-   An API key for an AI provider (e.g., OpenAI, Anthropic, Google).

## Setup

1.  **Clone the repository:**
    ```bash
    git clone https://your-repository-url.git
    cd your-repository-directory
    ```

2.  **Create and activate a virtual environment:**
    ```bash
    python -m venv venv
    source venv/bin/activate
    # On Windows, use: venv\Scripts\activate
    ```

3.  **Install the required dependencies:**
    ```bash
    pip install -r requirements.txt
    ```

4.  **Configure environment variables:**
    Create a `.env` file in the root of the project directory and add your AI provider's API key:
    ```
    # .env
    AI_PROVIDER_API_KEY="your_api_key_here"
    ```

## Usage

The driver is executed from the command line. You need to provide paths to three input files:
-   A project description file (Markdown or text).
-   The initial Python module code file.
-   A code review file containing feedback and required changes (Markdown or text).

### Command

```bash
python driver.py \
    --project-description-path "path/to/your/project_description.md" \
    --module-code-path "path/to/your/initial_code.py" \
    --review-path "path/to/your/review.md" \
    --output-path "path/to/your/final_code.py"
```

### Arguments

-   `--project-description-path`: Path to the file containing the project description.
-   `--module-code-path`: Path to the Python file with the initial code.
-   `--review-path`: Path to the file containing the code review and improvement points.
-   `--output-path`: Path where the final, production-ready code will be saved.

### Example

1.  Create your input files:
    -   `inputs/project_desc.md`
    -   `inputs/initial_code.py`
    -   `inputs/code_review.txt`

2.  Run the driver:
    ```bash
    python driver.py \
        --project-description-path "inputs/project_desc.md" \
        --module-code-path "inputs/initial_code.py" \
        --review-path "inputs/code_review.txt" \
        --output-path "outputs/final_code.py"
    ```

3.  The refined code will be available in `outputs/final_code.py`.

## Workflow Overview

The driver orchestrates the following process:

1.  **Initialization**: The driver loads the content from the three input files.
2.  **Bot 1 - First Turn**: It constructs a prompt for `bot_1` containing the project description, initial code, and review, asking it to initiate the refinement process and provide instructions for `bot_2`.
3.  **Bot 2 - Collaboration**: The output from `bot_1` (which includes updated code and further instructions) is passed to `bot_2`. `bot_2` works on the code and responds with its improvements.
4.  **Iterative Refinement**: The conversation continues between `bot_1` and `bot_2`, with the driver passing messages back and forth. `bot_1` reviews `bot_2`'s work, provides more feedback, and updates the code. This loop continues for a predefined number of turns or until a satisfactory state is reached.
5.  **Finalization**: `bot_1` produces the final, production-ready code, which the driver then saves to the specified output file.
