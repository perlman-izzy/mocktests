import pytest
from pathlib import Path

# Absolute import from repo root, assuming the class is in src/io_ops/workspace.py
from src.io_ops.workspace import Workspace


@pytest.fixture
def workspace_base_dir() -> Path:
    """Provides a consistent base directory path for tests in the fake filesystem."""
    return Path("/test_workspace")


@pytest.fixture
def workspace(fs, workspace_base_dir: Path) -> Workspace:
    """
    Provides a Workspace instance initialized in a mocked filesystem.
    The `fs` fixture is from pyfakefs and creates the fake filesystem.
    The Workspace class itself is responsible for directory creation.
    """
    return Workspace(workspace_base_dir)


def test_workspace_initialization_creates_directory(fs, workspace_base_dir: Path):
    """
    Test that initializing a Workspace object creates the base directory if it
    does not exist.
    """
    # Arrange
    assert not fs.exists(workspace_base_dir)

    # Act
    ws = Workspace(workspace_base_dir)

    # Assert
    assert fs.exists(workspace_base_dir)
    assert workspace_base_dir.is_dir()
    assert ws.base_path == workspace_base_dir


def test_workspace_initialization_with_existing_directory(fs, workspace_base_dir: Path):
    """
    Test that initializing a Workspace object works correctly when the base
    directory already exists, without raising an error.
    """
    # Arrange
    fs.create_dir(workspace_base_dir)
    assert fs.exists(workspace_base_dir)

    # Act
    ws = Workspace(workspace_base_dir)

    # Assert
    assert ws.base_path == workspace_base_dir


def test_get_path_returns_correct_absolute_path(workspace: Workspace):
    """
    Test the get_path method to ensure it returns the fully resolved path
    for a file within the workspace.
    """
    # Arrange
    file_name = "my_file.txt"
    expected_path = workspace.base_path / file_name

    # Act
    actual_path = workspace.get_path(file_name)

    # Assert
    assert actual_path == expected_path
    assert actual_path.is_absolute()


def test_write_and_read_file(workspace: Workspace):
    """
    Test the core functionality of writing content to a file and reading it back.
    """
    # Arrange
    file_name = "test_data.json"
    content = '{"key": "value", "number": 123}'

    # Act (Write)
    workspace.write(file_name, content)

    # Assert (File exists in fake filesystem)
    file_path = workspace.get_path(file_name)
    assert file_path.exists()
    assert file_path.is_file()

    # Act (Read)
    read_content = workspace.read(file_name)

    # Assert (Content matches)
    assert read_content == content


def test_write_overwrites_existing_file(workspace: Workspace):
    """
    Test that writing to an existing file overwrites its contents.
    """
    # Arrange
    file_name = "document.txt"
    initial_content = "This is the first version."
    new_content = "This is the updated version."
    workspace.write(file_name, initial_content)
    assert workspace.read(file_name) == initial_content

    # Act
    workspace.write(file_name, new_content)

    # Assert
    read_content = workspace.read(file_name)
    assert read_content == new_content


def test_read_nonexistent_file_raises_file_not_found_error(workspace: Workspace):
    """
    Test that attempting to read a file that does not exist raises a
    FileNotFoundError.
    """
    # Arrange
    non_existent_file = "ghost_file.dat"
    file_path = workspace.get_path(non_existent_file)
    assert not file_path.exists()

    # Act & Assert
    with pytest.raises(FileNotFoundError):
        workspace.read(non_existent_file)


def test_list_files_on_empty_workspace(workspace: Workspace):
    """
    Test that list_files returns an empty list for a newly created,
    empty workspace.
    """
    # Act
    files = workspace.list_files()

    # Assert
    assert files == []


def test_list_files_returns_all_file_names(workspace: Workspace):
    """
    Test that list_files correctly returns the names of all files in the
    workspace and ignores subdirectories.
    """
    # Arrange
    expected_files = {"file1.txt", "file2.log", "config.yml"}
    for file_name in expected_files:
        workspace.write(file_name, f"content for {file_name}")

    # Create a subdirectory to ensure it is ignored by list_files
    (workspace.base_path / "subdir").mkdir()

    # Act
    listed_files = workspace.list_files()

    # Assert
    # Use sets for comparison to handle potential ordering differences
    assert set(listed_files) == expected_files


def test_delete_file_removes_it_from_workspace(workspace: Workspace):
    """
    Test that a file can be successfully deleted from the workspace.
    (This test assumes a `delete` method exists on the Workspace class).
    """
    # Arrange
    file_to_delete = "temp_file.tmp"
    workspace.write(file_to_delete, "to be deleted")
    file_path = workspace.get_path(file_to_delete)
    assert file_path.exists()

    # Act
    workspace.delete(file_to_delete)

    # Assert
    assert not file_path.exists()
    assert file_to_delete not in workspace.list_files()


def test_delete_nonexistent_file_raises_file_not_found_error(workspace: Workspace):
    """
    Test that attempting to delete a non-existent file raises a
    FileNotFoundError. (This test assumes a `delete` method).
    """
    # Arrange
    non_existent_file = "nothing_here.txt"
    assert not workspace.get_path(non_existent_file).exists()

    # Act & Assert
    with pytest.raises(FileNotFoundError):
        workspace.delete(non_existent_file)
