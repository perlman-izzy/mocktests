import pytest
from unittest.mock import Mock, call, patch

# Assuming a structure like this exists in the source code.
# This is a hypothetical implementation for testing purposes.
# from src.orchestration.driver import Driver
# from src.orchestration.stage import Stage, StageResult

# For the purpose of creating a self-contained test file, we'll define
# placeholder classes. In a real scenario, these would be imported.
class StageResult:
    def __init__(self, success, should_retry=False, data=None, error_message=''):
        self.success = success
        self.should_retry = should_retry
        self.data = data or {}
        self.error_message = error_message

class Stage:
    def __init__(self, name, max_retries=0):
        self.name = name
        self.max_retries = max_retries

    def execute(self, context):
        raise NotImplementedError

class Driver:
    def __init__(self, stages):
        if not all(isinstance(s, Stage) for s in stages):
            raise TypeError("All items in 'stages' must be Stage instances.")
        self.stages = stages
        self.context = {}
        self.run_successful = False

    def run(self):
        for stage in self.stages:
            attempts = 0
            while attempts <= stage.max_retries:
                try:
                    result = stage.execute(self.context)
                    if result.success:
                        self.context.update(result.data)
                        break  # Move to the next stage
                    elif result.should_retry and attempts < stage.max_retries:
                        attempts += 1
                        # Optionally log the retry attempt here
                        continue
                    else:
                        # Final failure
                        self.run_successful = False
                        return self.run_successful
                except Exception as e:
                    # Unhandled exception in stage
                    self.run_successful = False
                    return self.run_successful
            else:
                # This block runs if the while loop completes without a 'break'
                # which means all retries were exhausted.
                self.run_successful = False
                return self.run_successful

        self.run_successful = True
        return self.run_successful

# --- Test Fixtures ---

@pytest.fixture
def mock_stage_factory():
    """Factory to create mock Stage objects."""
    def _create_mock_stage(name, max_retries=0):
        stage = Mock(spec=Stage)
        stage.name = name
        stage.max_retries = max_retries
        return stage
    return _create_mock_stage


# --- Test Cases ---

def test_driver_initialization(mock_stage_factory):
    """Tests that the Driver initializes correctly with valid stages."""
    stage1 = mock_stage_factory("stage1")
    stage2 = mock_stage_factory("stage2")
    driver = Driver(stages=[stage1, stage2])
    assert driver.stages == [stage1, stage2]
    assert driver.context == {}
    assert not driver.run_successful

def test_driver_initialization_with_invalid_type():
    """Tests that the Driver raises a TypeError if a non-Stage object is provided."""
    with pytest.raises(TypeError, match="All items in 'stages' must be Stage instances."):
        Driver(stages=["not_a_stage_object"])

def test_run_all_stages_succeed(mock_stage_factory):
    """Verifies correct execution and sequencing when all stages succeed."""
    stage1 = mock_stage_factory("stage1")
    stage2 = mock_stage_factory("stage2")

    stage1.execute.return_value = StageResult(success=True, data={'key1': 'val1'})
    stage2.execute.return_value = StageResult(success=True, data={'key2': 'val2'})

    driver = Driver(stages=[stage1, stage2])
    result = driver.run()

    assert result is True
    assert driver.run_successful is True
    assert stage1.execute.call_count == 1
    assert stage2.execute.call_count == 1

    # Verify context is passed and updated correctly
    stage1.execute.assert_called_once_with({})
    stage2.execute.assert_called_once_with({'key1': 'val1'})
    assert driver.context == {'key1': 'val1', 'key2': 'val2'}

def test_run_stops_on_non_retryable_failure(mock_stage_factory):
    """Verifies that the driver stops execution on the first non-retryable failure."""
    stage1 = mock_stage_factory("stage1")
    stage2_fails = mock_stage_factory("stage2_fails")
    stage3 = mock_stage_factory("stage3")

    stage1.execute.return_value = StageResult(success=True, data={'step1': 'done'})
    stage2_fails.execute.return_value = StageResult(success=False, should_retry=False)

    driver = Driver(stages=[stage1, stage2_fails, stage3])
    result = driver.run()

    assert result is False
    assert driver.run_successful is False

    stage1.execute.assert_called_once()
    stage2_fails.execute.assert_called_once()
    stage3.execute.assert_not_called()
    assert driver.context == {'step1': 'done'}

def test_run_with_successful_retry(mock_stage_factory):
    """Tests that a stage is retried and the pipeline continues upon success."""
    stage1_retry = mock_stage_factory("stage1_retry", max_retries=2)
    stage2 = mock_stage_factory("stage2")

    stage1_retry.execute.side_effect = [
        StageResult(success=False, should_retry=True),
        StageResult(success=True, data={'retry_success': True})
    ]
    stage2.execute.return_value = StageResult(success=True, data={'final_step': 'complete'})

    driver = Driver(stages=[stage1_retry, stage2])
    result = driver.run()

    assert result is True
    assert stage1_retry.execute.call_count == 2
    stage2.execute.assert_called_once()
    assert driver.context == {'retry_success': True, 'final_step': 'complete'}

def test_run_with_exhausted_retries_failure(mock_stage_factory):
    """Tests that the driver fails if a stage exhausts all its retry attempts."""
    stage1 = mock_stage_factory("stage1", max_retries=2) # 1 initial + 2 retries = 3 attempts
    stage2 = mock_stage_factory("stage2")

    # This stage will always fail
    stage1.execute.return_value = StageResult(success=False, should_retry=True)

    driver = Driver(stages=[stage1, stage2])
    result = driver.run()

    assert result is False
    assert driver.run_successful is False
    assert stage1.execute.call_count == 3
    stage2.execute.assert_not_called()

def test_run_handles_unhandled_stage_exception(mock_stage_factory):
    """Verifies the driver stops if a stage raises an unexpected exception."""
    stage1 = mock_stage_factory("stage1")
    stage2_exception = mock_stage_factory("stage2_exception")
    stage3 = mock_stage_factory("stage3")

    stage1.execute.return_value = StageResult(success=True)
    stage2_exception.execute.side_effect = ValueError("Something went wrong in the stage")

    driver = Driver(stages=[stage1, stage2_exception, stage3])
    result = driver.run()

    assert result is False
    stage1.execute.assert_called_once()
    stage2_exception.execute.assert_called_once()
    stage3.execute.assert_not_called()

def test_run_with_no_stages_is_successful():
    """Tests that a driver with an empty list of stages runs successfully."""
    driver = Driver(stages=[])
    result = driver.run()
    assert result is True
    assert driver.context == {}

def test_context_immutability_for_stage():
    """Ensures that a stage modifying its received context doesn't affect the driver's master context directly."""

    # This custom side effect function mimics a stage that modifies the context it receives
    def evil_stage_execute(context):
        context['new_key'] = 'mutated'
        return StageResult(success=True, data={'original_key': 'original_val'})

    mock_stage = Mock(spec=Stage)
    mock_stage.name = 'mutating_stage'
    mock_stage.max_retries = 0
    mock_stage.execute.side_effect = evil_stage_execute

    # In a real implementation, the Driver should pass a copy of the context
    # to each stage to prevent such side effects. Let's assume the current
    # implementation does NOT do this and test the behavior.
    # A production-ready Driver should pass `context.copy()`.
    driver = Driver(stages=[mock_stage])
    driver.run()

    # The stage's return data should be merged, but not the direct mutation.
    # If the Driver implementation is robust (passes a copy), this passes.
    # If not, driver.context would be {'new_key': 'mutated', 'original_key': 'original_val'}
    # This test exposes that potential vulnerability.
    assert driver.context == {'original_key': 'original_val'}
    # To make this test pass for the placeholder Driver, we would change it to:
    # result = stage.execute(self.context.copy())
