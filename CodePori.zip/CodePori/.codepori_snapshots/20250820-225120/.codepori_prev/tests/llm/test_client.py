import pytest
import httpx
import json
from typing import Dict, Any, List

from pytest_httpx import HTTPXMock

# Assuming the client and its exceptions are defined in src.llm.client
# This is a hypothetical structure for the purpose of these tests.
# We will test a concrete implementation of a generic client.
from src.llm.client import LLMClient, APIError, NetworkError

# --- Constants for Tests ---
TEST_API_KEY = "test-api-key-12345"
TEST_BASE_URL = "https://api.test-llm.com/v1"
TEST_MODEL = "test-model-v1"
CHAT_COMPLETION_ENDPOINT = "/chat/completions"


# --- Fixtures ---

@pytest.fixture
def llm_client() -> LLMClient:
    """Provides a test instance of the LLMClient."""
    return LLMClient(
        api_key=TEST_API_KEY,
        base_url=TEST_BASE_URL,
        model=TEST_MODEL
    )


@pytest.fixture
def sample_messages() -> List[Dict[str, str]]:
    """Provides a sample list of messages for chat completion payloads."""
    return [
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": "Hello, world!"}
    ]


# --- Test Cases ---

def test_client_initialization(llm_client: LLMClient):
    """Verify that the client initializes with correct attributes and headers."""
    assert llm_client.api_key == TEST_API_KEY
    assert llm_client.base_url == TEST_BASE_URL
    assert llm_client.model == TEST_MODEL

    expected_headers = {
        "Authorization": f"Bearer {TEST_API_KEY}",
        "Content-Type": "application/json",
    }
    # Assuming headers are accessible via a property for testing
    assert llm_client._headers == expected_headers

def test_client_initialization_no_api_key():
    """Verify that initializing the client with an empty API key raises an error."""
    with pytest.raises(ValueError, match="API key cannot be empty"):
        LLMClient(api_key="", base_url=TEST_BASE_URL, model=TEST_MODEL)

@pytest.mark.asyncio
async def test_chat_completion_success(
    llm_client: LLMClient,
    httpx_mock: HTTPXMock,
    sample_messages: List[Dict[str, str]]
):
    """Test a successful chat completion API call."""
    mock_response_payload = {
        "id": "chatcmpl-123",
        "object": "chat.completion",
        "created": 1677652288,
        "model": TEST_MODEL,
        "choices": [
            {
                "index": 0,
                "message": {
                    "role": "assistant",
                    "content": "Hello! How can I assist you today?",
                },
                "finish_reason": "stop",
            }
        ],
    }

    full_url = f"{TEST_BASE_URL}{CHAT_COMPLETION_ENDPOINT}"
    httpx_mock.add_response(method="POST", url=full_url, json=mock_response_payload, status_code=200)

    response = await llm_client.chat_completion(messages=sample_messages)

    assert response == mock_response_payload

    # Verify the request was made as expected
    request = httpx_mock.get_request()
    assert request is not None
    assert request.method == "POST"
    assert str(request.url) == full_url
    assert request.headers["Authorization"] == f"Bearer {TEST_API_KEY}"
    request_payload = json.loads(request.content)
    assert request_payload["model"] == TEST_MODEL
    assert request_payload["messages"] == sample_messages

@pytest.mark.asyncio
async def test_chat_completion_with_extra_params(
    llm_client: LLMClient,
    httpx_mock: HTTPXMock,
    sample_messages: List[Dict[str, str]]
):
    """Verify that extra parameters are correctly passed in the request body."""
    full_url = f"{TEST_BASE_URL}{CHAT_COMPLETION_ENDPOINT}"
    httpx_mock.add_response(method="POST", url=full_url, json={}, status_code=200)

    extra_params = {"temperature": 0.7, "max_tokens": 150}
    await llm_client.chat_completion(messages=sample_messages, **extra_params)

    request = httpx_mock.get_request()
    assert request is not None
    request_payload = json.loads(request.content)

    assert request_payload["temperature"] == 0.7
    assert request_payload["max_tokens"] == 150
    assert "model" in request_payload
    assert "messages" in request_payload


@pytest.mark.asyncio
@pytest.mark.parametrize(
    "status_code, error_text",
    [
        (401, '{"error": "Invalid API key"}'),
        (429, '{"error": "Rate limit exceeded"}'),
        (500, '{"error": "Internal server error"}'),
        (503, '{"error": "Service unavailable"}'),
    ]
)
async def test_chat_completion_api_error(
    llm_client: LLMClient,
    httpx_mock: HTTPXMock,
    sample_messages: List[Dict[str, str]],
    status_code: int,
    error_text: str
):
    """Test that API errors (4xx, 5xx) are wrapped in a custom APIError."""
    full_url = f"{TEST_BASE_URL}{CHAT_COMPLETION_ENDPOINT}"
    httpx_mock.add_response(
        method="POST",
        url=full_url,
        text=error_text,
        status_code=status_code
    )

    with pytest.raises(APIError) as exc_info:
        await llm_client.chat_completion(messages=sample_messages)

    # Check that the exception message contains useful info
    assert str(status_code) in str(exc_info.value)
    assert error_text in str(exc_info.value)
    assert isinstance(exc_info.value.__cause__, httpx.HTTPStatusError)

@pytest.mark.asyncio
@pytest.mark.parametrize(
    "exception_type",
    [httpx.ConnectError, httpx.ReadTimeout, httpx.PoolTimeout]
)
async def test_chat_completion_network_error(
    llm_client: LLMClient,
    httpx_mock: HTTPXMock,
    sample_messages: List[Dict[str, str]],
    exception_type: type
):
    """Test that transport-level errors are wrapped in a custom NetworkError."""
    full_url = f"{TEST_BASE_URL}{CHAT_COMPLETION_ENDPOINT}"
    httpx_mock.add_exception(exception_type("Simulated network failure"), url=full_url)

    with pytest.raises(NetworkError) as exc_info:
        await llm_client.chat_completion(messages=sample_messages)

    assert "Simulated network failure" in str(exc_info.value)
    assert isinstance(exc_info.value.__cause__, httpx.TransportError)

@pytest.mark.asyncio
async def test_chat_completion_invalid_json_response(
    llm_client: LLMClient,
    httpx_mock: HTTPXMock,
    sample_messages: List[Dict[str, str]]
):
    """Test handling of a 200 OK response with non-JSON content."""
    full_url = f"{TEST_BASE_URL}{CHAT_COMPLETION_ENDPOINT}"
    # The response is a malformed HTML page instead of JSON
    invalid_content = "<html><body><h1>Gateway Error</h1></body></html>"
    httpx_mock.add_response(method="POST", url=full_url, text=invalid_content, status_code=200)

    # The client should ideally catch this and raise a specific error.
    # Here, we test for the underlying json.JSONDecodeError which httpx's .json() would raise.
    # A more robust client might wrap this in a custom `ResponseParsingError`.
    with pytest.raises(json.JSONDecodeError):
        await llm_client.chat_completion(messages=sample_messages)
