import os
import shutil
import tempfile
from pathlib import Path
from typing import Generator

import pytest


@pytest.fixture(scope="function")
def workspace() -> Generator[Path, None, None]:
    """
    Creates a temporary, isolated workspace directory for a single test function.

    This fixture ensures test atomicity by providing a clean environment.
    It automatically handles creation, directory switching, and cleanup.

    Usage:
        def test_something(workspace: Path):
            # The current working directory is now `workspace`
            (workspace / "test_file.txt").write_text("hello")
            assert os.path.exists("test_file.txt")

    Yields:
        Generator[Path, None, None]: The path to the temporary workspace directory.
    """
    original_cwd = Path.cwd()
    # Create a unique temporary directory using the standard library
    temp_dir_path = Path(tempfile.mkdtemp(prefix="pytest-ws-"))

    try:
        # Change the current working directory to the new temp directory
        os.chdir(temp_dir_path)
        # Yield control to the test function
        yield temp_dir_path
    finally:
        # Ensure cleanup happens even if the test fails
        # Change back to the original directory
        os.chdir(original_cwd)
        # Recursively remove the temporary directory and its contents
        shutil.rmtree(temp_dir_path, ignore_errors=True)
