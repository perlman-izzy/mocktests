#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""Unit tests for pipeline stages.

This module contains tests for individual PipelineStage implementations,
ensuring each stage's logic is correct in isolation. Mocks are used for
the Workspace and any external dependencies like file I/O, subprocess calls,
or API clients.
"""

import pytest
from unittest.mock import Mock, patch, call, mock_open

# Absolute imports from repo root as per project standards.
# NOTE: These are hypothetical paths based on the project description.
# Adjust them to match the actual project structure.
from src.workspace import Workspace
from src.pipeline.stages import (
    ReadInputStage,
    GenerateCodeStage,
    RunTestsStage,
    WriteOutputStage
)


@pytest.fixture
def mock_workspace() -> Mock:
    """Provides a mock Workspace object for tests."""
    ws = Mock(spec=Workspace)
    # Use a real dict to simulate the workspace's state
    ws_data = {}

    def get_data(key, default=None):
        return ws_data.get(key, default)

    def set_data(key, value):
        ws_data[key] = value

    ws.get.side_effect = get_data
    ws.set.side_effect = set_data
    # Attach the underlying data dict for introspection in tests if needed
    ws.data = ws_data
    return ws


class TestReadInputStage:
    """Tests for the ReadInputStage."""

    def test_execute_reads_file_and_updates_workspace(self, mock_workspace: Mock):
        """
        Verify that ReadInputStage reads content from a given path
        and stores it in the workspace under the 'initial_prompt' key.
        """
        # Arrange
        input_path = "/path/to/input.txt"
        file_content = "This is the initial prompt from a file."
        stage = ReadInputStage(input_path=input_path)

        # Act
        with patch("builtins.open", mock_open(read_data=file_content)) as m_open:
            stage.execute(mock_workspace)

        # Assert
        m_open.assert_called_once_with(input_path, "r", encoding="utf-8")
        mock_workspace.set.assert_called_once_with("initial_prompt", file_content)
        assert mock_workspace.data["initial_prompt"] == file_content


class TestGenerateCodeStage:
    """Tests for the GenerateCodeStage."""

    @patch('src.pipeline.stages.LLMClient')
    def test_execute_generates_code_and_updates_workspace(self, MockLLMClient, mock_workspace: Mock):
        """
        Verify that GenerateCodeStage uses the LLM to generate code
        based on a prompt from the workspace and stores the result.
        """
        # Arrange
        mock_llm_instance = MockLLMClient.return_value
        expected_code = "def hello_world():\n    print('Hello, World!')"
        mock_llm_instance.generate.return_value = expected_code

        prompt = "Write a hello world function in Python."
        mock_workspace.data["prompt"] = prompt

        stage = GenerateCodeStage(model="gpt-4-turbo")

        # Act
        stage.execute(mock_workspace)

        # Assert
        mock_workspace.get.assert_called_once_with("prompt")
        mock_llm_instance.generate.assert_called_once_with(prompt, model="gpt-4-turbo")
        mock_workspace.set.assert_called_once_with("generated_code", expected_code)
        assert mock_workspace.data["generated_code"] == expected_code


class TestRunTestsStage:
    """Tests for the RunTestsStage."""

    @patch('src.pipeline.stages.run_command')
    @patch('builtins.open', new_callable=mock_open)
    def test_execute_runs_tests_and_records_success(self, m_open, mock_run_command, mock_workspace: Mock):
        """
        Verify that RunTestsStage executes a test command and records a successful outcome.
        """
        # Arrange
        generated_code = "def test_addition():\n    assert 1 + 1 == 2"
        mock_workspace.data["generated_code"] = generated_code

        # Simulate a successful subprocess run
        mock_run_command.return_value = (0, "1 passed in 0.01s", "")

        stage = RunTestsStage(test_command="pytest /tmp/tests/test_generated.py", code_path="/tmp/tests/test_generated.py")

        # Act
        stage.execute(mock_workspace)

        # Assert
        m_open.assert_called_once_with("/tmp/tests/test_generated.py", "w", encoding="utf-8")
        m_open().write.assert_called_once_with(generated_code)
        mock_run_command.assert_called_once_with("pytest /tmp/tests/test_generated.py")

        expected_calls = [
            call("test_results", {"return_code": 0, "stdout": "1 passed in 0.01s", "stderr": ""}),
            call("tests_passed", True)
        ]
        mock_workspace.set.assert_has_calls(expected_calls, any_order=True)

    @patch('src.pipeline.stages.run_command')
    @patch('builtins.open', new_callable=mock_open)
    def test_execute_runs_tests_and_records_failure(self, m_open, mock_run_command, mock_workspace: Mock):
        """
        Verify that RunTestsStage executes a test command and records a failed outcome.
        """
        # Arrange
        generated_code = "def test_fail():\n    assert 1 == 2"
        mock_workspace.data["generated_code"] = generated_code

        # Simulate a failed subprocess run
        mock_run_command.return_value = (1, "", "E   AssertionError: assert 1 == 2")

        stage = RunTestsStage(test_command="pytest /tmp/tests/test_generated.py", code_path="/tmp/tests/test_generated.py")

        # Act
        stage.execute(mock_workspace)

        # Assert
        m_open.assert_called_once_with("/tmp/tests/test_generated.py", "w", encoding="utf-8")
        mock_run_command.assert_called_once_with("pytest /tmp/tests/test_generated.py")
        expected_calls = [
            call("test_results", {"return_code": 1, "stdout": "", "stderr": "E   AssertionError: assert 1 == 2"}),
            call("tests_passed", False)
        ]
        mock_workspace.set.assert_has_calls(expected_calls, any_order=True)


class TestWriteOutputStage:
    """Tests for the WriteOutputStage."""

    def test_execute_writes_workspace_content_to_file(self, mock_workspace: Mock):
        """
        Verify that WriteOutputStage writes the content of a specified
        workspace key to a designated output file.
        """
        # Arrange
        output_path = "/path/to/output.py"
        file_content = "# Final generated code\ndef main():\n    pass"
        mock_workspace.data["final_code"] = file_content

        stage = WriteOutputStage(workspace_key="final_code", output_path=output_path)

        # Act
        with patch("builtins.open", mock_open()) as m_open:
            stage.execute(mock_workspace)

        # Assert
        mock_workspace.get.assert_called_once_with("final_code")
        m_open.assert_called_once_with(output_path, "w", encoding="utf-8")
        m_open().write.assert_called_once_with(file_content)

    def test_execute_handles_missing_key_gracefully(self, mock_workspace: Mock):
        """
        Verify that WriteOutputStage does not fail or write a file if the
        workspace key is missing. It should do nothing.
        """
        # Arrange
        # Ensure the key is not in the workspace
        mock_workspace.data = {}
        output_path = "/path/to/output.py"

        stage = WriteOutputStage(workspace_key="non_existent_key", output_path=output_path)

        # Act
        with patch("builtins.open", mock_open()) as m_open:
            stage.execute(mock_workspace)

        # Assert
        mock_workspace.get.assert_called_once_with("non_existent_key")
        m_open.assert_not_called()
