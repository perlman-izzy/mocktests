import pytest
from pathlib import Path
from unittest.mock import patch

# Assuming the main entry point for the pipeline is in 'src.driver'
# and it exposes a function like 'run_pipeline'.
# Also assuming a custom exception for better error handling.
from src.driver import run_pipeline
from src.core.exceptions import PipelineError


@pytest.fixture
def test_workspace(tmp_path: Path) -> Path:
    """Creates a temporary workspace with input and output directories."""
    input_dir = tmp_path / "input"
    output_dir = tmp_path / "output"

    input_dir.mkdir()
    output_dir.mkdir()

    return tmp_path


def test_pipeline_success_single_file(test_workspace: Path):
    """
    Verifies a successful pipeline run with a single input file.
    It checks for correct LLM interaction and output file creation.
    """
    # Arrange
    input_dir = test_workspace / "input"
    output_dir = test_workspace / "output"

    input_file = input_dir / "document1.txt"
    input_content = "This is the source content for the LLM."
    input_file.write_text(input_content, encoding='utf-8')

    expected_llm_response = "This is the processed content from the LLM."
    expected_output_file = output_dir / "document1.txt"

    # Mock the external LLM client interface
    with patch("src.driver.llm_adapter.generate_completion", autospec=True) as mock_llm_generate:
        mock_llm_generate.return_value = expected_llm_response

        # Act
        run_pipeline(input_dir=input_dir, output_dir=output_dir)

        # Assert
        # 1. Verify the LLM adapter was called exactly once with the correct content.
        mock_llm_generate.assert_called_once_with(prompt=input_content)

        # 2. Verify the output file was created.
        assert expected_output_file.exists(), "Output file was not created."

        # 3. Verify the output file content matches the LLM's response.
        output_content = expected_output_file.read_text(encoding='utf-8')
        assert output_content == expected_llm_response


def test_pipeline_success_multiple_files(test_workspace: Path):
    """
    Verifies a successful pipeline run with multiple input files to ensure
    the driver iterates and processes each file correctly.
    """
    # Arrange
    input_dir = test_workspace / "input"
    output_dir = test_workspace / "output"

    (input_dir / "doc_a.txt").write_text("Content A")
    (input_dir / "doc_b.txt").write_text("Content B")

    llm_responses = {
        "Content A": "Processed A",
        "Content B": "Processed B",
    }

    with patch("src.driver.llm_adapter.generate_completion", autospec=True) as mock_llm_generate:
        mock_llm_generate.side_effect = lambda prompt: llm_responses.get(prompt, "Error: Unexpected Content")

        # Act
        run_pipeline(input_dir=input_dir, output_dir=output_dir)

        # Assert
        # 1. Verify the LLM was called for each file.
        assert mock_llm_generate.call_count == 2

        # 2. Verify all output files exist and have the correct, distinct content.
        output_file_a = output_dir / "doc_a.txt"
        output_file_b = output_dir / "doc_b.txt"

        assert output_file_a.exists()
        assert output_file_a.read_text() == "Processed A"

        assert output_file_b.exists()
        assert output_file_b.read_text() == "Processed B"

        # 3. Verify no other unexpected files were created.
        assert len(list(output_dir.iterdir())) == 2


def test_pipeline_handles_empty_input_directory(test_workspace: Path):
    """
    Ensures the pipeline runs gracefully and does nothing when the input
    directory is empty.
    """
    # Arrange
    input_dir = test_workspace / "input"
    output_dir = test_workspace / "output"

    with patch("src.driver.llm_adapter.generate_completion", autospec=True) as mock_llm_generate:
        # Act
        run_pipeline(input_dir=input_dir, output_dir=output_dir)

        # Assert
        # 1. The LLM should not have been called.
        mock_llm_generate.assert_not_called()

        # 2. The output directory should remain empty.
        assert not any(output_dir.iterdir()), "Output directory should be empty."


def test_pipeline_handles_llm_api_error_gracefully(test_workspace: Path):
    """
    Verifies that if the LLM adapter raises an exception, the pipeline
    catches it, wraps it in a domain-specific exception, and stops processing.
    """
    # Arrange
    input_dir = test_workspace / "input"
    output_dir = test_workspace / "output"
    (input_dir / "file_that_will_fail.txt").write_text("Some content")

    with patch("src.driver.llm_adapter.generate_completion", autospec=True) as mock_llm_generate:
        mock_llm_generate.side_effect = ConnectionError("Failed to connect to LLM API")

        # Act & Assert
        # The pipeline should catch the specific error and wrap it.
        with pytest.raises(PipelineError, match=r"Failed to process .*file_that_will_fail.txt"):
            run_pipeline(input_dir=input_dir, output_dir=output_dir)

        # Assert that no partial or incorrect output file was created.
        assert not any(output_dir.iterdir()), "No output files should be created on LLM error."


def test_pipeline_skips_non_targeted_files(test_workspace: Path):
    """
    Tests that the pipeline correctly skips files that are not its target,
    assuming the driver has logic to filter files (e.g., by a glob pattern).
    """
    # Arrange
    input_dir = test_workspace / "input"
    output_dir = test_workspace / "output"

    (input_dir / "document1.md").write_text("Valid markdown")
    (input_dir / "image.jpg").touch()  # Non-text file
    (input_dir / "config.json").write_text("{}") # Another non-target file

    expected_llm_response = "PROCESSED: Valid markdown"

    with patch("src.driver.llm_adapter.generate_completion", autospec=True) as mock_llm_generate:
        mock_llm_generate.return_value = expected_llm_response

        # Act
        # Assuming the driver can be configured to only process '*.md' files
        run_pipeline(input_dir=input_dir, output_dir=output_dir, file_glob="*.md")

        # Assert
        # 1. LLM was only called for the .md file.
        mock_llm_generate.assert_called_once_with(prompt="Valid markdown")

        # 2. Only the output for the .md file was created.
        expected_output_file = output_dir / "document1.md"
        assert expected_output_file.exists()
        assert len(list(output_dir.iterdir())) == 1
