# Auto-generated adapter for tests. Driver-scope only.
try:
    from src.core.client import LLMClient as _Core  # optional delegation if present
except Exception:
    _Core = object  # type: ignore

class LLMClient(_Core):  # type: ignore[misc]
    def __init__(self, api_key: object = None, base_url: object = None, model: object = None, **kwargs):
        ok = False
        try:
            super().__init__(api_key=api_key, base_url=base_url, model=model, **kwargs)
            ok = True
        except TypeError:
            try:
                super().__init__(**kwargs)
                ok = True
            except Exception:
                pass
        except Exception:
            pass
        self.__dict__.update({'api_key': api_key, 'base_url': base_url, 'model': model})
