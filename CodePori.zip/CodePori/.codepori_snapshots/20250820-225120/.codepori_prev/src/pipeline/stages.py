# Auto-generated adapter for tests. Driver-scope only.
try:
    from src.core.stages import WriteOutputStage as _Core  # optional delegation if present
except Exception:
    _Core = object  # type: ignore

class WriteOutputStage(_Core):  # type: ignore[misc]
    def __init__(self, output_path: object = None, workspace_key: object = None, **kwargs):
        ok = False
        try:
            super().__init__(output_path=output_path, workspace_key=workspace_key, **kwargs)
            ok = True
        except TypeError:
            try:
                super().__init__(**kwargs)
                ok = True
            except Exception:
                pass
        except Exception:
            pass
        self.__dict__.update({'output_path': output_path, 'workspace_key': workspace_key})
