import logging
import os
import shutil
from pathlib import Path
from typing import Dict, Any, Generator, List, Union, Tuple

# Configure a module-level logger
# Applications using this module can then configure the logger's handlers and level.
logger = logging.getLogger(__name__)


class WorkspaceError(Exception):
    """Base exception for all workspace-related errors."""
    pass


class WorkspaceNotFoundError(WorkspaceError):
    """Raised when the workspace directory does not exist when it's expected to."""
    pass


class WorkspaceExistsError(WorkspaceError):
    """Raised when attempting to create a workspace that already exists."""
    pass


class FileInWorkspaceNotFoundError(WorkspaceError):
    """Raised when a requested file or directory is not found within the workspace."""
    pass


class InvalidWorkspacePathError(WorkspaceError):
    """Raised when the provided path is invalid, e.g., it's a file, not a directory."""
    pass


class OutsideWorkspaceError(WorkspaceError, SecurityException):
    """Raised when an operation attempts to access a path outside the workspace root."""
    pass


class Workspace:
    """Manages a directory on the filesystem, ensuring all operations are contained.

    This class acts as a driver or shim for a specific directory, providing a safe
    and convenient API for file and subdirectory manipulations. It prevents path
    traversal attacks and provides clear, specific exceptions for various error
    conditions.

    Attributes:
        root (pathlib.Path): The absolute path to the root of the workspace directory.
    """

    def __init__(self, base_path: Union[str, Path]) -> None:
        """Initializes the Workspace instance.

        Args:
            base_path: The path to the directory that will serve as the workspace.

        Raises:
            InvalidWorkspacePathError: If the path exists and is a file.
        """
        self.root = Path(base_path).resolve()
        if self.root.is_file():
            raise InvalidWorkspacePathError(
                f"The specified path '{self.root}' exists and is a file, not a directory."
            )
        logger.info(f"Workspace initialized at: {self.root}")

    def __enter__(self) -> 'Workspace':
        """Context manager entry. Creates the workspace if it doesn't exist."""
        self.create(exist_ok=True)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context manager exit. Does not automatically clean up."""
        logger.info(f"Exiting workspace context for: {self.root}")

    def _resolve_path(self, relative_path: Union[str, Path]) -> Path:
        """Resolves a relative path against the workspace root with security checks.

        This method ensures that the resolved path is strictly within the workspace
        directory, preventing directory traversal attacks (e.g., using '../').

        Args:
            relative_path: The path relative to the workspace root.

        Returns:
            The resolved, absolute path.

        Raises:
            OutsideWorkspaceError: If the resolved path is outside the workspace.
        """
        # Normalize the path to handle redundant separators or '.'
        path_to_check = Path(relative_path)
        if path_to_check.is_absolute():
            raise OutsideWorkspaceError(
                f"Absolute paths are not allowed: '{relative_path}'"
            )

        absolute_path = (self.root / path_to_check).resolve()

        # The most reliable way to check for containment
        try:
            absolute_path.relative_to(self.root)
        except ValueError:
            logger.error(
                f"Security Alert: Attempted path traversal to '{absolute_path}' "
                f"from workspace '{self.root}'."
            )
            raise OutsideWorkspaceError(
                f"Path '{relative_path}' resolves outside the workspace."
            )

        return absolute_path

    def exists(self) -> bool:
        """Checks if the workspace directory exists.

        Returns:
            True if the workspace directory exists, False otherwise.
        """
        return self.root.is_dir()

    def create(self, exist_ok: bool = False) -> None:
        """Creates the workspace directory.

        Args:
            exist_ok: If False (the default), a WorkspaceExistsError is raised if the
                      directory already exists.

        Raises:
            WorkspaceExistsError: If the directory exists and exist_ok is False.
            WorkspaceError: If an OS-level error occurs during creation.
        """
        if self.exists():
            if not exist_ok:
                raise WorkspaceExistsError(f"Workspace already exists at: {self.root}")
            logger.debug(f"Workspace at {self.root} already exists, creation skipped.")
            return

        try:
            logger.info(f"Creating workspace directory at: {self.root}")
            self.root.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            logger.error(f"Failed to create workspace at {self.root}: {e}")
            raise WorkspaceError(f"Could not create workspace at {self.root}: {e}") from e

    def delete(self) -> None:
        """Deletes the entire workspace directory and all its contents.

        Raises:
            WorkspaceNotFoundError: If the workspace directory does not exist.
            WorkspaceError: If an OS-level error occurs during deletion.
        """
        if not self.exists():
            raise WorkspaceNotFoundError(f"Workspace to delete does not exist at: {self.root}")

        try:
            logger.warning(f"Deleting entire workspace at: {self.root}")
            shutil.rmtree(self.root)
        except OSError as e:
            logger.error(f"Failed to delete workspace at {self.root}: {e}")
            raise WorkspaceError(f"Could not delete workspace at {self.root}: {e}") from e

    def clear(self) -> None:
        """Removes all files and subdirectories from the workspace, leaving the root directory.

        Raises:
            WorkspaceNotFoundError: If the workspace directory does not exist.
            WorkspaceError: If an OS-level error occurs during clearing.
        """
        if not self.exists():
            raise WorkspaceNotFoundError(f"Workspace to clear does not exist at: {self.root}")

        logger.warning(f"Clearing all contents of workspace at: {self.root}")
        for item in self.root.iterdir():
            try:
                if item.is_dir():
                    shutil.rmtree(item)
                else:
                    item.unlink()
            except OSError as e:
                logger.error(f"Failed to remove item {item} while clearing workspace: {e}")
                raise WorkspaceError(f"Could not clear item {item}: {e}") from e

    def write_file(self, file_path: Union[str, Path], content: Union[str, bytes]) -> None:
        """Writes content to a file within the workspace.

        This will create any necessary parent directories.

        Args:
            file_path: The path of the file relative to the workspace root.
            content: The string or bytes content to write to the file.

        Raises:
            WorkspaceNotFoundError: If the workspace root does not exist.
            WorkspaceError: On any file writing errors.
        """
        if not self.exists():
            raise WorkspaceNotFoundError(f"Cannot write file; workspace does not exist at: {self.root}")

        absolute_path = self._resolve_path(file_path)
        mode = 'wb' if isinstance(content, bytes) else 'w'

        try:
            absolute_path.parent.mkdir(parents=True, exist_ok=True)
            with open(absolute_path, mode, encoding=None if mode == 'wb' else 'utf-8') as f:
                f.write(content)
            logger.info(f"Wrote file to {absolute_path}")
        except (IOError, OSError) as e:
            logger.error(f"Failed to write file to {absolute_path}: {e}")
            raise WorkspaceError(f"Could not write to file '{file_path}': {e}") from e

    def read_file(self, file_path: Union[str, Path], as_bytes: bool = False) -> Union[str, bytes]:
        """Reads content from a file within the workspace.

        Args:
            file_path: The path of the file relative to the workspace root.
            as_bytes: If True, reads the file in binary mode and returns bytes.

        Returns:
            The file content as a string or bytes.

        Raises:
            FileInWorkspaceNotFoundError: If the file does not exist.
            WorkspaceError: On any file reading errors.
        """
        absolute_path = self._resolve_path(file_path)
        mode = 'rb' if as_bytes else 'r'

        try:
            with open(absolute_path, mode, encoding=None if mode == 'rb' else 'utf-8') as f:
                content = f.read()
            logger.info(f"Read file from {absolute_path}")
            return content
        except FileNotFoundError:
            raise FileInWorkspaceNotFoundError(f"File '{file_path}' not found in workspace.") from None
        except (IOError, OSError) as e:
            logger.error(f"Failed to read file from {absolute_path}: {e}")
            raise WorkspaceError(f"Could not read file '{file_path}': {e}") from e

    def delete_file(self, file_path: Union[str, Path]) -> None:
        """Deletes a file within the workspace.

        Args:
            file_path: The path of the file relative to the workspace root.

        Raises:
            FileInWorkspaceNotFoundError: If the file does not exist.
            WorkspaceError: On any file deletion errors.
        """
        absolute_path = self._resolve_path(file_path)

        try:
            absolute_path.unlink()
            logger.warning(f"Deleted file at {absolute_path}")
        except FileNotFoundError:
            raise FileInWorkspaceNotFoundError(f"File '{file_path}' to delete was not found.") from None
        except OSError as e:
            logger.error(f"Failed to delete file at {absolute_path}: {e}")
            raise WorkspaceError(f"Could not delete file '{file_path}': {e}") from e

    def list_files(self, sub_dir: Union[str, Path] = '.') -> List[str]:
        """Lists all files (not directories) in a given subdirectory of the workspace.

        Args:
            sub_dir: The subdirectory relative to the workspace root.

        Returns:
            A list of filenames.
        """
        absolute_path = self._resolve_path(sub_dir)
        if not absolute_path.is_dir():
            raise FileInWorkspaceNotFoundError(f"Subdirectory '{sub_dir}' does not exist.")

        return [item.name for item in absolute_path.iterdir() if item.is_file()]

    def get_summary(self) -> Dict[str, Union[int, str]]:
        """Provides a summary of the workspace contents.

        Calculates the total number of files and the total size of all files.

        Returns:
            A dictionary containing 'file_count' and 'total_size_bytes'.
        """
        if not self.exists():
            raise WorkspaceNotFoundError(f"Cannot get summary; workspace does not exist at: {self.root}")

        file_count = 0
        total_size = 0
        try:
            for dirpath, _, filenames in os.walk(self.root):
                file_count += len(filenames)
                for f in filenames:
                    fp = os.path.join(dirpath, f)
                    # Check for broken symlinks
                    if not os.path.islink(fp):
                        total_size += os.path.getsize(fp)
        except OSError as e:
            logger.error(f"Error calculating workspace summary for {self.root}: {e}")
            raise WorkspaceError(f"Could not calculate summary: {e}") from e

        summary = {
            "file_count": file_count,
            "total_size_bytes": total_size
        }
        logger.info(f"Workspace summary for {self.root}: {summary}")
        return summary
