#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Main entry point for the CodePori Driver command-line interface.

This module is responsible for parsing command-line arguments, setting up logging,
loading configuration, and initializing the main application driver to execute
the requested commands.
"""

import argparse
import logging
import logging.handlers
import os
import sys
from pathlib import Path
from typing import List, Optional, Sequence

# --- Hypothetical imports from other project modules ---
# These are assumed to be implemented in other parts of the project.
# We are programming to an interface, ensuring this entry point is robust.

# Assuming a main driver class that orchestrates the core logic.
from src.codepori_driver.driver import CodePoriDriver

# Assuming a configuration loader utility.
from src.codepori_driver.config import ConfigLoader, AppConfig

# Assuming custom exceptions for clear error handling.
from src.codepori_driver.exceptions import CodePoriError, ConfigError

# Assuming a version file exists to manage the application version.
from src.codepori_driver._version import __version__

# --- Constants ---
APP_NAME = "CodePoriDriver"
DEFAULT_LOG_DIR = Path.home() / ".codepori" / "logs"
DEFAULT_LOG_FILE = DEFAULT_LOG_DIR / "codepori_driver.log"


def setup_logging(
    log_level: int = logging.INFO,
    log_file: Optional[Path] = None,
    log_to_console: bool = True
) -> None:
    """Configures the logging for the application.

    Sets up a logger that can write to both the console and a rotating file.
    The log file is rotated when it reaches 10 MB and keeps up to 5 backups.

    Args:
        log_level: The minimum logging level to capture (e.g., logging.INFO).
        log_file: The path to the log file. If None, defaults to
                  DEFAULT_LOG_FILE.
        log_to_console: Whether to output logs to the console (stderr).
    """
    logger = logging.getLogger("src.codepori_driver")
    logger.setLevel(log_level)

    log_format = logging.Formatter(
        fmt="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )

    if log_to_console:
        console_handler = logging.StreamHandler(sys.stderr)
        console_handler.setLevel(log_level)
        console_handler.setFormatter(log_format)
        logger.addHandler(console_handler)

    effective_log_file = log_file or DEFAULT_LOG_FILE

    try:
        effective_log_file.parent.mkdir(parents=True, exist_ok=True)
        # Set up a rotating file handler
        file_handler = logging.handlers.RotatingFileHandler(
            effective_log_file,
            maxBytes=10 * 1024 * 1024,  # 10 MB
            backupCount=5
        )
        file_handler.setLevel(log_level)
        file_handler.setFormatter(log_format)
        logger.addHandler(file_handler)
    except (OSError, PermissionError) as e:
        logging.basicConfig(level=logging.WARNING)
        logger.warning(
            f"Could not configure file logging at {effective_log_file}: {e}",
            exc_info=False
        )
        logger.info("File logging will be disabled for this session.")

    logger.debug("Logging configured. Log level: %s", logging.getLevelName(log_level))


def create_argument_parser() -> argparse.ArgumentParser:
    """Creates and configures the argument parser for the CLI.

    Defines the main commands, sub-commands, and global options for the
    application's command-line interface.

    Returns:
        An instance of argparse.ArgumentParser configured for the application.
    """
    parser = argparse.ArgumentParser(
        prog=APP_NAME,
        description="A CLI tool for orchestrating modular code generation.",
        epilog=f"For more help on a specific command, type: '{APP_NAME} <command> --help'"
    )

    parser.add_argument(
        "-v", "--version",
        action="version",
        version=f"%(prog)s {__version__}",
        help="Show the application's version and exit."
    )

    # --- Global Options ---
    global_group = parser.add_argument_group("Global Options")
    global_group.add_argument(
        "--config",
        type=Path,
        default=None,
        help="Path to a custom YAML configuration file."
    )
    global_group.add_argument(
        "--log-file",
        type=Path,
        default=DEFAULT_LOG_FILE,
        help=f"Path to the log file. Defaults to: {DEFAULT_LOG_FILE}"
    )
    global_group.add_argument(
        "--verbose",
        action="store_const",
        dest="log_level",
        const=logging.DEBUG,
        default=logging.INFO,
        help="Enable verbose (DEBUG level) logging output."
    )
    global_group.add_argument(
        "--quiet",
        action="store_const",
        dest="log_level",
        const=logging.WARNING,
        help="Suppress informational output, showing only warnings and errors."
    )

    # --- Sub-commands ---
    subparsers = parser.add_subparsers(
        dest="command",
        required=True,
        title="Available Commands",
        metavar="<command>"
    )

    # 'init' command
    parser_init = subparsers.add_parser(
        "init",
        help="Initialize a new CodePori project in the current directory.",
        description="Sets up the necessary configuration and directory structure for a new project."
    )
    parser_init.add_argument(
        "-f", "--force",
        action="store_true",
        help="Force initialization even if a project file already exists."
    )
    parser_init.add_argument(
        "--template",
        type=str,
        default="default",
        help="Specify a project template to use for initialization."
    )

    # 'generate' command
    parser_generate = subparsers.add_parser(
        "generate",
        help="Generate a new module based on a specification.",
        description="Scaffolds a new module, including boilerplate code, tests, and documentation."
    )
    parser_generate.add_argument(
        "module_name",
        type=str,
        help="The name of the module to generate (e.g., 'user_service')."
    )
    parser_generate.add_argument(
        "--spec-file",
        type=Path,
        required=True,
        help="Path to the module specification file (e.g., a YAML or JSON file)."
    )

    return parser

def main(argv: Optional[Sequence[str]] = None) -> int:
    """The main execution function for the command-line interface.

    This function orchestrates the entire application flow:
    1. Parses command-line arguments.
    2. Sets up logging.
    3. Loads application configuration.
    4. Instantiates and runs the main driver.
    5. Handles exceptions and returns an appropriate exit code.

    Args:
        argv: A sequence of command-line arguments. If None, `sys.argv[1:]` is used.

    Returns:
        An integer exit code (0 for success, non-zero for failure).
    """
    parser = create_argument_parser()
    args = parser.parse_args(argv)

    # 1. Setup logging as early as possible
    setup_logging(log_level=args.log_level, log_file=args.log_file)
    log = logging.getLogger(f"src.codepori_driver.{__name__}")
    log.debug("Application starting with arguments: %s", args)

    try:
        # 2. Load configuration
        log.info("Loading application configuration...")
        config_loader = ConfigLoader()
        # Assume loader can find default config or use path from args
        config: AppConfig = config_loader.load(config_path=args.config)
        log.info("Configuration loaded successfully.")

        # 3. Initialize the main driver with the loaded config
        driver = CodePoriDriver(config)

        # 4. Execute the requested command
        if args.command == "init":
            log.info("Executing 'init' command.")
            driver.initialize_project(force=args.force, template=args.template)
            print("Project initialized successfully.")

        elif args.command == "generate":
            log.info("Executing 'generate' command for module: %s", args.module_name)
            driver.generate_module(
                module_name=args.module_name,
                spec_file=args.spec_file
            )
            print(f"Module '{args.module_name}' generated successfully.")

        else:
            # This case should not be reachable due to `required=True` in subparsers
            # but is included for robustness.
            log.error("Unknown command: %s", args.command)
            parser.print_help()
            return 1

    except (CodePoriError, ConfigError) as e:
        log.error("A known application error occurred: %s", e, exc_info=True)
        print(f"Error: {e}", file=sys.stderr)
        return 1
    except FileNotFoundError as e:
        log.error("A required file was not found: %s", e, exc_info=True)
        print(f"Error: File not found - {e}", file=sys.stderr)
        return 1
    except Exception as e:
        log.critical("An unexpected error occurred: %s", e, exc_info=True)
        print(f"An unexpected error occurred. See log file for details: {args.log_file}", file=sys.stderr)
        return 2

    log.info("Application finished successfully.")
    return 0


if __name__ == "__main__":
    # This allows the script to be run directly and facilitates testing.
    # The exit code from main() is passed to sys.exit().
    sys.exit(main())
