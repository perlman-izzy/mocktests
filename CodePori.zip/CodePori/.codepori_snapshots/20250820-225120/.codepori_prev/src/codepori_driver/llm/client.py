import abc
import logging
import os
from typing import Any, Dict, Type, Literal, Union

import httpx
from pydantic import BaseModel, Field, SecretStr, ValidationError
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

# Configure a logger for the LLM client module
logger = logging.getLogger(__name__)


# --- Custom Exceptions ---

class LLMClientError(Exception):
    """Base exception for all LLM client-related errors."""
    pass


class LLMConfigurationError(LLMClientError):
    """Raised when there is a configuration issue with the LLM client."""
    pass


class LLMAPIError(LLMClientError):
    """Raised when the LLM API returns an error response."""
    def __init__(self, message: str, status_code: int, response_data: Dict[str, Any]):
        super().__init__(message)
        self.status_code = status_code
        self.response_data = response_data

    def __str__(self):
        return f"{super().__str__()} (Status: {self.status_code}, Response: {self.response_data})"


class LLMResponseError(LLMClientError):
    """Raised when the LLM response is malformed or cannot be parsed."""
    pass

# --- Data Models for Configuration and Payloads ---

class LLMConfig(BaseModel):
    """Configuration model for LLM clients.

    Attributes:
        provider: The name of the LLM provider (e.g., 'openai').
        model_name: The specific model to use (e.g., 'gpt-4-turbo').
        api_key: The API key for authentication.
        api_base_url: The base URL for the API endpoint.
        timeout: The timeout in seconds for API requests.
        max_retries: The maximum number of retries for a failed request.
        temperature: The sampling temperature for the model.
        max_tokens: The maximum number of tokens to generate.
    """
    provider: Literal["openai"] = "openai"
    model_name: str = Field(..., description="The specific model to use.")
    api_key: SecretStr = Field(..., description="The API key for authentication.")
    api_base_url: str = "https://api.openai.com/v1"
    timeout: int = 60
    max_retries: int = 3
    temperature: float = 0.7
    max_tokens: int = 4096


class CodeGenerationPrompt(BaseModel):
    """Structured prompt for code generation tasks.

    Attributes:
        system_prompt: Instructions for the AI model's role and persona.
        task_description: A detailed description of the code to be generated.
        context: Existing code, file structure, or other relevant context.
        specifications: Specific requirements, constraints, or examples.
    """
    system_prompt: str
    task_description: str
    context: str
    specifications: str


class PlanCreationPrompt(BaseModel):
    """Structured prompt for creating a development plan.

    Attributes:
        system_prompt: Instructions for the AI model's role and persona.
        project_goal: The high-level goal of the project.
        project_description: A detailed description of the project.
        constraints: Any constraints or limitations to consider.
    """
    system_prompt: str
    project_goal: str
    project_description: str
    constraints: str


# --- Abstract Base Classes for LLM Clients ---

class BaseLLMClient(abc.ABC):
    """Abstract base class for a synchronous LLM client.

    This class defines the standard interface for interacting with LLMs,
    ensuring that all concrete implementations provide the same core
    functionalities.
    """

    @abc.abstractmethod
    def generate_code(self, prompt: CodeGenerationPrompt) -> str:
        """Generates code based on a detailed prompt.

        Args:
            prompt: A CodeGenerationPrompt object with structured input.

        Returns:
            The generated code as a string.

        Raises:
            LLMAPIError: If the API call fails.
            LLMResponseError: If the response is malformed.
        """
        raise NotImplementedError

    @abc.abstractmethod
    def create_plan(self, prompt: PlanCreationPrompt) -> Dict[str, Any]:
        """Creates a development plan based on a project description.

        Args:
            prompt: A PlanCreationPrompt object with structured input.

        Returns:
            A dictionary representing the structured development plan.

        Raises:
            LLMAPIError: If the API call fails.
            LLMResponseError: If the response is malformed.
        """
        raise NotImplementedError


# --- Concrete Implementation for OpenAI (Synchronous) ---

class OpenAIClient(BaseLLMClient):
    """Synchronous client for interacting with the OpenAI API.

    This class implements the BaseLLMClient interface for OpenAI models.
    It handles API requests, error handling, and retries.
    """

    def __init__(self, config: LLMConfig):
        """Initializes the OpenAIClient.

        Args:
            config: An LLMConfig object containing connection and model details.

        Raises:
            LLMConfigurationError: If the provided API key is missing.
        """
        if not config.api_key:
            raise LLMConfigurationError("OpenAI API key is not provided.")
        self.config = config
        self._client = httpx.Client(
            base_url=self.config.api_base_url,
            headers={
                "Authorization": f"Bearer {self.config.api_key.get_secret_value()}",
                "Content-Type": "application/json",
            },
            timeout=self.config.timeout,
        )

    def _invoke_llm(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Makes a request to the OpenAI API with retry logic.

        Args:
            payload: The dictionary payload to send to the chat completions endpoint.

        Returns:
            The 'message' dictionary from the first choice in the API response.

        Raises:
            LLMAPIError: If the API returns a non-200 status code after retries.
            LLMResponseError: If the response structure is not as expected.
        """
        retry_decorator = retry(
            stop=stop_after_attempt(self.config.max_retries),
            wait=wait_exponential(multiplier=1, min=2, max=10),
            retry=retry_if_exception_type((httpx.RequestError, httpx.HTTPStatusError)),
            reraise=True,
        )

        @retry_decorator
        def _make_request() -> httpx.Response:
            logger.info(f"Making request to OpenAI model: {self.config.model_name}")
            try:
                response = self._client.post("/chat/completions", json=payload)
                response.raise_for_status()
                return response
            except httpx.HTTPStatusError as e:
                logger.error(f"HTTP Status Error: {e.response.status_code} - {e.response.text}")
                raise LLMAPIError(
                    message=f"API request failed with status {e.response.status_code}",
                    status_code=e.response.status_code,
                    response_data=e.response.json(),
                )
            except httpx.RequestError as e:
                logger.error(f"HTTP Request Error: {e}")
                raise  # Re-raise to be caught by tenacity

        try:
            response = _make_request()
            response_data = response.json()

            if not response_data.get("choices") or not isinstance(response_data["choices"], list):
                raise LLMResponseError(f"Invalid response structure: 'choices' key missing or invalid.")

            first_choice = response_data["choices"][0]
            if "message" not in first_choice:
                raise LLMResponseError(f"Invalid response structure: 'message' key missing in choice.")

            return first_choice["message"]
        except ValidationError as e:
            raise LLMResponseError(f"Failed to parse API response: {e}")
        except Exception as e:
            logger.exception("An unexpected error occurred during LLM invocation.")
            if not isinstance(e, (LLMAPIError, LLMResponseError)):
                raise LLMClientError(f"An unexpected error occurred: {e}") from e
            raise e

    def generate_code(self, prompt: CodeGenerationPrompt) -> str:
        """Generates code using the OpenAI chat completions API.

        Args:
            prompt: A CodeGenerationPrompt object with structured input.

        Returns:
            The generated code as a string.
        """
        logger.debug(f"Generating code for task: {prompt.task_description[:50]}...")
        payload = {
            "model": self.config.model_name,
            "messages": [
                {"role": "system", "content": prompt.system_prompt},
                {
                    "role": "user",
                    "content": f"Task: {prompt.task_description}\n\nContext:\n{prompt.context}\n\nSpecifications:\n{prompt.specifications}",
                },
            ],
            "temperature": self.config.temperature,
            "max_tokens": self.config.max_tokens,
        }
        response_message = self._invoke_llm(payload)
        if not response_message.get("content") or not isinstance(response_message["content"], str):
             raise LLMResponseError("Response message content is missing or not a string.")
        return response_message["content"]

    def create_plan(self, prompt: PlanCreationPrompt) -> Dict[str, Any]:
        """Creates a structured plan using the OpenAI chat completions API.

        Args:
            prompt: A PlanCreationPrompt object with structured input.

        Returns:
            A dictionary representing the structured plan.
        """
        logger.debug(f"Creating plan for project: {prompt.project_goal[:50]}...")
        payload = {
            "model": self.config.model_name,
            "messages": [
                {"role": "system", "content": prompt.system_prompt},
                {
                    "role": "user",
                    "content": f"Goal: {prompt.project_goal}\n\nDescription:\n{prompt.project_description}\n\nConstraints:\n{prompt.constraints}",
                },
            ],
            "temperature": self.config.temperature,
            "max_tokens": self.config.max_tokens,
            "response_format": {"type": "json_object"},
        }
        response_message = self._invoke_llm(payload)
        content = response_message.get("content")
        if not content or not isinstance(content, str):
             raise LLMResponseError("Response message content is missing or not a string.")
        try:
            import json
            return json.loads(content)
        except json.JSONDecodeError as e:
            raise LLMResponseError(f"Failed to decode JSON from LLM response: {e}") from e


# --- Client Factory ---

CLIENT_REGISTRY: Dict[str, Type[BaseLLMClient]] = {
    "openai": OpenAIClient,
}

def get_llm_client(config: LLMConfig) -> BaseLLMClient:
    """Factory function to get an instance of an LLM client.

    Args:
        config: The LLMConfig object specifying which client to create.

    Returns:
        An instance of a class derived from BaseLLMClient.

    Raises:
        LLMConfigurationError: If the provider in the config is not supported.
    """
    provider = config.provider
    client_class = CLIENT_REGISTRY.get(provider)

    if not client_class:
        raise LLMConfigurationError(
            f"Unsupported LLM provider: '{provider}'. Supported providers are: {list(CLIENT_REGISTRY.keys())}"
        )

    logger.info(f"Initializing LLM client for provider: {provider}")
    return client_class(config=config)
