import logging
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Type

# Assuming these modules exist as part of the project structure.
# These are not standard library imports and are expected to be created in other modules.
from src.codepori_config.config_loader import ConfigLoader, ConfigLoadError
from src.codepori_config.models import Config
from src.codepori_pipeline.stage_loader import StageLoader, StageLoadError
from src.codepori_pipeline.stage import BaseStage
from src.codepori_pipeline.models import StageResult
from src.codepori_shared.context import ExecutionContext
from src.codepori_shared.logging_config import setup_logging
from src.codepori_shared.exceptions import CodePoriError

# Set up a module-level logger
logger = logging.getLogger(__name__)


class DriverError(CodePoriError):
    """Base exception for errors raised by the Driver."""
    pass


class DriverInitializationError(DriverError):
    """Raised when the Driver fails to initialize correctly."""
    pass


class PipelineExecutionError(DriverError):
    """Raised when the pipeline execution fails."""
    pass


class StageExecutionError(PipelineExecutionError):
    """Raised when a specific stage in the pipeline fails."""
    def __init__(self, stage_name: str, message: str):
        self.stage_name = stage_name
        full_message = f"Execution failed at stage '{stage_name}': {message}"
        super().__init__(full_message)


class Driver:
    """Orchestrates the execution of a multi-stage pipeline.

    The Driver is the main entry point for running a process. It is responsible for:
    1. Loading and validating the application configuration.
    2. Setting up application-wide logging.
    3. Dynamically loading and initializing all pipeline stages specified in the config.
    4. Executing the pipeline stages sequentially, passing a shared context.
    5. Handling stage results and managing the overall pipeline flow (e.g., stopping on failure).

    Attributes:
        config_path (Path): The path to the main configuration file.
        config (Config): The loaded and validated configuration object.
        stages (List[BaseStage]): An ordered list of initialized pipeline stage instances.
    """

    def __init__(self, config_path: str):
        """Initializes the Driver.

        Args:
            config_path: The file path to the main YAML configuration file.

        Raises:
            DriverInitializationError: If configuration loading, logging setup,
                or stage initialization fails.
        """
        self.config_path = Path(config_path)
        logger.info(f"Initializing driver with configuration: {self.config_path}")

        if not self.config_path.is_file():
            msg = f"Configuration file not found at: {self.config_path}"
            logger.error(msg)
            raise DriverInitializationError(msg)

        try:
            self.config: Config = self._load_and_validate_config()
            self._setup_logging()
            self.stages: List[BaseStage] = self._initialize_pipeline_stages()
        except (ConfigLoadError, StageLoadError) as e:
            logger.critical(f"Failed to initialize driver: {e}", exc_info=True)
            raise DriverInitializationError(f"Driver initialization failed. Reason: {e}") from e
        except Exception as e:
            logger.critical("An unexpected error occurred during driver initialization.", exc_info=True)
            raise DriverInitializationError(f"Unexpected error during initialization: {e}") from e

        logger.info("Driver initialized successfully with %d stages.", len(self.stages))

    def _load_and_validate_config(self) -> Config:
        """Loads and validates the configuration file.

        Uses the ConfigLoader to parse the YAML file and validate it against
        the expected schema defined in the Config model.

        Returns:
            The validated configuration object.

        Raises:
            ConfigLoadError: If the configuration cannot be loaded or is invalid.
        """
        logger.debug(f"Attempting to load configuration from {self.config_path}")
        loader = ConfigLoader(self.config_path)
        config = loader.load_config()
        logger.info("Configuration loaded and validated successfully.")
        return config

    def _setup_logging(self) -> None:
        """Configures the application's logging system.

        Uses a centralized logging setup utility, passing it the logging
        configuration section from the main config file.
        """
        logger.debug("Setting up application-wide logging.")
        try:
            log_config = self.config.logging
            setup_logging(
                level=log_config.level,
                log_to_file=log_config.log_to_file,
                log_file_path=log_config.log_file_path,
                log_format=log_config.format
            )
            logger.info("Logging configured successfully.")
        except Exception as e:
            # If logging fails, we can't use the logger. Print to stderr and exit.
            print(f"CRITICAL: Failed to configure logging: {e}", file=sys.stderr)
            raise DriverInitializationError(f"Failed to configure logging: {e}") from e

    def _initialize_pipeline_stages(self) -> List[BaseStage]:
        """Dynamically loads and initializes all stages defined in the configuration.

        Iterates through the list of stage configurations, uses the StageLoader to
        get the class for each stage, and then instantiates it with its specific
        parameters.

        Returns:
            A list of initialized stage objects in the order of execution.

        Raises:
            StageLoadError: If a stage class cannot be found or instantiated.
        """
        logger.info("Initializing pipeline stages...")
        initialized_stages = []
        stage_configs = self.config.pipeline.stages

        if not stage_configs:
            logger.warning("No stages defined in the pipeline configuration.")
            return []

        stage_loader = StageLoader()

        for stage_config in stage_configs:
            stage_name = stage_config.name
            stage_params = stage_config.params or {}
            logger.debug(f"Loading stage '{stage_name}' with params: {stage_params}")

            try:
                stage_class = stage_loader.load_stage(stage_name)
                stage_instance = stage_class(**stage_params)
                initialized_stages.append(stage_instance)
                logger.info(f"Successfully initialized stage: '{stage_name}'")
            except StageLoadError as e:
                logger.error(f"Failed to load stage '{stage_name}'. Reason: {e}")
                raise
            except TypeError as e:
                # This catches errors where stage __init__ params don't match config
                logger.error(f"Mismatched parameters for stage '{stage_name}'. Reason: {e}")
                raise StageLoadError(f"Mismatched parameters for stage '{stage_name}'. Check your config.yaml. Error: {e}") from e

        return initialized_stages

    def _create_execution_context(self) -> ExecutionContext:
        """Creates the initial shared execution context for the pipeline run.

        The context is used to pass data and state between stages.

        Returns:
            A new instance of ExecutionContext.
        """
        logger.debug("Creating new execution context.")
        initial_data = {
            'config': self.config,
            'pipeline_results': []
        }
        return ExecutionContext(initial_data)

    def run(self) -> None:
        """Executes the entire pipeline from start to finish.

        Iterates through the initialized stages and executes them sequentially.
        A shared ExecutionContext is passed to each stage.
        If a stage fails, the pipeline may be halted based on the 'fail_fast' configuration.

        Raises:
            PipelineExecutionError: If the pipeline is empty or if a stage fails
                and the 'fail_fast' policy is enabled.
        """
        if not self.stages:
            logger.warning("Pipeline has no stages to run. Exiting.")
            return

        logger.info("Starting pipeline execution...")
        context = self._create_execution_context()
        fail_fast = self.config.pipeline.fail_fast

        for stage in self.stages:
            stage_name = stage.__class__.__name__
            logger.info(f"--- Executing stage: {stage_name} ---")

            try:
                result: StageResult = stage.execute(context)
                context.update_history(stage_name, result)

                if result.success:
                    logger.info(f"Stage '{stage_name}' completed successfully. Message: {result.message}")
                else:
                    logger.error(f"Stage '{stage_name}' failed. Message: {result.message}")
                    if fail_fast:
                        raise StageExecutionError(stage_name, result.message)

            except Exception as e:
                logger.critical(
                    f"An unhandled exception occurred in stage '{stage_name}': {e}",
                    exc_info=True
                )
                if fail_fast:
                    raise StageExecutionError(
                        stage_name, f"Unhandled exception: {e}"
                    ) from e
                # If not failing fast, we record the failure and continue
                error_result = StageResult(
                    success=False,
                    message=f"Unhandled exception: {e}",
                    data={'exception_type': type(e).__name__, 'exception_args': e.args}
                )
                context.update_history(stage_name, error_result)

        logger.info("Pipeline execution finished.")


def main():
    """Main entry point for command-line execution."""
    # This function is for demonstration and direct execution of the driver.
    # In a real application, this might be handled by a CLI framework like Click or Argparse.
    if len(sys.argv) != 2:
        print("Usage: python -m src.codepori_driver.driver <path_to_config.yaml>", file=sys.stderr)
        sys.exit(1)

    config_file_path = sys.argv[1]

    # Basic root logger setup until the driver configures it properly
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')

    try:
        driver = Driver(config_path=config_file_path)
        driver.run()
        logger.info("CodePori Driver run completed successfully.")
        sys.exit(0)
    except DriverError as e:
        # DriverError and its children are expected, controlled errors.
        logger.critical(f"A critical driver error occurred: {e}", exc_info=False) # exc_info is false to avoid messy tracebacks for controlled exits
        sys.exit(1)
    except Exception as e:
        # Catch any other unexpected exceptions
        logger.critical("An unexpected fatal error occurred during driver execution.", exc_info=True)
        sys.exit(1)


if __name__ == '__main__':
    main()
