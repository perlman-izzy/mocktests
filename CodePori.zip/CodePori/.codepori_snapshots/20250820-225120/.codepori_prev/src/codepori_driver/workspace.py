import os
import json
import shutil
import logging
import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Union, Generator

# Set up a dedicated logger for workspace operations
logger = logging.getLogger(__name__)

class WorkspaceError(Exception):
    """Base exception for workspace-related errors."""
    pass

class FileNotFoundError(WorkspaceError):
    """Raised when a requested file does not exist in the workspace."""
    pass

class ArtifactNotFoundError(WorkspaceError):
    """Raised when a requested artifact does not exist."""
    pass

class Workspace: 
    """Manages a directory for code generation, execution, and artifact storage.

    The Workspace provides a unified API for all file system operations required by
    different stages of the code generation pipeline. It ensures that all file I/O
    is contained within a specific root directory, preventing accidental modification
    of the host file system.

    It also serves as a state container, storing intermediate data (artifacts)
    like plans, reports, and analysis results in a structured way.

    Attributes:
        root (Path): The absolute path to the root directory of the workspace.
    """

    def __init__(self, path: Union[str, Path]) -> None:
        """Initializes the Workspace and creates the root directory if it doesn't exist.

        Args:
            path (Union[str, Path]): The path to the workspace's root directory.
        """
        self.root = Path(path).resolve()
        try:
            self.root.mkdir(parents=True, exist_ok=True)
            logger.info(f"Workspace initialized at: {self.root}")
        except OSError as e:
            logger.error(f"Failed to create workspace directory at {self.root}: {e}")
            raise WorkspaceError(f"Could not create workspace at {self.root}") from e

        self._artifacts_dir = self.root / ".codepori_artifacts"
        self._artifacts_dir.mkdir(exist_ok=True)

    @property
    def src_path(self) -> Path:
        """Provides the path to the source code directory.

        This directory is intended to hold the main application source code.
        It is created on first access.

        Returns:
            Path: The path to the 'src' directory within the workspace.
        """
        path = self.root / "src"
        path.mkdir(exist_ok=True)
        return path

    @property
    def tests_path(self) -> Path:
        """Provides the path to the tests directory.

        This directory is intended to hold tests for the source code.
        It is created on first access.

        Returns:
            Path: The path to the 'tests' directory within the workspace.
        """
        path = self.root / "tests"
        path.mkdir(exist_ok=True)
        return path

    def get_path(self, relative_path: Union[str, Path]) -> Path:
        """Constructs an absolute path within the workspace from a relative path.

        This is a security and convenience method to ensure all file access is
        sandboxed within the workspace root.

        Args:
            relative_path (Union[str, Path]): The relative path from the workspace root.

        Returns:
            Path: The resolved, absolute path within the workspace.

        Raises:
            ValueError: If the relative path attempts to escape the workspace root.
        """
        path = self.root.joinpath(relative_path).resolve()
        if self.root not in path.parents and path != self.root:
            raise ValueError("Attempted to access a path outside the workspace boundary.")
        return path

    def write_file(self, file_path: Union[str, Path], content: str) -> None:
        """Writes content to a file within the workspace.

        This method ensures that parent directories are created before writing the file.

        Args:
            file_path (Union[str, Path]): The relative path of the file to write.
            content (str): The string content to write to the file.
        """
        abs_path = self.get_path(file_path)
        try:
            abs_path.parent.mkdir(parents=True, exist_ok=True)
            abs_path.write_text(content, encoding='utf-8')
            logger.debug(f"Successfully wrote to file: {file_path}")
        except IOError as e:
            logger.error(f"Failed to write to file {abs_path}: {e}")
            raise WorkspaceError(f"I/O error writing to {file_path}") from e

    def read_file(self, file_path: Union[str, Path]) -> str:
        """Reads the content of a file from the workspace.

        Args:
            file_path (Union[str, Path]): The relative path of the file to read.

        Returns:
            str: The content of the file.

        Raises:
            FileNotFoundError: If the specified file does not exist.
        """
        abs_path = self.get_path(file_path)
        if not abs_path.is_file():
            logger.warning(f"Attempted to read non-existent file: {file_path}")
            raise FileNotFoundError(f"File not found at: {file_path}")
        try:
            return abs_path.read_text(encoding='utf-8')
        except IOError as e:
            logger.error(f"Failed to read file {abs_path}: {e}")
            raise WorkspaceError(f"I/O error reading from {file_path}") from e

    def delete_file(self, file_path: Union[str, Path]) -> None:
        """Deletes a file within the workspace.

        Args:
            file_path (Union[str, Path]): The relative path of the file to delete.
        """
        abs_path = self.get_path(file_path)
        if abs_path.is_file():
            abs_path.unlink()
            logger.info(f"Deleted file: {file_path}")
        else:
            logger.warning(f"Attempted to delete non-existent file: {file_path}")

    def list_files(self, sub_dir: Union[str, Path] = '.', recursive: bool = True, glob_pattern: str = '**/*') -> Generator[Path, None, None]:
        """Lists all files in a subdirectory of the workspace, optionally recursively.

        Args:
            sub_dir (Union[str, Path], optional): The subdirectory to start from.
                Defaults to the workspace root.
            recursive (bool, optional): Whether to list files in subdirectories.
                If False, glob_pattern should be adjusted (e.g., '*'). Defaults to True.
            glob_pattern (str, optional): A glob pattern to filter files.
                Defaults to '**/*' to match all files recursively.

        Yields:
            Generator[Path, None, None]: A generator of Path objects for each file,
                                         relative to the workspace root.
        """
        start_path = self.get_path(sub_dir)
        if not start_path.is_dir():
            return

        for path in start_path.glob(glob_pattern):
            if path.is_file():
                yield path.relative_to(self.root)

    def set_artifact(self, name: str, content: Any) -> None:
        """Saves an artifact (e.g., a plan, report) to the workspace.

        The artifact is serialized to JSON and stored in a dedicated artifacts directory.
        A timestamp is added to the filename for versioning.

        Args:
            name (str): The name of the artifact (e.g., 'initial_plan').
            content (Any): The content of the artifact, must be JSON-serializable.
        """
        timestamp = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
        artifact_path = self._artifacts_dir / f"{name}_{timestamp}.json"
        try:
            with artifact_path.open('w', encoding='utf-8') as f:
                json.dump(content, f, indent=2)
            logger.info(f"Saved artifact '{name}' to {artifact_path.name}")
        except TypeError as e:
            logger.error(f"Failed to serialize artifact '{name}': {e}")
            raise WorkspaceError(f"Artifact content for '{name}' is not JSON-serializable.") from e

    def get_artifact(self, name: str, latest: bool = True) -> Any:
        """Retrieves an artifact from the workspace.

        Args:
            name (str): The name of the artifact to retrieve.
            latest (bool, optional): If True, retrieves the most recent version
                of the artifact. If False, this will raise an error if multiple
                versions exist. Defaults to True.

        Returns:
            Any: The deserialized content of the artifact.

        Raises:
            ArtifactNotFoundError: If no artifact with the given name is found.
            WorkspaceError: If multiple artifacts are found but 'latest' is False.
        """
        matching_artifacts = sorted(
            self._artifacts_dir.glob(f"{name}_*.json"),
            reverse=True
        )

        if not matching_artifacts:
            raise ArtifactNotFoundError(f"Artifact '{name}' not found.")

        if not latest and len(matching_artifacts) > 1:
            raise WorkspaceError(f"Multiple artifacts named '{name}' found. Specify a version or use latest=True.")

        artifact_path = matching_artifacts[0]
        logger.info(f"Loading latest artifact for '{name}' from {artifact_path.name}")
        try:
            with artifact_path.open('r', encoding='utf-8') as f:
                return json.load(f)
        except json.JSONDecodeError as e:
            logger.error(f"Failed to decode JSON for artifact {artifact_path.name}: {e}")
            raise WorkspaceError(f"Could not parse artifact '{name}'.") from e

    def get_file_tree(self, sub_dir: str = '.', include_artifacts: bool = False) -> str:
        """Generates a string representation of the file tree.

        Args:
            sub_dir (str): The subdirectory to generate the tree from. Defaults to root.
            include_artifacts (bool): Whether to include the .codepori_artifacts dir.

        Returns:
            str: A string representing the file tree.
        """
        tree_lines = []
        start_path = self.get_path(sub_dir)

        for root, dirs, files in os.walk(start_path, topdown=True):
            if not include_artifacts:
                dirs[:] = [d for d in dirs if d != '.codepori_artifacts']

            level = Path(root).relative_to(start_path).parts
            indent = ' ' * 4 * (len(level))
            tree_lines.append(f"{indent}{Path(root).name}/")
            sub_indent = ' ' * 4 * (len(level) + 1)
            for f in sorted(files):
                tree_lines.append(f"{sub_indent}{f}")

        return "\n".join(tree_lines)

    def clear(self, keep_artifacts: bool = False) -> None:
        """Clears the workspace by deleting all its contents.

        Args:
            keep_artifacts (bool): If True, the artifacts directory will not be deleted.
        """
        logger.warning(f"Clearing workspace at {self.root}")
        for path in self.root.iterdir():
            if keep_artifacts and path.samefile(self._artifacts_dir):
                continue
            if path.is_dir():
                shutil.rmtree(path)
            else:
                path.unlink()
        logger.info("Workspace cleared.")

    @classmethod
    def from_archive(cls, archive_path: Union[str, Path], output_dir: Union[str, Path]) -> 'Workspace':
        """Creates a Workspace by extracting an archive.

        Args:
            archive_path (Union[str, Path]): Path to the archive file (e.g., .zip, .tar.gz).
            output_dir (Union[str, Path]): The directory to extract the workspace into.

        Returns:
            Workspace: A new Workspace instance pointing to the extracted directory.
        """
        archive_path = Path(archive_path)
        output_dir = Path(output_dir)
        shutil.unpack_archive(archive_path, output_dir)
        logger.info(f"Extracted workspace from {archive_path} to {output_dir}")
        return cls(output_dir)

    def to_archive(self, output_path: Union[str, Path], archive_format: str = 'zip') -> Path:
        """Archives the entire workspace into a file.

        Args:
            output_path (Union[str, Path]): The path for the output archive file, 
                without the extension.
            archive_format (str): The format of the archive ('zip', 'tar', 'gztar').

        Returns:
            Path: The full path to the created archive file.
        """
        archive_file = shutil.make_archive(
            base_name=str(output_path),
            format=archive_format,
            root_dir=self.root
        )
        logger.info(f"Workspace archived to {archive_file}")
        return Path(archive_file)
