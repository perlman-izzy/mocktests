import os
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Type, Union

import yaml
from pydantic import BaseModel, Field, SecretStr, ValidationError
from pydantic_settings import BaseSettings, PydanticBaseSettingsSource

# Define a base directory for the project to locate configuration files.
# This assumes the 'src' directory is the root for our package.
# In a real application, this might be determined more dynamically.
BASE_DIR = Path(__file__).resolve().parent.parent
DEFAULT_CONFIG_PATH = BASE_DIR / "config" / "default_config.yaml"


class ConfigurationError(Exception):
    """Custom exception for configuration-related errors."""
    pass


# --- Pydantic Models for Configuration Sections ---

class LLMProviderSettings(BaseModel):
    """Settings specific to an LLM provider."""
    model: str = Field(
        default="gpt-4-turbo-preview",
        description="The specific model name to use for the LLM provider.",
    )
    temperature: float = Field(
        default=0.1,
        description="Sampling temperature for the model, between 0 and 2.",
        ge=0.0,
        le=2.0,
    )
    max_tokens: int = Field(
        default=4096, description="Maximum number of tokens to generate in a completion."
    )
    timeout: int = Field(default=120, description="Request timeout in seconds.")


class LLMConfig(BaseModel):
    """Configuration for the Large Language Model client."""
    provider: str = Field(
        default="openai", description="The LLM provider to use (e.g., 'openai', 'anthropic')."
    )
    api_key: Optional[SecretStr] = Field(
        default=None, description="API key for the LLM provider. Best set via environment variable."
    )
    settings: Dict[str, LLMProviderSettings] = Field(
        default_factory=dict,
        description="A dictionary of provider-specific settings.",
    )


class AgentConfig(BaseModel):
    """Configuration for a specific type of agent in the pipeline."""
    name: str = Field(description="The name of the agent role (e.g., 'Manager', 'Developer').")
    llm_provider: str = Field(
        default="openai", description="The LLM provider this agent will use."
    )
    prompt_template_path: str = Field(
        description="Path to the prompt template file for this agent."
    )


class PipelineConfig(BaseModel):
    """Configuration for the main processing pipeline flow."""
    max_iterations: int = Field(
        default=10, description="Maximum number of iterations for the main development loop."
    )
    agents: List[AgentConfig] = Field(
        default_factory=list,
        description="Configuration for the agents involved in the pipeline.",
    )
    workspace_dir: str = Field(
        default="./workspace",
        description="Directory to store project files and outputs.",
    )


class LoggingConfig(BaseModel):
    """Configuration for application logging."""
    level: str = Field(
        default="INFO",
        description="The root logging level for the application.",
        pattern=r"^(CRITICAL|ERROR|WARNING|INFO|DEBUG|NOTSET)$",
    )
    format: str = Field(
        default="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        description="The log message format string.",
    )
    log_file: Optional[str] = Field(
        default=None,
        description="Optional file path to write logs to. If None, logs to stdout.",
    )


class ToolConfig(BaseModel):
    """Configuration for external tools."""
    enabled: bool = Field(default=True, description="Whether the tool is enabled.")
    path: Optional[str] = Field(
        default=None, description="Path to the tool's executable if not in system PATH."
    )
    timeout: int = Field(default=60, description="Default timeout for tool execution.")


class ToolsConfig(BaseModel):
    """Container for all external tool configurations."""
    linter: ToolConfig = Field(
        default_factory=ToolConfig, description="Configuration for the code linter tool."
    )
    test_runner: ToolConfig = Field(
        default_factory=ToolConfig,
        description="Configuration for the unit test runner tool.",
    )


# --- Main Settings Management ---


def yaml_config_settings_source(settings: BaseSettings) -> Dict[str, Any]:
    """A pydantic-settings source that loads settings from a YAML file.

    This function is designed to be used in the `customise_sources` class method
    of a Pydantic `BaseSettings` class. It reads a YAML file specified by the
    `CODEPORI_CONFIG_PATH` environment variable or a default path.

    Args:
        settings: The settings instance being customized.

    Returns:
        A dictionary of configuration values loaded from the YAML file.
    """
    config_path_str = os.getenv("CODEPORI_CONFIG_PATH", str(DEFAULT_CONFIG_PATH))
    config_path = Path(config_path_str)

    if not config_path.is_file():
        logging.warning(
            f"Configuration file not found at '{config_path}'. "
            f"Using default settings and environment variables only."
        )
        return {}

    try:
        with open(config_path, "r") as f:
            yaml_data = yaml.safe_load(f)
        return yaml_data if yaml_data is not None else {}
    except yaml.YAMLError as e:
        raise ConfigurationError(f"Error parsing YAML file '{config_path}': {e}") from e
    except IOError as e:
        raise ConfigurationError(
            f"Error reading configuration file '{config_path}': {e}"
        ) from e


class Settings(BaseSettings):
    """The main application settings class.

    This class aggregates all configuration components and uses `pydantic-settings`
    to load values from multiple sources, including a YAML file, environment
    variables, and secrets files.

    The loading priority is:
    1. Arguments passed to `__init__` (not typically used for global settings).
    2. Environment variables (e.g., `CODEPORI_LLM__API_KEY` overrides `llm.api_key`).
    3. YAML configuration file.
    4. Default values defined in the model fields.
    """

    llm: LLMConfig = Field(default_factory=LLMConfig)
    pipeline: PipelineConfig = Field(default_factory=PipelineConfig)
    logging: LoggingConfig = Field(default_factory=LoggingConfig)
    tools: ToolsConfig = Field(default_factory=ToolsConfig)

    class Config:
        """Pydantic-settings configuration.

        - `env_prefix`: Specifies the prefix for environment variables.
        - `env_nested_delimiter`: Defines the separator for nested models.
          For example, `CODEPORI_LLM__PROVIDER` maps to `llm.provider`.
        """

        env_prefix = "CODEPORI_"
        env_nested_delimiter = "__"
        env_file = ".env"
        env_file_encoding = "utf-8"

        @classmethod
        def customise_sources(
            cls,
            settings_cls: Type[BaseSettings],
            init_settings: PydanticBaseSettingsSource,
            env_settings: PydanticBaseSettingsSource,
            dotenv_settings: PydanticBaseSettingsSource,
            file_secret_settings: PydanticBaseSettingsSource,
        ) -> tuple[PydanticBaseSettingsSource, ...]:
            """Customizes the source loading order for settings.

            This method injects our custom YAML source into the loading process.
            The order defines the priority of settings sources (last one wins).
            We place the YAML source after .env but before environment variables.
            """
            return (
                init_settings,
                dotenv_settings,  # Loads from .env file
                yaml_config_settings_source,  # Custom YAML loader
                env_settings,  # Loads from environment variables
                file_secret_settings,  # Loads from Docker secrets
            )


# --- Global Singleton Instance ---

_settings_instance: Optional[Settings] = None


def get_settings() -> Settings:
    """Provides a global, cached instance of the application settings.

    This function implements a singleton pattern for the configuration object.
    It loads the settings on the first call and returns the cached instance
    on subsequent calls, preventing repeated file I/O and parsing.

    Raises:
        ConfigurationError: If the loaded configuration fails Pydantic validation.

    Returns:
        The application's `Settings` instance.
    """
    global _settings_instance
    if _settings_instance is None:
        try:
            _settings_instance = Settings()
        except ValidationError as e:
            # Provide a more user-friendly error message for validation issues.
            error_messages = [f"  - {err['loc']}: {err['msg']}" for err in e.errors()]
            raise ConfigurationError(
                f"Configuration validation failed:\n" + "\n".join(error_messages)
            ) from e
    return _settings_instance


# A globally accessible instance of the settings.
# Other modules can simply `from src.codepori_driver.config import settings`
settings: Settings = get_settings()


# --- Example Usage & Self-Test ---

def setup_logging() -> None:
    """Configures the root logger based on the loaded settings."""
    log_config = settings.logging
    logging.basicConfig(
        level=log_config.level,
        format=log_config.format,
        filename=log_config.log_file,
        filemode="a" if log_config.log_file else None,
    )
    logging.getLogger("pydantic").setLevel(logging.WARNING)


if __name__ == "__main__":
    # This block allows the script to be run directly for configuration testing.
    print("--- Codepori Configuration Module Self-Test ---")

    # Setup logging to see output from the config loader
    setup_logging()

    print(f"Attempting to load configuration...")
    print(f"Default config file path: {DEFAULT_CONFIG_PATH}")
    env_path = os.getenv("CODEPORI_CONFIG_PATH")
    if env_path:
        print(f"CODEPORI_CONFIG_PATH is set to: {env_path}")
    else:
        print("CODEPORI_CONFIG_PATH is not set, using default.")

    try:
        # The 'settings' object is already loaded at import time
        print("\nConfiguration loaded successfully!")
        print("\n--- Current Settings ---")
        # Use model_dump for a clean, serializable representation
        print(settings.model_dump_json(indent=2))

        # Example of accessing a nested setting
        print("\n--- Accessing Specific Values ---")
        print(f"Pipeline max iterations: {settings.pipeline.max_iterations}")
        print(f"LLM provider: {settings.llm.provider}")

        # Note on secrets
        if settings.llm.api_key:
            print("LLM API Key is set (value is hidden).")
        else:
            print("LLM API Key is NOT set.")

    except ConfigurationError as e:
        print(f"\nERROR: An error occurred while loading configuration: {e}")
    except Exception as e:
        print(f"\nERROR: An unexpected error occurred: {e}")
