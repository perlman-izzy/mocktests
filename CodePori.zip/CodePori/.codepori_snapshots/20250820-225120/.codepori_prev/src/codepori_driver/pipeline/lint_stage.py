"""
Defines the pipeline stage for performing static code analysis (linting).

This module contains the `LintStage` class, which is responsible for executing
a configurable linter tool (like ruff, flake8, or pylint) on the source code
within a given workspace. It captures the results, generates a report, and
determines the stage's success based on the linter's output.
"""

from __future__ import annotations

import logging
import shlex
import subprocess
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from src.codepori_driver.pipeline.pipeline_stage import PipelineStage
from src.codepori_driver.pipeline.pipeline_state import PipelineState
from src.codepori_driver.workspace.workspace import Workspace

logger = logging.getLogger(__name__)


class LintStage(PipelineStage):
    """
    A pipeline stage for running a linter on the project's source code.

    This stage automates the process of static code analysis. It runs a
    specified linter command within the project's directory, captures all
    output, and saves it to a detailed report file in the workspace's
    artifacts directory. The stage's outcome (success or failure) depends
    on the exit code of the linter process, although this behavior can be
    overridden.

    Attributes:
        lint_command (List[str]): The linter command and its arguments, split
            into a list.
        report_filename (str): The name for the output report file.
        ignore_failure (bool): If True, the stage will report success even if
            the linter finds issues (i.e., returns a non-zero exit code).
        working_directory (Optional[Path]): A specific subdirectory within the
            project to run the command from. Defaults to the project root.
    """

    DEFAULT_LINT_COMMAND: str = "ruff check ."
    DEFAULT_REPORT_FILENAME: str = "lint_report.txt"

    def __init__(
        self,
        lint_command: Optional[str] = None,
        report_filename: Optional[str] = None,
        ignore_failure: bool = False,
        working_directory: Optional[str | Path] = None,
    ):
        """
        Initializes the LintStage with specific configuration.

        This constructor sets up the linting stage. All parameters are optional
        and will fall back to sensible defaults if not provided.

        Args:
            lint_command (Optional[str]): The full linter command to execute.
                For example, 'pylint src/'. If None, defaults to
                `LintStage.DEFAULT_LINT_COMMAND`. It will be safely split
                for execution.
            report_filename (Optional[str]): The base name of the file where
                the linter's output will be stored. If None, defaults to
                `LintStage.DEFAULT_REPORT_FILENAME`. This file will be placed
                in the workspace's artifacts directory.
            ignore_failure (bool): If set to True, the pipeline will continue
                with a 'success' status from this stage even if the linter
                reports errors (non-zero exit code). This is useful for
                informational-only linting. Defaults to False.
            working_directory (Optional[str | Path]): A relative path within
                the project directory where the linter command should be
                executed. If None, the project's root directory is used.
        """
        super().__init__()
        self.lint_command = shlex.split(lint_command or self.DEFAULT_LINT_COMMAND)
        self.report_filename = report_filename or self.DEFAULT_REPORT_FILENAME
        self.ignore_failure = ignore_failure
        self.working_directory = Path(working_directory) if working_directory else None

        if not self.lint_command:
            raise ValueError("Lint command cannot be empty.")

        logger.debug(
            f"LintStage initialized with command: '{' '.join(self.lint_command)}', "
            f"report: '{self.report_filename}', ignore_failure: {self.ignore_failure}"
        )

    @property
    def name(self) -> str:
        """
        Provides the unique, human-readable name of this pipeline stage.

        Returns:
            str: The name of the stage, "LintStage".
        """
        return "LintStage"

    def run(self, workspace: Workspace) -> PipelineState:
        """
        Executes the configured linter command on the code within the workspace.

        This is the main entry point for the stage's execution. It performs
        the following steps:
        1. Verifies the existence of the project directory in the workspace.
        2. Determines the correct execution directory.
        3. Executes the linter command as a subprocess.
        4. Captures stdout, stderr, and the exit code.
        5. Formats and saves a detailed report to the workspace artifacts.
        6. Returns a `PipelineState` object indicating success or failure.

        Args:
            workspace (Workspace): The workspace context, providing access to
                the project's files and a location for artifacts.

        Returns:
            PipelineState: An object describing the outcome of the stage. It
                will be a 'failure' state if the linter command fails (and
                `ignore_failure` is False) or if a critical error occurs.
                Otherwise, it will be a 'success' state.
        """
        logger.info(f"--- Starting {self.name} ---")

        project_path = workspace.get_project_path()
        if not project_path or not project_path.is_dir():
            error_msg = f"Project path '{project_path}' is invalid or not a directory."
            logger.error(error_msg)
            return PipelineState.failure(self, error_msg)

        exec_path = self._get_execution_path(project_path)
        if not exec_path.is_dir():
            error_msg = f"Execution path '{exec_path}' does not exist or is not a directory."
            logger.error(error_msg)
            return PipelineState.failure(self, error_msg)

        logger.info(f"Running linter in: '{exec_path}'")
        logger.info(f"Command: '{' '.join(self.lint_command)}'")

        try:
            exit_code, stdout, stderr = self._execute_lint_command(exec_path)
            logger.info(f"Linter process finished with exit code: {exit_code}")
        except Exception as e:
            error_msg = f"An unexpected error occurred while executing the linter: {e}"
            logger.critical(error_msg, exc_info=True)
            return PipelineState.failure(self, error_msg)

        report_content = self._format_report(
            command=self.lint_command,
            exit_code=exit_code,
            stdout=stdout,
            stderr=stderr
        )
        report_path = self._save_report(workspace, report_content)
        artifacts = {"lint_report": str(report_path)}

        if exit_code == 0:
            message = "Linting completed successfully. No issues found."
            logger.info(message)
            return PipelineState.success(self, message, artifacts=artifacts)
        else:
            message = f"Linter found issues (exit code: {exit_code})."
            logger.warning(message)
            if self.ignore_failure:
                success_message = f"{message} Failure is ignored by configuration."
                logger.info("Stage result is SUCCESS due to 'ignore_failure=True'.")
                return PipelineState.success(self, success_message, artifacts=artifacts)
            else:
                failure_message = f"{message} See the report for details."
                logger.error("Stage result is FAILURE.")
                return PipelineState.failure(self, failure_message, artifacts=artifacts)

    def _get_execution_path(self, project_root: Path) -> Path:
        """
        Determines the absolute path where the linter command should be run.

        Args:
            project_root (Path): The root directory of the checked-out project.

        Returns:
            Path: The absolute path for command execution.
        """
        if self.working_directory:
            return (project_root / self.working_directory).resolve()
        return project_root.resolve()

    def _execute_lint_command(self, cwd: Path) -> Tuple[int, str, str]:
        """
        Executes the linter command in a subprocess.

        Handles the low-level details of running the command, capturing its
        output, and ensuring it completes.

        Args:
            cwd (Path): The directory from which to run the command.

        Returns:
            Tuple[int, str, str]: A tuple containing the exit code,
                the standard output, and the standard error as strings.

        Raises:
            FileNotFoundError: If the command executable is not found.
            subprocess.TimeoutExpired: If the command takes too long to run.
            Exception: For other subprocess-related errors.
        """
        try:
            process = subprocess.run(
                self.lint_command,
                cwd=cwd,
                capture_output=True,
                text=True,
                encoding='utf-8',
                check=False,  # We handle the non-zero exit code manually
            )
            stdout = process.stdout
            stderr = process.stderr
            return process.returncode, stdout, stderr
        except FileNotFoundError:
            error_msg = f"Command not found: '{self.lint_command[0]}'. Is it installed and in PATH?"
            logger.error(error_msg)
            raise
        except Exception as e:
            logger.error(f"Subprocess execution failed: {e}", exc_info=True)
            raise

    def _format_report(
        self, command: List[str], exit_code: int, stdout: str, stderr: str
    ) -> str:
        """
        Creates a well-formatted string containing the full linter report.

        Args:
            command (List[str]): The command that was executed.
            exit_code (int): The process's final exit code.
            stdout (str): The captured standard output.
            stderr (str): The captured standard error.

        Returns:
            str: A formatted, multi-line string with the complete report.
        """
        header = " LINTING STAGE REPORT "
        report_parts = [
            f"{'=' * 20}{header}{'=' * 20}",
            f"Executed Command: {' '.join(command)}",
            f"Exit Code: {exit_code}",
            f"Status: {'Success' if exit_code == 0 else 'Issues Found'}",
            "\n" + ("-" * (42 + len(header))),
            "\n--- STANDARD OUTPUT (stdout) ---\n",
            stdout.strip() if stdout.strip() else "[No standard output]",
            "\n\n--- STANDARD ERROR (stderr) ---\n",
            stderr.strip() if stderr.strip() else "[No standard error]",
            "\n\n" + "=" * (42 + len(header)),
        ]
        return "\n".join(report_parts)

    def _save_report(self, workspace: Workspace, content: str) -> Path:
        """
        Saves the provided report content to a file in the workspace artifacts.

        This method ensures the artifacts directory exists and writes the
        report. It handles potential file I/O errors gracefully.

        Args:
            workspace (Workspace): The current workspace.
            content (str): The string content of the report to save.

        Returns:
            Path: The absolute path to the newly created report file.
        """
        try:
            artifacts_dir = workspace.get_artifacts_path()
            artifacts_dir.mkdir(parents=True, exist_ok=True)
            report_path = artifacts_dir / self.report_filename

            with report_path.open("w", encoding="utf-8") as f:
                f.write(content)

            logger.info(f"Lint report successfully saved to: {report_path}")
            return report_path
        except IOError as e:
            logger.error(f"Fatal: Could not write lint report to workspace: {e}", exc_info=True)
            raise RuntimeError(f"Failed to save lint report") from e
