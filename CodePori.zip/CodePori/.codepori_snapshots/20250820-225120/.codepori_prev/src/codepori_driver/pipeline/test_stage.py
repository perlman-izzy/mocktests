import json
import logging
import os
import subprocess
from pathlib import Path
from typing import Any, Dict, List, Optional

from src.codepori_driver.pipeline.base_stage import BaseStage
from src.codepori_driver.workspace.workspace import Workspace

# Configure a logger for this module.
logger = logging.getLogger(__name__)

# Default configuration keys and values for the TestStage.
CONFIG_KEY_TEST_COMMAND = "test_command"
CONFIG_KEY_TEST_DIRECTORY = "test_directory"
CONFIG_KEY_JSON_REPORT_NAME = "json_report_name"
CONFIG_KEY_SUMMARY_REPORT_NAME = "summary_report_name"

DEFAULT_TEST_COMMAND = "pytest"
DEFAULT_TEST_DIRECTORY = "."
DEFAULT_JSON_REPORT_NAME = ".test_results.json"
DEFAULT_SUMMARY_REPORT_NAME = "test_summary.md"


class TestStage(BaseStage):
    """A pipeline stage for running tests within the workspace.

    This stage executes a configured test command (e.g., pytest) within the
    project's workspace. It is designed to capture structured test results
    from a JSON report, generate a human-readable summary, and save both
    artifacts back into the workspace for subsequent stages or review.

    Attributes:
        _test_command (str): The base command for the test runner (e.g., 'pytest').
        _test_directory (str): The target directory within the workspace to run tests against.
        _json_report_name (str): The filename for the machine-readable JSON test report.
        _summary_report_name (str): The filename for the human-readable Markdown summary.
    """

    def __init__(self, config: Dict[str, Any], workspace: Workspace):
        """Initializes the TestStage with configuration and a workspace.

        Args:
            config (Dict[str, Any]): A dictionary containing the configuration
                for this stage. Expected keys include 'test_command',
                'test_directory', 'json_report_name', and 'summary_report_name'.
            workspace (Workspace): An object providing access to the file system
                and state of the current project generation task.
        """
        super().__init__(config, workspace)
        self._test_command = self.config.get(CONFIG_KEY_TEST_COMMAND, DEFAULT_TEST_COMMAND)
        self._test_directory = self.config.get(CONFIG_KEY_TEST_DIRECTORY, DEFAULT_TEST_DIRECTORY)
        self._json_report_name = self.config.get(
            CONFIG_KEY_JSON_REPORT_NAME, DEFAULT_JSON_REPORT_NAME
        )
        self._summary_report_name = self.config.get(
            CONFIG_KEY_SUMMARY_REPORT_NAME, DEFAULT_SUMMARY_REPORT_NAME
        )
        logger.info("TestStage initialized.")

    def run(self) -> None:
        """Executes the test stage.

        This method orchestrates the process of running tests, parsing the
        results, and updating the workspace with the outcome.
        """
        logger.info("Starting TestStage execution...")
        try:
            process_result = self._execute_tests()
            report_path = self.workspace.get_path(self._json_report_name)

            test_report = self._parse_json_test_report(report_path)

            if not test_report:
                logger.warning(
                    "Could not parse JSON report. Creating a fallback report from stdout/stderr."
                )
                test_report = self._create_fallback_report(process_result)

            self._update_workspace(test_report)

        except Exception as e:
            logger.exception("An unexpected error occurred during the TestStage execution: %s", e)
            # Create a failure report even if the stage crashes unexpectedly
            error_report = {
                "summary": {"outcome": "error", "total": 0},
                "details": f"TestStage failed with an exception: {e}",
                "raw_output": str(e),
            }
            self._update_workspace(error_report)

        logger.info("TestStage execution finished.")

    def _build_test_command(self) -> List[str]:
        """Constructs the full test command with arguments.

        Returns:
            List[str]: A list of command-line arguments to be executed.
        """
        command = [
            self._test_command,
            self._test_directory,
            "--json-report",
            f"--json-report-file={self._json_report_name}",
            "-v",  # Verbose output is useful for logs
        ]
        return command

    def _execute_tests(self) -> subprocess.CompletedProcess:
        """Executes the configured test command in a subprocess.

        The command is run from the root of the workspace. It captures stdout,
        stderr, and the return code for later analysis.

        Returns:
            subprocess.CompletedProcess: The result of the executed subprocess.

        Raises:
            RuntimeError: If the test runner command (e.g., pytest) cannot be found.
        """
        command = self._build_test_command()
        workspace_root = self.workspace.get_path()

        logger.info(f"Executing test command: {' '.join(command)} in {workspace_root}")

        try:
            result = subprocess.run(
                command,
                cwd=workspace_root,
                capture_output=True,
                text=True,
                check=False,  # We handle the return code manually
            )
            logger.info(f"Test command finished with return code: {result.returncode}")
            if result.stdout:
                logger.debug("Test command stdout:\n%s", result.stdout)
            if result.stderr:
                logger.warning("Test command stderr:\n%s", result.stderr)
            return result
        except FileNotFoundError:
            logger.error(
                f"Test command '{self._test_command}' not found. "
                f"Please ensure the test runner is installed and in the system's PATH."
            )
            raise RuntimeError(f"Test runner '{self._test_command}' not found.")

    def _parse_json_test_report(self, report_path: Path) -> Optional[Dict[str, Any]]:
        """Parses the JSON report file generated by the test runner.

        Args:
            report_path (Path): The path to the JSON report file.

        Returns:
            Optional[Dict[str, Any]]: A dictionary containing the parsed test
            results, or None if the report cannot be found or parsed.
        """
        if not report_path.is_file():
            logger.warning(f"JSON test report not found at: {report_path}")
            return None

        try:
            with open(report_path, "r", encoding="utf-8") as f:
                report_data = json.load(f)

            # Basic validation of report structure
            if "summary" not in report_data or "tests" not in report_data:
                logger.error("JSON report has an invalid structure.")
                return None

            logger.info("Successfully parsed JSON test report.")
            return report_data
        except json.JSONDecodeError:
            logger.exception(f"Failed to decode JSON from report file: {report_path}")
            return None
        except IOError as e:
            logger.exception(f"Failed to read report file {report_path}: {e}")
            return None

    def _create_fallback_report(self, result: subprocess.CompletedProcess) -> Dict[str, Any]:
        """Creates a basic report when the JSON report is unavailable.

        This is used when the test runner fails to generate a report, for instance,
        due to a syntax error in a test file or a missing dependency.

        Args:
            result (subprocess.CompletedProcess): The result from the subprocess call.

        Returns:
            Dict[str, Any]: A dictionary representing a basic failure report.
        """
        outcome = "passed" if result.returncode == 0 else "error"
        return {
            "summary": {
                "outcome": outcome,
                "total": "unknown",
                "passed": "unknown",
                "failed": "unknown",
            },
            "tests": [],
            "raw_output": {
                "stdout": result.stdout,
                "stderr": result.stderr,
                "returncode": result.returncode,
            },
        }

    def _format_markdown_summary(self, report: Dict[str, Any]) -> str:
        """Formats the test report into a human-readable Markdown summary.

        Args:
            report (Dict[str, Any]): The structured test report dictionary.

        Returns:
            str: A Markdown-formatted string summarizing the test results.
        """
        summary = report.get("summary", {})
        outcome = summary.get("outcome", "UNKNOWN").upper()
        lines = [f"# Test Execution Report\n\n**Overall Outcome:** `{outcome}`\n"]

        lines.append("## Summary\n")
        lines.append("| Metric | Count |")
        lines.append("|--------|-------|")
        for key, value in summary.items():
            if key != "outcome":
                lines.append(f"| {key.capitalize()} | {value} |")
        lines.append("\n")

        failed_tests = [
            test for test in report.get("tests", []) if test.get("outcome") == "failed"
        ]

        if failed_tests:
            lines.append("## Failed Tests\n")
            for test in failed_tests:
                nodeid = test.get("nodeid", "Unknown Test")
                lines.append(f"### ❌ `{nodeid}`\n")
                longrepr = test.get("longrepr", "No failure details available.")
                lines.append(f"```\n{longrepr}\n```\n")

        if "raw_output" in report:
            lines.append("## Raw Command Output\n")
            raw_output = report["raw_output"]
            if raw_output.get("stderr"):
                lines.append("### Stderr\n")
                lines.append(f"```\n{raw_output['stderr']}\n```\n")
            if raw_output.get("stdout"):
                lines.append("### Stdout\n")
                lines.append(f"```\n{raw_output['stdout']}\n```\n")

        return "\n".join(lines)

    def _update_workspace(self, test_report: Dict[str, Any]) -> None:
        """Writes the test results back to the workspace.

        Saves both a machine-readable JSON file and a human-readable Markdown file.

        Args:
            test_report (Dict[str, Any]): The structured test report.
        """
        # Write the structured JSON report
        try:
            json_report_str = json.dumps(test_report, indent=2)
            self.workspace.write_file(self._json_report_name, json_report_str)
            logger.info(f"Wrote structured test report to {self._json_report_name}")
        except TypeError as e:
            logger.error(f"Failed to serialize test report to JSON: {e}")

        # Write the human-readable Markdown summary
        markdown_summary = self._format_markdown_summary(test_report)
        self.workspace.write_file(self._summary_report_name, markdown_summary)
        logger.info(f"Wrote human-readable test summary to {self._summary_report_name}")
