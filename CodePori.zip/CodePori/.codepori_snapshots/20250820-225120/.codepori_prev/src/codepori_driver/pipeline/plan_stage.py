import logging
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional
import json

# Note: The following classes are defined here to make this module self-contained
# for review, as per the context of the task. In a real project, these would
# be in separate files like 'src.codepori_driver.llm.client'.

class LLMClient:
    """A client to interact with a Large Language Model."""

    def generate(self, prompt: str, **kwargs) -> str:
        """
        Generates a response from the LLM based on the given prompt.

        Args:
            prompt: The input prompt for the LLM.
            **kwargs: Additional parameters for the LLM call (e.g., temperature).

        Returns:
            The raw string response from the LLM.
        """
        raise NotImplementedError("LLMClient.generate must be implemented by a subclass.")

class Workspace:
    """
    A class to manage the state of the code generation process.
    It acts as a central repository for artifacts like prompts, plans, and code.
    """

    def __init__(self, data: Optional[Dict[str, Any]] = None):
        """Initializes the Workspace.

        Args:
            data: Optional initial data for the workspace.
        """
        self._data: Dict[str, Any] = data or {}

    def get_initial_prompt(self) -> Optional[str]:
        """Retrieves the initial user prompt from the workspace."""
        return self._data.get("initial_prompt")

    def set_plan(self, plan: Dict[str, Any]) -> None:
        """Stores the generated technical plan in the workspace."""
        self._data["plan"] = plan

    def get_plan(self) -> Optional[Dict[str, Any]]:
        """Retrieves the technical plan from the workspace."""
        return self._data.get("plan")


class PipelineStage(ABC):
    """Abstract base class for a stage in the code generation pipeline."""

    @abstractmethod
    def run(self, workspace: Workspace) -> Workspace:
        """
        Executes the logic for this pipeline stage.

        Args:
            workspace: The current state of the project.

        Returns:
            The updated workspace after the stage has run.
        """
        pass


# --- Custom Exceptions for PlanStage ---

class PlanStageError(Exception):
    """Base exception for errors occurring in the PlanStage."""
    pass


class MissingPromptError(PlanStageError):
    """Raised when the initial prompt is not found in the workspace."""
    pass


class PlanGenerationError(PlanStageError):
    """Raised when the LLM fails to generate a valid plan."""
    pass


class PlanParsingError(PlanStageError):
    """Raised when the LLM response for the plan cannot be parsed."""
    pass


# --- Prompt Template ---

PLANNING_PROMPT_TEMPLATE = """
You are a senior software architect responsible for creating a detailed technical plan for a software development task.
Based on the user's request, create a comprehensive plan that a team of developers can follow to implement the feature.

**User Request:**
---
{initial_prompt}
---

**Your Task:**
Generate a technical plan with the following components:

1.  **`project_summary`**: A brief, one-paragraph summary of the project's goal.
2.  **`tech_stack_recommendation`**: A list of recommended technologies (languages, frameworks, libraries) and a brief justification for each choice.
3.  **`file_breakdown`**: A list of all the files that need to be created or modified. For each file, provide:
    *   `path`: The full path to the file from the project root (e.g., `src/main.py`).
    *   `description`: A clear, one-sentence description of the file's purpose.
4.  **`implementation_steps`**: A detailed, step-by-step sequence of actions to implement the project. Each step should be a clear, actionable instruction for a developer.
5.  **`dependency_graph`**: A dictionary representing the dependencies between implementation steps. The keys should be step numbers (as strings, e.g., "1", "2"), and the values should be a list of step numbers that must be completed before this step can start. An empty list `[]` means the step has no dependencies.

**Output Format:**
Your entire response MUST be a single, valid JSON object. Do not include any explanatory text, markdown formatting, or code fences around the JSON.

**Example JSON Structure:**
{{
  "project_summary": "A brief summary of the project.",
  "tech_stack_recommendation": [
    {{"name": "Python 3.10+", "justification": "Modern features and widespread adoption."}},
    {{"name": "FastAPI", "justification": "For building high-performance APIs."}}
  ],
  "file_breakdown": [
    {{"path": "src/api/main.py", "description": "The main entry point for the FastAPI application."}},
    {{"path": "src/core/config.py", "description": "Handles application configuration and settings."}}
  ],
  "implementation_steps": [
    "Step 1: Set up the project structure with directories `src/api` and `src/core`.",
    "Step 2: Initialize the FastAPI application in `src/api/main.py`.",
    "Step 3: Implement the configuration loading logic in `src/core/config.py`."
  ],
  "dependency_graph": {{
    "1": [],
    "2": ["1"],
    "3": ["1"]
  }}
}}
"""

# --- PlanStage Implementation ---

class PlanStage(PipelineStage):
    """
    A pipeline stage for generating a detailed technical plan.

    This stage takes the initial user prompt from the workspace, uses an LLM
    to generate a structured technical plan, and stores this plan back into
    the workspace for subsequent stages.

    Attributes:
        llm_client: An instance of an LLMClient to communicate with the LLM.
        config: A dictionary containing configuration for the stage, such as
                LLM model parameters.
    """

    def __init__(self, llm_client: LLMClient, config: Optional[Dict[str, Any]] = None):
        """
        Initializes the PlanStage.

        Args:
            llm_client: The client for interacting with the language model.
            config: Optional configuration for the stage.

        Raises:
            TypeError: If llm_client is not an instance of LLMClient.
        """
        if not isinstance(llm_client, LLMClient):
            raise TypeError("llm_client must be an instance of LLMClient.")
        self.llm_client = llm_client
        self.config = config or {}
        logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        self.logger = logging.getLogger(self.__class__.__name__)

    def run(self, workspace: Workspace) -> Workspace:
        """
        Executes the planning stage.

        This method orchestrates the process of fetching the initial prompt,
        generating a technical plan via the LLM, validating the plan, and
        updating the workspace.

        Args:
            workspace: The current project workspace.

        Returns:
            The workspace updated with the technical plan.

        Raises:
            MissingPromptError: If the initial prompt is not in the workspace.
            PlanGenerationError: If the LLM fails to generate a response.
            PlanParsingError: If the LLM response is not valid JSON.
            PlanStageError: For other validation or stage-related errors.
        """
        self.logger.info("Starting plan generation stage...")

        initial_prompt = self._get_initial_prompt(workspace)
        planning_prompt = self._construct_planning_prompt(initial_prompt)

        try:
            self.logger.info("Sending planning request to LLM...")
            raw_llm_response = self.llm_client.generate(
                prompt=planning_prompt,
                **self.config.get("llm_params", {})
            )
            self.logger.info("Received response from LLM.")
        except Exception as e:
            self.logger.error(f"LLM generation failed: {e}", exc_info=True)
            raise PlanGenerationError(f"Failed to generate plan from LLM: {e}") from e

        plan = self._parse_llm_response(raw_llm_response)
        self._validate_plan(plan)

        workspace.set_plan(plan)
        self.logger.info("Successfully generated and stored the technical plan.")

        return workspace

    def _get_initial_prompt(self, workspace: Workspace) -> str:
        """
        Retrieves the initial prompt from the workspace.

        Args:
            workspace: The project workspace.

        Returns:
            The initial user prompt as a string.

        Raises:
            MissingPromptError: If the prompt is not found or is empty.
        """
        self.logger.debug("Attempting to retrieve initial prompt from workspace.")
        prompt = workspace.get_initial_prompt()
        if not prompt or not prompt.strip():
            self.logger.error("Initial prompt not found or is empty in the workspace.")
            raise MissingPromptError("The workspace does not contain a valid initial prompt.")
        self.logger.debug("Successfully retrieved initial prompt.")
        return prompt

    def _construct_planning_prompt(self, initial_prompt: str) -> str:
        """
        Constructs the full prompt to be sent to the LLM for planning.

        Args:
            initial_prompt: The initial user prompt.

        Returns:
            The formatted prompt string.
        """
        return PLANNING_PROMPT_TEMPLATE.format(initial_prompt=initial_prompt)

    def _parse_llm_response(self, response: str) -> Dict[str, Any]:
        """
        Parses the raw string response from the LLM into a dictionary.

        This implementation assumes the response is a JSON string. It will
        attempt to clean up common LLM artifacts like markdown code fences.

        Args:
            response: The raw string response from the LLM.

        Returns:
            The parsed plan as a dictionary.

        Raises:
            PlanParsingError: If the response cannot be parsed as JSON.
        """
        self.logger.debug("Parsing LLM response.")
        cleaned_response = response.strip()

        if cleaned_response.startswith("```json"):
            cleaned_response = cleaned_response.lstrip("```json").rstrip("```")
        elif cleaned_response.startswith("```"):
            cleaned_response = cleaned_response.lstrip("```").rstrip("```")

        cleaned_response = cleaned_response.strip()

        try:
            plan = json.loads(cleaned_response)
            if not isinstance(plan, dict):
                raise PlanParsingError("Parsed plan is not a JSON object (dictionary).")
            self.logger.debug("LLM response parsed successfully.")
            return plan
        except json.JSONDecodeError as e:
            self.logger.error(f"Failed to parse LLM response as JSON: {e}")
            self.logger.debug(f"Raw response was:\n---\n{response}\n---")
            raise PlanParsingError(f"LLM response is not valid JSON: {e}") from e

    def _validate_plan(self, plan: Dict[str, Any]) -> None:
        """
        Validates the structure and content of the generated plan.

        Args:
            plan: The parsed plan dictionary.

        Raises:
            PlanStageError: If the plan is invalid.
        """
        self.logger.debug("Validating the structure of the generated plan.")
        required_keys = [
            "project_summary",
            "tech_stack_recommendation",
            "file_breakdown",
            "implementation_steps",
            "dependency_graph"
        ]

        for key in required_keys:
            if key not in plan:
                raise PlanStageError(f"Generated plan is missing required key: '{key}'")

        if not isinstance(plan["project_summary"], str) or not plan["project_summary"]:
            raise PlanStageError("Plan 'project_summary' must be a non-empty string.")

        if not isinstance(plan["implementation_steps"], list) or not plan["implementation_steps"]:
            raise PlanStageError("Plan 'implementation_steps' must be a non-empty list.")

        if not all(isinstance(step, str) for step in plan["implementation_steps"]):
            raise PlanStageError("All items in 'implementation_steps' must be strings.")

        self.logger.info("Plan structure validation passed.")
