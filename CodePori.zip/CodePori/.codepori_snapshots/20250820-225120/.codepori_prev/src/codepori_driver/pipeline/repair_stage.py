import logging
from typing import Dict, Any, Optional

from src.codepori_driver.llm_client.llm_client import LLMClient
from src.codepori_driver.workspace.workspace_provider import WorkspaceProvider
from src.codepori_driver.pipeline.stage import Stage
from src.codepori_driver.logging.logger import Logger
from src.codepori_driver.errors import RepairStageError

# Constants for payload keys to avoid magic strings
PAYLOAD_FILE_PATH = "file_path"
PAYLOAD_LINT_REPORT = "lint_report"
PAYLOAD_TEST_REPORT = "test_report"
PAYLOAD_REPAIR_ATTEMPTED = "repair_attempted"
PAYLOAD_REPAIR_SUCCESSFUL = "repair_successful"


REPAIR_PROMPT_TEMPLATE = """
You are an expert senior Python developer tasked with fixing code that has failed linting or unit tests.
Your goal is to analyze the provided code and the error reports, identify the root cause of the issues, and provide a corrected version of the entire file.

**IMPORTANT INSTRUCTIONS:**
1.  You MUST return the complete, corrected code for the entire file.
2.  Do not add any explanations, comments, or apologies before or after the code.
3.  The corrected code should be enclosed in a single Python markdown block. For example:
    ```python
    # your corrected code here
    ```
4.  Ensure your fix addresses all the issues mentioned in the error reports.
5.  Maintain the original coding style and structure as much as possible, unless the style itself is the source of a linting error.
6.  Do not introduce new functionality. Only fix the existing issues.

**FILE TO REPAIR:**
```python
{file_content}
```

**ERROR REPORTS:**

{error_reports}

Now, provide the corrected version of the file.
"""

class RepairStage(Stage):
    """A pipeline stage for automatically repairing code using an LLM.

    This stage takes the path to a file, along with linting and/or testing
    error reports, constructs a prompt for a Large Language Model (LLM),
    and uses the LLM's response to overwrite the original file with a
    corrected version.

    Attributes:
        llm_client (LLMClient): The client for interacting with the LLM.
        workspace_provider (WorkspaceProvider): The provider for file system operations.
        logger (Logger): The application's logger instance.
    """

    def __init__(
        self,
        llm_client: LLMClient,
        workspace_provider: WorkspaceProvider,
        logger: Logger,
    ):
        """Initializes the RepairStage.

        Args:
            llm_client (LLMClient): An instance of the LLM client.
            workspace_provider (WorkspaceProvider): An instance of the workspace provider.
            logger (Logger): An instance of the logger.
        """
        super().__init__()
        if not isinstance(llm_client, LLMClient):
            raise TypeError("llm_client must be an instance of LLMClient")
        if not isinstance(workspace_provider, WorkspaceProvider):
            raise TypeError("workspace_provider must be an instance of WorkspaceProvider")
        if not isinstance(logger, Logger):
            raise TypeError("logger must be an instance of Logger")

        self._llm_client = llm_client
        self._workspace_provider = workspace_provider
        self._logger = logger
        self._logger.log(logging.INFO, f"RepairStage initialized.")

    def execute(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Executes the code repair process.

        This method reads the file content and error reports from the payload,
        generates a repair suggestion using the LLM, and applies the fix
        to the file in the workspace.

        Args:
            payload (Dict[str, Any]): A dictionary containing the necessary data
                for the stage. Expected keys are 'file_path', 'lint_report',
                and 'test_report'.

        Returns:
            Dict[str, Any]: The updated payload, with 'repair_attempted' and
                'repair_successful' flags set.

        Raises:
            RepairStageError: If a critical error occurs during the repair
                process, such as failing to read the file, the LLM failing,
                or the LLM response being invalid.
        """
        self._logger.log(logging.INFO, "Executing RepairStage...")
        payload[PAYLOAD_REPAIR_ATTEMPTED] = True
        payload[PAYLOAD_REPAIR_SUCCESSFUL] = False

        try:
            file_path = self._get_required_payload_value(payload, PAYLOAD_FILE_PATH)
            lint_report = payload.get(PAYLOAD_LINT_REPORT)
            test_report = payload.get(PAYLOAD_TEST_REPORT)
            self._logger.log(logging.INFO, f"Attempting to repair file: {file_path}")

            if not lint_report and not test_report:
                self._logger.log(logging.WARNING,
                                 "RepairStage skipped: No lint or test reports provided.")
                # We consider this a "successful" non-operation
                payload[PAYLOAD_REPAIR_SUCCESSFUL] = True
                return payload

            file_content = self._workspace_provider.read_file(file_path)
            prompt = self._construct_prompt(file_content, lint_report, test_report)

            self._logger.log(logging.DEBUG, f"Generated repair prompt for {file_path}")
            llm_response = self._llm_client.generate_code(prompt)

            repaired_code = self._extract_code_from_response(llm_response)
            self._workspace_provider.write_file(file_path, repaired_code)

            self._logger.log(logging.INFO, f"Successfully applied repair to {file_path}")
            payload[PAYLOAD_REPAIR_SUCCESSFUL] = True

        except (KeyError, FileNotFoundError, ValueError, IOError) as e:
            error_message = f"Error during repair stage execution for {payload.get(PAYLOAD_FILE_PATH, 'unknown file')}: {e}"
            self._logger.log(logging.ERROR, error_message)
            raise RepairStageError(error_message) from e
        except Exception as e:
            error_message = f"An unexpected error occurred in RepairStage for {payload.get(PAYLOAD_FILE_PATH, 'unknown file')}: {e}"
            self._logger.log(logging.ERROR, error_message)
            raise RepairStageError(error_message) from e

        return payload

    def _get_required_payload_value(self, payload: Dict[str, Any], key: str) -> Any:
        """Retrieves a required value from the payload dictionary.

        Args:
            payload (Dict[str, Any]): The dictionary to retrieve from.
            key (str): The key of the value to retrieve.

        Returns:
            Any: The value associated with the key.

        Raises:
            KeyError: If the key is not found in the payload.
        """
        if key not in payload:
            raise KeyError(f"Missing required key '{key}' in RepairStage payload.")
        return payload[key]

    def _construct_prompt(
        self,
        file_content: str,
        lint_report: Optional[str],
        test_report: Optional[str]
    ) -> str:
        """Constructs the full prompt for the LLM based on available reports.

        Args:
            file_content (str): The content of the file to be repaired.
            lint_report (Optional[str]): The report from the linting stage.
            test_report (Optional[str]): The report from the testing stage.

        Returns:
            str: The fully formatted prompt string.
        """
        self._logger.log(logging.INFO, "Constructing LLM prompt for code repair.")
        error_reports_parts = []
        if lint_report and lint_report.strip():
            error_reports_parts.append(f"**LINTING ERRORS:**\n```\n{lint_report}\n```")

        if test_report and test_report.strip():
            error_reports_parts.append(f"**TESTING FAILURES:**\n```\n{test_report}\n```")

        if not error_reports_parts:
            # This case is handled in execute, but as a safeguard:
            raise ValueError("Cannot construct repair prompt without any error reports.")

        error_reports = "\n\n".join(error_reports_parts)

        return REPAIR_PROMPT_TEMPLATE.format(
            file_content=file_content,
            error_reports=error_reports
        )

    def _extract_code_from_response(self, response: str) -> str:
        """Extracts the Python code block from the LLM's markdown response.

        The method looks for a code block fenced by ```python and ```.
        If not found, it tries to find a generic code block (```).

        Args:
            response (str): The raw string response from the LLM.

        Returns:
            str: The extracted code content.

        Raises:
            ValueError: If a valid Python code block cannot be found in the response.
        """
        self._logger.log(logging.DEBUG, "Extracting code from LLM response.")
        response = response.strip()

        # Primary search for ```python ... ```
        python_block_start = response.find("```python")
        if python_block_start != -1:
            start_index = python_block_start + len("```python\n")
            end_index = response.find("```", start_index)
            if end_index != -1:
                extracted_code = response[start_index:end_index].strip()
                self._logger.log(logging.INFO, "Successfully extracted python code block.")
                return extracted_code

        # Fallback search for ``` ... ```
        generic_block_start = response.find("```")
        if generic_block_start != -1:
            start_index = generic_block_start + len("```\n")
            end_index = response.find("```", start_index)
            if end_index != -1:
                extracted_code = response[start_index:end_index].strip()
                self._logger.log(logging.WARNING, "Found a generic code block, assuming it's Python.")
                return extracted_code

        # If no blocks are found, maybe the LLM returned raw code.
        # This is less reliable, but a possible last resort.
        if response.startswith(('import ', 'from ', 'def ', 'class ', '#')):
            self._logger.log(logging.WARNING, "No markdown block found. Assuming entire response is code.")
            return response

        error_msg = "Could not extract a valid code block from the LLM response."
        self._logger.log(logging.ERROR, f"{error_msg} Response was: {response[:500]}...")
        raise ValueError(error_msg)
