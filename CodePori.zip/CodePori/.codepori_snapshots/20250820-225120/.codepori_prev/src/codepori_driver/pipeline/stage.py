import abc
import logging
import time
from typing import Any, Dict, final, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    # Use a forward reference for the Workspace class to avoid circular dependencies.
    # The actual Workspace class will be defined in its own module.
    from src.codepori_driver.workspace.workspace import Workspace


class PipelineStageError(Exception):
    """Base exception for all errors related to pipeline stages.

    This custom exception serves as the parent for more specific exceptions
    within the pipeline stage execution, allowing for consolidated error handling.
    Catching this exception will catch any error originating from the pipeline
    stage logic.
    """
    pass


class StageConfigurationError(PipelineStageError):
    """Raised when a pipeline stage is configured incorrectly.

    This error indicates that the configuration dictionary provided to a stage
    during its initialization is missing required keys, contains values of the
    wrong type, or has other validation issues.

    Attributes:
        stage_name (str): The name of the stage where the configuration error occurred.
        message (str): A detailed message describing the configuration issue.
    """
    def __init__(self, stage_name: str, message: str):
        """Initializes the StageConfigurationError.

        Args:
            stage_name (str): The name of the stage with the invalid configuration.
            message (str): The specific error message.
        """
        self.stage_name = stage_name
        self.message = message
        super().__init__(f"Configuration error in stage '{stage_name}': {message}")


class StageExecutionError(PipelineStageError):
    """Raised when a pipeline stage fails during its execution.

    This exception wraps any unexpected error that occurs within the `_perform_stage_action`
    method of a pipeline stage. It captures the context of the failure, including
    the stage name and the original exception, to facilitate debugging.

    Attributes:
        stage_name (str): The name of the stage that failed.
        message (str): A high-level message about the failure.
        original_exception (Optional[Exception]): The underlying exception that caused the failure.
    """
    def __init__(self, stage_name: str, message: str, original_exception: Optional[Exception] = None):
        """Initializes the StageExecutionError.

        Args:
            stage_name (str): The name of the stage where the error occurred.
            message (str): A summary of the execution failure.
            original_exception (Optional[Exception]): The original exception that was caught.
        """
        self.stage_name = stage_name
        self.message = message
        self.original_exception = original_exception
        full_message = f"Execution failed in stage '{stage_name}': {message}"
        if original_exception:
            full_message += f" | Original error: {original_exception!r}"
        super().__init__(full_message)


class PipelineStage(abc.ABC):
    """Abstract Base Class for a single stage in the processing pipeline.

    This class defines the common interface and execution logic for all pipeline
    stages. Each concrete stage must inherit from this class and implement the
    `name` property and the `_perform_stage_action` method.

    The pipeline orchestrator's responsibility is to instantiate and call the
    `execute` method on each stage in the correct sequence. The `execute` method
    itself employs the Template Method design pattern. It provides a consistent
    execution wrapper that handles crucial cross-cutting concerns such as
    logging, timing, and robust error handling, while delegating the specific
    stage logic to the `_perform_stage_action` method.

    This design ensures that all stages behave uniformly in terms of their
    lifecycle and reporting, promoting consistency and reducing boilerplate
    code in concrete stage implementations.

    Attributes:
        config (Dict[str, Any]): A dictionary containing the configuration
            for this specific stage, passed during initialization.
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """Initializes the PipelineStage.

        This constructor sets up the stage with its configuration and a dedicated
        logger instance. It also calls a validation hook for subclasses.

        Args:
            config (Optional[Dict[str, Any]]): A dictionary containing configuration
                parameters for the stage. If None, an empty dictionary is used.
        """
        self.config = config if config is not None else {}
        # The logger name is structured to include the module and class name
        # for better traceability in logs.
        self._logger = logging.getLogger(f"{self.__class__.__module__}.{self.__class__.__name__}")
        self._logger.debug("Initializing stage with config: %s", self.config)
        try:
            self._validate_config()
        except StageConfigurationError:
            # Re-raise configuration errors to halt execution early if setup is wrong.
            raise
        except Exception as e:
            # Wrap any other validation error in a StageConfigurationError.
            raise StageConfigurationError(
                stage_name=self.__class__.__name__, # Use class name if name property fails
                message=f"An unexpected error occurred during configuration validation: {e}"
            ) from e

    @property
    @abc.abstractmethod
    def name(self) -> str:
        """Provides the unique, human-readable name of the pipeline stage.

        This name is fundamental for logging, identification, and debugging purposes.
        It should be a concise but descriptive string literal that clearly
        communicates the stage's primary function (e.g., 'ProjectInitializer',
        'CodeAnalyzer', 'ReportGenerator').

        Returns:
            str: The name of the stage.
        """
        raise NotImplementedError("Subclasses must implement the 'name' property.")

    @abc.abstractmethod
    def _perform_stage_action(self, workspace: 'Workspace') -> None:
        """Executes the core, stage-specific logic.

        This abstract method must be implemented by all concrete subclasses. It
        contains the unique processing logic for the stage. The method receives
        the shared workspace object, which it can read from and write to.
        The primary contract of this method is to modify the state of the
        workspace object in-place to reflect the outcome of its processing.

        The `execute` method will invoke this and handle all surrounding concerns
        like logging, timing, and exception wrapping.

        Args:
            workspace (Workspace): The shared workspace object that is passed
                sequentially through the pipeline. Implementations should modify
                this object directly.

        Raises:
            NotImplementedError: If a subclass fails to implement this method.
            Exception: Any exception raised during execution will be caught by the
                `execute` method and wrapped in a `StageExecutionError`.
        """
        raise NotImplementedError("Subclasses must implement the '_perform_stage_action' method.")

    def _validate_config(self) -> None:
        """Hook for subclasses to validate their specific configuration.

        Subclasses can override this method to perform detailed validation of
        the `self.config` dictionary. This method is called at the end of the
        base class `__init__`.

        A robust implementation should check for the presence of required keys,
        validate data types, and check for sane values. If validation fails,
        it should raise a `StageConfigurationError` with a clear message.

        The base implementation is a no-op and performs no validation.

        Raises:
            StageConfigurationError: If the configuration is found to be invalid.
        """
        self._logger.debug("Skipping configuration validation (base implementation).")

    @final
    def execute(self, workspace: 'Workspace') -> None:
        """Public method to execute the pipeline stage.

        This method serves as the entry point for the pipeline orchestrator. It
        implements the Template Method pattern, providing a robust execution
        scaffold around the core logic defined in `_perform_stage_action`.

        The scaffold is responsible for:
        1. Logging the start and successful completion of the stage.
        2. Measuring and logging the execution time of the stage.
        3. Catching any exceptions from `_perform_stage_action`, logging them,
           and wrapping them in a standardized `StageExecutionError`.

        This method is marked as `@final` to prevent subclasses from overriding
        this critical wrapper logic, thereby ensuring consistent behavior and
        reporting across all stages in the pipeline.

        Args:
            workspace (Workspace): The shared workspace object to be processed.

        Raises:
            StageExecutionError: If any exception occurs during the execution of
                the `_perform_stage_action` method.
        """
        stage_name = self.name
        self._logger.info("======================================================================")
        self._logger.info("🚀 Starting Stage: %s", stage_name)
        self._logger.info("----------------------------------------------------------------------")
        start_time = time.monotonic()

        try:
            self._perform_stage_action(workspace)
            end_time = time.monotonic()
            duration = end_time - start_time
            self._logger.info("----------------------------------------------------------------------")
            self._logger.info("✅ Finished Stage: %s in %.4f seconds", stage_name, duration)
            self._logger.info("======================================================================\n")

        except Exception as e:
            end_time = time.monotonic()
            duration = end_time - start_time
            self._logger.error(
                "❌ Stage '%s' failed after %.4f seconds.",
                stage_name,
                duration,
                exc_info=True  # Automatically adds exception info to the log record
            )
            self._logger.info("======================================================================\n")
            # Re-raise the exception wrapped in a custom, more informative error.
            raise StageExecutionError(
                stage_name=stage_name,
                message=f"An unexpected error occurred: {type(e).__name__}",
                original_exception=e
            ) from e
