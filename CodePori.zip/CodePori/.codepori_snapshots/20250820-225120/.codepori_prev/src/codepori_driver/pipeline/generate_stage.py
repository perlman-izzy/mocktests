import logging
import json
from typing import Dict, Any, Optional

from pydantic import ValidationError

from src.codepori_driver.llm.llm_client import LLMClient
from src.codepori_driver.pipeline.pipeline_stage import PipelineStage
from src.codepori_driver.workspace.workspace import Workspace
from src.codepori_driver.models.technical_plan import TechnicalPlan, ModulePlan
from src.codepori_driver.logging.logger import get_logger


class GenerateStage(PipelineStage):
    """A pipeline stage for generating source code and tests from a technical plan.

    This stage reads the `technical_plan.json` file from the workspace, which is
    expected to be the output of the 'Plan' stage. It then iterates through each
    module defined in the plan, using a Large Language Model (LLM) to generate
    the corresponding source code and unit tests. The generated files are written
    back into the workspace in their specified target and test paths.

    Attributes:
        llm_client (LLMClient): The client for interacting with the LLM.
        config (Dict[str, Any]): The application configuration dictionary.
        logger (logging.Logger): The logger instance for this stage.
        project_description (str): A high-level description of the project.
    """

    _TECHNICAL_PLAN_FILENAME = "technical_plan.json"

    _SOURCE_CODE_PROMPT_TEMPLATE = """
    You are an expert senior Python developer specializing in clean, maintainable, and production-ready code.
    Your task is to write the complete source code for a specific module based on a provided plan.

    **Project Context:**
    {project_description}

    **Module Details:**
    - **Target File Path:** `{target_path}`
    - **Description:** {module_description}
    - **Dependencies (other modules it relies on):** {dependencies}

    **Instructions:**
    1.  Implement the full functionality as described in the module description.
    2.  Adhere to Python best practices (PEP 8, clean code principles).
    3.  Include comprehensive Google-style docstrings for all classes and functions.
    4.  Add type hints for all function arguments and return values.
    5.  Ensure all necessary imports are included and are absolute from the project root 'src'.
    6.  The code must be complete and runnable. Do not include any placeholders, TODO comments, or incomplete sections.

    **Output Format:**
    Provide ONLY the raw Python code for the file `{target_path}`. Do not include any explanations, introductory text, or markdown code fences.
    """

    _TEST_CODE_PROMPT_TEMPLATE = """
    You are an expert senior Python developer with extensive experience in software testing and Test-Driven Development (TDD).
    Your task is to write comprehensive unit tests for a given Python module using the `pytest` framework.

    **Project Context:**
    {project_description}

    **Testing Target:**
    - **Source File Path:** `{target_path}`
    - **Test File Path:** `{test_path}`

    **Source Code to Test:**
    ```python
    {source_code}
    ```

    **Instructions:**
    1.  Use the `pytest` framework for writing tests.
    2.  Employ mocking (`unittest.mock`) where necessary to isolate the unit of code being tested, especially for external dependencies like file I/O or API calls.
    3.  Aim for high test coverage, including positive cases, negative cases, and edge cases.
    4.  Ensure tests are independent and can be run in any order.
    5.  Include all necessary imports, including the module being tested.
    6.  The test code must be complete and runnable. Do not include any placeholders, TODO comments, or incomplete sections.

    **Output Format:**
    Provide ONLY the raw Python code for the test file `{test_path}`. Do not include any explanations, introductory text, or markdown code fences.
    """

    def __init__(self, llm_client: LLMClient, config: Dict[str, Any]):
        """Initializes the GenerateStage.

        Args:
            llm_client (LLMClient): The language model client for code generation.
            config (Dict[str, Any]): The application's configuration settings.
        """
        self.llm_client = llm_client
        self.config = config
        self.logger = get_logger(__name__)
        self.project_description = self.config.get("project_description", "No project description provided.")

    def run(self, workspace: Workspace) -> Workspace:
        """Executes the generation stage of the pipeline.

        This method orchestrates the process of loading the technical plan,
        and for each module within the plan, generating and writing the source
        and test code files to the workspace.

        Args:
            workspace (Workspace): The project workspace containing the input
                                 technical plan and serving as the output location
                                 for generated files.

        Returns:
            Workspace: The updated workspace containing the newly generated files.
        """
        self.logger.info("--- Starting Generate Stage ---")

        technical_plan = self._load_technical_plan(workspace)
        if not technical_plan:
            self.logger.error("Generate stage concluded without a valid technical plan. Cannot proceed.")
            return workspace

        self.logger.info(f"Successfully loaded technical plan with {len(technical_plan.modules)} modules.")

        for module_plan in technical_plan.modules:
            try:
                self.logger.info(f"Processing module: {module_plan.target_path}")
                generated_source = self._generate_source_code(workspace, module_plan)

                if generated_source:
                    self._generate_test_code(workspace, module_plan, generated_source)
                else:
                    self.logger.warning(f"Skipping test generation for {module_plan.target_path} due to empty source code generation.")
            except Exception as e:
                self.logger.error(f"An unexpected error occurred while processing module {module_plan.target_path}: {e}", exc_info=True)

        self.logger.info("--- Generate Stage Finished ---")
        return workspace

    def _load_technical_plan(self, workspace: Workspace) -> Optional[TechnicalPlan]:
        """Loads and validates the technical plan from the workspace.

        Args:
            workspace (Workspace): The workspace from which to read the plan.

        Returns:
            Optional[TechnicalPlan]: The parsed TechnicalPlan object, or None if
                                     the plan cannot be found or is invalid.
        """
        self.logger.info(f"Attempting to load technical plan from '{self._TECHNICAL_PLAN_FILENAME}'.")
        try:
            plan_content = workspace.read_file(self._TECHNICAL_PLAN_FILENAME)
            if not plan_content:
                self.logger.error(f"'{self._TECHNICAL_PLAN_FILENAME}' is empty or could not be read.")
                return None

            technical_plan = TechnicalPlan.model_validate_json(plan_content)
            return technical_plan
        except FileNotFoundError:
            self.logger.error(f"Technical plan file not found: '{self._TECHNICAL_PLAN_FILENAME}'.")
            return None
        except (ValidationError, json.JSONDecodeError) as e:
            self.logger.error(f"Failed to parse or validate technical plan: {e}", exc_info=True)
            return None
        except Exception as e:
            self.logger.error(f"An unexpected error occurred while loading the technical plan: {e}", exc_info=True)
            return None

    def _generate_source_code(self, workspace: Workspace, module_plan: ModulePlan) -> Optional[str]:
        """Generates and writes the source code for a single module.

        Args:
            workspace (Workspace): The workspace to write the generated file to.
            module_plan (ModulePlan): The plan for the module to be generated.

        Returns:
            Optional[str]: The generated source code, or None on failure.
        """
        self.logger.info(f"Generating source code for '{module_plan.target_path}'.")
        prompt = self._create_source_code_prompt(module_plan)

        try:
            generated_code = self.llm_client.generate_text(prompt)
            if not generated_code or not generated_code.strip():
                self.logger.warning(f"LLM returned empty source code for {module_plan.target_path}. Skipping file write.")
                return None

            # Basic cleanup of common LLM artifacts
            cleaned_code = self._clean_llm_output(generated_code)

            workspace.write_file(module_plan.target_path, cleaned_code)
            self.logger.info(f"Successfully wrote source code to '{module_plan.target_path}'.")
            return cleaned_code
        except Exception as e:
            self.logger.error(f"Failed to generate or write source code for {module_plan.target_path}: {e}", exc_info=True)
            return None

    def _generate_test_code(self, workspace: Workspace, module_plan: ModulePlan, source_code: str) -> None:
        """Generates and writes the unit tests for a single module.

        Args:
            workspace (Workspace): The workspace to write the generated file to.
            module_plan (ModulePlan): The plan containing the test path.
            source_code (str): The source code of the module to be tested.
        """
        if not module_plan.test_path:
            self.logger.info(f"No test path specified for {module_plan.target_path}. Skipping test generation.")
            return

        self.logger.info(f"Generating test code for '{module_plan.test_path}'.")
        prompt = self._create_test_code_prompt(module_plan, source_code)

        try:
            generated_tests = self.llm_client.generate_text(prompt)
            if not generated_tests or not generated_tests.strip():
                self.logger.warning(f"LLM returned empty test code for {module_plan.test_path}. Skipping file write.")
                return

            cleaned_tests = self._clean_llm_output(generated_tests)

            workspace.write_file(module_plan.test_path, cleaned_tests)
            self.logger.info(f"Successfully wrote test code to '{module_plan.test_path}'.")
        except Exception as e:
            self.logger.error(f"Failed to generate or write test code for {module_plan.test_path}: {e}", exc_info=True)

    def _create_source_code_prompt(self, module_plan: ModulePlan) -> str:
        """Creates a detailed prompt for generating module source code.

        Args:
            module_plan (ModulePlan): The plan for the module.

        Returns:
            str: The fully formatted prompt.
        """
        dependencies_str = ", ".join(module_plan.dependencies) if module_plan.dependencies else "None"
        return self._SOURCE_CODE_PROMPT_TEMPLATE.format(
            project_description=self.project_description,
            target_path=module_plan.target_path,
            module_description=module_plan.description,
            dependencies=dependencies_str
        )

    def _create_test_code_prompt(self, module_plan: ModulePlan, source_code: str) -> str:
        """Creates a detailed prompt for generating module unit tests.

        Args:
            module_plan (ModulePlan): The plan for the module.
            source_code (str): The source code to be tested.

        Returns:
            str: The fully formatted prompt.
        """
        return self._TEST_CODE_PROMPT_TEMPLATE.format(
            project_description=self.project_description,
            target_path=module_plan.target_path,
            test_path=module_plan.test_path,
            source_code=source_code
        )

    def _clean_llm_output(self, code: str) -> str:
        """Removes common markdown fences from LLM code output.

        Args:
            code (str): The raw string output from the LLM.

        Returns:
            str: The cleaned code string.
        """
        if code.strip().startswith("```python"):
            code = code.strip()[9:]
        elif code.strip().startswith("```"):
            code = code.strip()[3:]

        if code.strip().endswith("```"):
            code = code.strip()[:-3]

        return code.strip()
