from __future__ import annotations

import abc
import dataclasses
import datetime
import json
import logging
import shutil
import subprocess
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

# In a real-world scenario, these common components would be in separate modules
# like 'src.codepori_driver.pipeline.models' or 'src.codepori_driver.pipeline.abc'.
# For this self-contained module, they are included here.

# --- Common Pipeline Components ---

@dataclasses.dataclass
class PipelineContext:
    """A data class to hold and pass state between pipeline stages.

    This object acts as a shared memory or context for the entire pipeline run,
    accumulating data, logs, and artifacts as it passes through each stage.

    Attributes:
        project_root (Path): The root directory of the project being generated.
        generated_files (List[Path]): A list of paths to all generated code files.
        temp_dir (Optional[Path]): The path to a temporary directory used during generation.
        start_time (float): The timestamp (from time.monotonic()) when the pipeline started.
        execution_logs (List[str]): A list of log messages from the pipeline execution.
        encountered_errors (List[str]): A list of errors encountered during the pipeline run.
        metadata (Dict[str, Any]): A dictionary for storing any other arbitrary data.
    """ 
    project_root: Path
    generated_files: List[Path] = dataclasses.field(default_factory=list)
    temp_dir: Optional[Path] = None
    start_time: float = dataclasses.field(default_factory=time.monotonic)
    execution_logs: List[str] = dataclasses.field(default_factory=list)
    encountered_errors: List[str] = dataclasses.field(default_factory=list)
    metadata: Dict[str, Any] = dataclasses.field(default_factory=dict)


class PipelineStage(abc.ABC):
    """Abstract base class for a stage in the code generation pipeline.

    Each stage in the pipeline must inherit from this class and implement
    the `execute` method. This ensures a consistent interface for all pipeline
    operations.
    """

    @abc.abstractmethod
    def execute(self, context: PipelineContext) -> PipelineContext:
        """Executes the logic for this pipeline stage.

        Args:
            context: The current pipeline context, containing all state from
                previous stages.

        Returns:
            The modified pipeline context after this stage has run.
        """
        raise NotImplementedError

# --- Custom Exceptions for Finalize Stage ---

class FinalizeStageError(Exception):
    """Base exception for errors raised by the FinalizeStage."""
    pass

class DependencyNotFoundError(FinalizeStageError):
    """Raised when a required external dependency (e.g., a code formatter) is not found."""
    pass

class FormatterError(FinalizeStageError):
    """Raised when the code formatting subprocess fails."""
    pass

class ReportGenerationError(FinalizeStageError):
    """Raised when the final summary report cannot be generated."""
    pass

class CleanupError(FinalizeStageError):
    """Raised when an error occurs during the cleanup of temporary files."""
    pass


# --- Finalize Stage Implementation ---

class FinalizeStage(PipelineStage):
    """The final stage of the pipeline, responsible for post-generation tasks.

    This stage handles code formatting, cleanup of temporary resources, and the
    generation of a final summary report for the entire pipeline execution.
    It is designed to be the last step that ensures the generated output is
    clean, consistent, and well-documented.

    Attributes:
        formatter_command (Optional[Sequence[str]]): The command to run for code formatting.
            Example: `['black', '.']` or `['ruff', 'format', '.']`.
        generate_report (bool): Whether to generate a JSON summary report.
        report_path (Path): The file path where the summary report will be saved.
        cleanup_temp (bool): Whether to delete the temporary directory after the run.
        logger (logging.Logger): The logger instance for this stage.
    """

    def __init__(
        self, 
        formatter_command: Optional[Sequence[str]] = None,
        generate_report: bool = True,
        report_path: Path = Path('codepori_report.json'),
        cleanup_temp: bool = True
    ):
        """Initializes the FinalizeStage with its configuration.

        Args:
            formatter_command: The command and arguments for an external code
                formatter. If None, formatting is skipped.
            generate_report: Flag to enable or disable summary report generation.
            report_path: The destination path for the summary report.
            cleanup_temp: Flag to enable or disable cleanup of the temp directory.

        Raises:
            DependencyNotFoundError: If the formatter command is specified but the
                executable cannot be found in the system's PATH.
        """
        self.formatter_command = formatter_command
        self.generate_report = generate_report
        self.report_path = report_path
        self.cleanup_temp = cleanup_temp
        self.logger = logging.getLogger(self.__class__.__name__)
        self.logger.setLevel(logging.INFO)

        self._check_dependencies()

    def _check_dependencies(self) -> None:
        """Checks for required external dependencies."""
        if self.formatter_command:
            command_name = self.formatter_command[0]
            if not shutil.which(command_name):
                msg = f"Formatter command '{command_name}' not found in PATH."
                self.logger.error(msg)
                raise DependencyNotFoundError(msg)
            self.logger.info(f"Found formatter dependency: '{command_name}'")

    def execute(self, context: PipelineContext) -> PipelineContext:
        """Runs the finalize stage: formats code, generates a report, and cleans up.

        Args:
            context: The pipeline context from previous stages.

        Returns:
            The final, updated pipeline context.
        """
        self.logger.info("--- Starting Finalize Stage ---")
        try:
            if self.formatter_command:
                self._format_code(context)

            if self.generate_report:
                self._generate_report(context)

            if self.cleanup_temp:
                self._cleanup(context)

            self.logger.info("--- Finalize Stage Completed Successfully ---")
            return context
        except FinalizeStageError as e:
            self.logger.error(f"An error occurred during the finalize stage: {e}")
            context.encountered_errors.append(str(e))
            # Re-raise to allow upstream handlers to catch it if necessary
            raise

    def _format_code(self, context: PipelineContext) -> None:
        """Runs an external code formatter on the generated files.

        Args:
            context: The pipeline context containing the project root.

        Raises:
            FormatterError: If the formatting subprocess fails.
        """
        if not self.formatter_command:
            self.logger.info("No formatter command configured. Skipping formatting.")
            return

        self.logger.info(f"Running formatter: `{' '.join(self.formatter_command)}` on '{context.project_root}'")
        try:
            process = subprocess.run(
                self.formatter_command,
                cwd=context.project_root,  # Run command from the project root
                capture_output=True,
                text=True,
                check=False, # We check the returncode manually
                timeout=300 # 5-minute timeout
            )

            if process.stdout:
                self.logger.info(f"Formatter stdout:\n{process.stdout}")
            if process.stderr:
                self.logger.warning(f"Formatter stderr:\n{process.stderr}")

            if process.returncode != 0:
                error_message = f"Formatter failed with exit code {process.returncode}."
                self.logger.error(error_message)
                raise FormatterError(f"{error_message}\n{process.stderr}")

            self.logger.info("Code formatting completed successfully.")

        except FileNotFoundError:
            msg = f"Formatter command '{self.formatter_command[0]}' not found."
            self.logger.error(msg)
            raise DependencyNotFoundError(msg)
        except subprocess.TimeoutExpired:
            msg = "Formatter command timed out."
            self.logger.error(msg)
            raise FormatterError(msg)
        except Exception as e:
            msg = f"An unexpected error occurred during formatting: {e}"
            self.logger.error(msg, exc_info=True)
            raise FormatterError(msg) from e

    def _generate_report(self, context: PipelineContext) -> None:
        """Generates a JSON summary report of the pipeline run.

        Args:
            context: The pipeline context containing run data.

        Raises:
            ReportGenerationError: If the report file cannot be written.
        """
        self.logger.info(f"Generating summary report at '{self.report_path}'")

        end_time = time.monotonic()
        duration_seconds = end_time - context.start_time

        report_data = {
            'run_timestamp_utc': datetime.datetime.utcnow().isoformat() + 'Z',
            'run_duration_seconds': round(duration_seconds, 4),
            'project_root': str(context.project_root),
            'total_files_generated': len(context.generated_files),
            'generated_files': [str(p) for p in context.generated_files],
            'total_errors': len(context.encountered_errors),
            'errors': context.encountered_errors,
            'metadata': context.metadata
        }

        try:
            self.report_path.parent.mkdir(parents=True, exist_ok=True)
            with open(self.report_path, 'w', encoding='utf-8') as f:
                json.dump(report_data, f, indent=4)
            self.logger.info("Summary report generated successfully.")
        except (IOError, OSError) as e:
            msg = f"Failed to write summary report to '{self.report_path}': {e}"
            self.logger.error(msg, exc_info=True)
            raise ReportGenerationError(msg) from e

    def _cleanup(self, context: PipelineContext) -> None:
        """Removes temporary directories and files.

        Args:
            context: The pipeline context containing the temp directory path.

        Raises:
            CleanupError: If the temporary directory cannot be removed.
        """
        if not context.temp_dir:
            self.logger.info("No temporary directory specified. Skipping cleanup.")
            return

        self.logger.info(f"Cleaning up temporary directory: '{context.temp_dir}'")
        if not context.temp_dir.exists() or not context.temp_dir.is_dir():
            self.logger.warning(
                f"Temporary directory '{context.temp_dir}' does not exist or is not a directory. Skipping cleanup."
            )
            return

        try:
            shutil.rmtree(context.temp_dir)
            self.logger.info("Temporary directory cleaned up successfully.")
        except (IOError, OSError) as e:
            msg = f"Failed to remove temporary directory '{context.temp_dir}': {e}"
            self.logger.error(msg, exc_info=True)
            raise CleanupError(msg) from e
