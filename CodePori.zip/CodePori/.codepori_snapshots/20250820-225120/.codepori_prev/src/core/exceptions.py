from typing import Any, Dict, Optional


class ApplicationError(Exception):
    """Base class for all custom exceptions in this application.

    This exception class is intended to be subclassed, not raised directly.
    It provides a consistent structure for all application-specific errors,
    allowing for unified error handling and logging. It can store an
    optional error code and a payload for additional context.

    Attributes:
        message (str): A human-readable description of the error.
        error_code (Optional[str]): A unique, machine-readable code for the error.
        payload (Optional[Dict[str, Any]]): A dictionary for extra context.
    """

    def __init__(
        self,
        message: str,
        error_code: Optional[str] = None,
        payload: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Initializes the ApplicationError.

        Args:
            message (str): The primary error message.
            error_code (Optional[str]): A specific error code for categorization.
            payload (Optional[Dict[str, Any]]): Additional data related to the error.
        """
        super().__init__(message)
        self.message = message
        self.error_code = error_code
        self.payload = payload or {}

    def __str__(self) -> str:
        """Returns the string representation of the error."""
        if self.error_code:
            return f"[{self.error_code}] {self.message}"
        return self.message

    def __repr__(self) -> str:
        """Returns the developer-friendly representation of the error."""
        return (
            f"{self.__class__.__name__}("
            f"message='{self.message}', "
            f"error_code='{self.error_code}', "
            f"payload={self.payload}"
            f")"
        )


class PipelineError(ApplicationError):
    """Represents a generic error that occurred during a pipeline execution.

    This exception should be used for failures within a data processing pipeline
    that are not specific to a particular stage (e.g., pipeline orchestration
    failure, invalid pipeline definition). For stage-specific errors, use
    subclasses of `PipelineStageError`.

    Example:
        >>> try:
        ...     raise PipelineError("Pipeline failed to initialize.", error_code="PIPE_INIT_001")
        ... except PipelineError as e:
        ...     print(e)
        [PIPE_INIT_001] Pipeline failed to initialize.
    """
    pass


class PipelineStageError(PipelineError):
    """Base class for errors that occur within a specific stage of a pipeline.

    This class extends `PipelineError` by adding context about the stage
    where the error occurred.

    Attributes:
        stage_name (str): The name of the pipeline stage that failed.

    Example:
        >>> try:
        ...     raise PipelineStageError(
        ...         "Generic stage failure",
        ...         stage_name="data_processing_main"
        ...     )
        ... except PipelineStageError as e:
        ...     print(f"Error in stage '{e.stage_name}': {e}")
        Error in stage 'data_processing_main': Generic stage failure
    """

    def __init__(
        self,
        message: str,
        stage_name: str,
        error_code: Optional[str] = None,
        payload: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Initializes the PipelineStageError.

        Args:
            message (str): The primary error message.
            stage_name (str): The name of the stage where the error happened.
            error_code (Optional[str]): A specific error code for categorization.
            payload (Optional[Dict[str, Any]]): Additional data related to the error.
        """
        super().__init__(message, error_code, payload)
        self.stage_name = stage_name

    def __str__(self) -> str:
        """Returns the string representation, including the stage name."""
        base_str = super().__str__()
        return f"Stage '{self.stage_name}': {base_str}"

    def __repr__(self) -> str:
        """Returns the developer-friendly representation of the error."""
        return (
            f"{self.__class__.__name__}("
            f"message='{self.message}', "
            f"stage_name='{self.stage_name}', "
            f"error_code='{self.error_code}', "
            f"payload={self.payload}"
            f")"
        )


class ExtractionError(PipelineStageError):
    """Indicates a failure during the data extraction phase of a pipeline.

    This could be due to issues like a source system being unavailable,
    authentication failure, or an invalid query.

    Example:
        >>> source_details = {"host": "remote.db", "table": "users"}
        >>> try:
        ...     raise ExtractionError(
        ...         "Failed to connect to source database.",
        ...         stage_name="extract_from_postgres",
        ...         error_code="EXT_DB_CONN_001",
        ...         payload={"details": source_details}
        ...     )
        ... except ExtractionError as e:
        ...     print(e)
        Stage 'extract_from_postgres': [EXT_DB_CONN_001] Failed to connect to source database.
    """
    pass


class TransformationError(PipelineStageError):
    """Indicates a failure during the data transformation phase of a pipeline.

    This could be due to unexpected data formats, failed data type conversions,
    or errors in business logic application.

    Example:
        >>> record_id = "user_123"
        >>> try:
        ...     raise TransformationError(
        ...         f"Could not parse date field for record '{record_id}'.",
        ...         stage_name="transform_user_data",
        ...         error_code="TRNS_DATE_PARSE_002",
        ...         payload={"record_id": record_id, "field": "created_at"}
        ...     )
        ... except TransformationError as e:
        ...     print(e)
        Stage 'transform_user_data': [TRNS_DATE_PARSE_002] Could not parse date field for record 'user_123'.
    """
    pass


class LoadingError(PipelineStageError):
    """Indicates a failure during the data loading phase of a pipeline.

    This could be due to issues like a target system being unavailable,
    database constraint violations, or insufficient permissions.

    Example:
        >>> destination = {"type": "data_warehouse", "table": "fact_sales"}
        >>> try:
        ...     raise LoadingError(
        ...         "Unique constraint violation on target table.",
        ...         stage_name="load_to_warehouse",
        ...         error_code="LOAD_DB_CONST_003",
        ...         payload={"destination": destination}
        ...     )
        ... except LoadingError as e:
        ...     print(e)
        Stage 'load_to_warehouse': [LOAD_DB_CONST_003] Unique constraint violation on target table.
    """
    pass


class ValidationPipelineError(PipelineStageError):
    """Indicates a failure during a data validation stage of a pipeline.

    This is for when a specific stage is dedicated to validation and that
    validation process itself fails, as distinct from `DataValidationError` which
    refers to the data itself being invalid.

    Example:
        >>> try:
        ...     raise ValidationPipelineError(
        ...         "Validation schema could not be loaded.",
        ...         stage_name="validate_source_data",
        ...         error_code="VAL_SCHEMA_LOAD_001"
        ...     )
        ... except ValidationPipelineError as e:
        ...     print(e)
        Stage 'validate_source_data': [VAL_SCHEMA_LOAD_001] Validation schema could not be loaded.
    """
    pass


class ConfigurationError(ApplicationError):
    """Indicates an error related to application configuration.

    This exception is raised when configuration is missing, malformed,
    or contains invalid values.

    Example:
        >>> config_key = "database.connection.url"
        >>> try:
        ...     raise ConfigurationError(
        ...         f"Required configuration key '{config_key}' is missing.",
        ...         error_code="CONFIG_MISSING_KEY_001",
        ...         payload={"key": config_key}
        ...     )
        ... except ConfigurationError as e:
        ...     print(e)
        [CONFIG_MISSING_KEY_001] Required configuration key 'database.connection.url' is missing.
    """
    pass


class ResourceError(ApplicationError):
    """Base class for errors involving external resources (e.g., files, APIs).

    This class should be subclassed to provide more specific details about
    the nature of the resource failure.
    """
    pass


class ResourceNotFoundError(ResourceError):
    """Indicates that a required external resource could not be found.

    Example:
        >>> file_path = "/path/to/nonexistent/file.csv"
        >>> try:
        ...     raise ResourceNotFoundError(
        ...         f"File not found at path: {file_path}",
        ...         error_code="RES_FILE_NOT_FOUND_001",
        ...         payload={"path": file_path}
        ...     )
        ... except ResourceNotFoundError as e:
        ...     print(e)
        [RES_FILE_NOT_FOUND_001] File not found at path: /path/to/nonexistent/file.csv
    """
    pass


class ResourceConnectionError(ResourceError):
    """Indicates a failure to connect to an external resource.

    This could be a database, a remote API, or any other networked service.

    Example:
        >>> api_endpoint = "https://api.example.com/data"
        >>> try:
        ...     raise ResourceConnectionError(
        ...         f"Connection to API endpoint timed out: {api_endpoint}",
        ...         error_code="RES_CONN_TIMEOUT_002",
        ...         payload={"endpoint": api_endpoint}
        ...     )
        ... except ResourceConnectionError as e:
        ...     print(e)
        [RES_CONN_TIMEOUT_002] Connection to API endpoint timed out: https://api.example.com/data
    """
    pass


class DataError(ApplicationError):
    """Base class for errors related to data integrity, format, or content.

    This is for errors discovered outside the context of a specific pipeline stage,
    or for when data validation is a cross-cutting concern.
    """
    pass


class DataValidationError(DataError):
    """Indicates that data failed a validation check.

    This is used when data does not conform to a required schema, business rule,
    or other integrity constraint.

    Example:
        >>> validation_errors = [{"field": "email", "error": "invalid format"}]
        >>> try:
        ...     raise DataValidationError(
        ...         "User data failed validation.",
        ...         error_code="DATA_VALIDATION_001",
        ...         payload={"errors": validation_errors}
        ...     )
        ... except DataValidationError as e:
        ...     print(e.payload)
        {'errors': [{'field': 'email', 'error': 'invalid format'}]}
    """
    pass


class DataParsingError(DataError):
    """Indicates an error while parsing data from a raw format.

    This is used for errors like malformed JSON, invalid CSV structure, or
    unintelligible binary data.

    Example:
        >>> raw_json = '{\"name\": \"John Doe\", \"age\": 30,'
        >>> try:
        ...     raise DataParsingError(
        ...         "Failed to parse JSON string.",
        ...         error_code="DATA_PARSE_JSON_001",
        ...         payload={"line": 1, "column": 31}
        ...     )
        ... except DataParsingError as e:
        ...     print(e)
        [DATA_PARSE_JSON_001] Failed to parse JSON string.
    """
    pass
