#!/usr/bin/env python3
# coding: utf-8
"""
CodePori (Proxy/Gemini) — STRICT JSON + UNIVERSAL ANY-ERROR REPROMPTS + TEXT/ASSET-SAFE WRITES
+ LINTER + AUTO-FIX RELATIVE/CONFIG IMPORTS + DIFF + TEST REPAIR + RESILIENT PYTEST (plugin-aware)

- Pytest plugin autoload is ON by default. If a third-party plugin crashes import, we auto-fallback:
  autoload OFF + explicit safelist (-p pytest_mock, -p pyfakefs) when tests reference those fixtures.
- JSON retries = 6 (exact).
- REPAIR_RETRIES = 6 (per-file compile-checked repair loops for ALL Python files, including tests).
- Always syntax-lint, print diff report, and verify env/runtime settings.
"""

from __future__ import annotations

import ast
import importlib
import json
import os
import pathlib
import re
import shutil
import subprocess
import sys
import textwrap
import time
import traceback
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple

import requests

# ---------------------- PATHS / CONFIG ----------------------
PROJECT_DIR = pathlib.Path(__file__).resolve().parent
OUT_DIR = PROJECT_DIR / "output"
CODE_DIR = OUT_DIR / "code"
LOG_FILE = OUT_DIR / "run.log"
PREV_SNAPSHOT = PROJECT_DIR / ".codepori_prev"

PROMPTS = {
    "project": PROJECT_DIR / "project_description.txt",
    "manager": PROJECT_DIR / "manager_bot.txt",
    "dev1": PROJECT_DIR / "dev_1.txt",
    "dev2": PROJECT_DIR / "dev_2.txt",
    "final1": PROJECT_DIR / "finalizer_bot_1.txt",
    "final2": PROJECT_DIR / "finalizer_bot_2.txt",
    # repo typo kept for compatibility
    "verify": PROJECT_DIR / "verfication_bot.txt",
}

PROXY_BASE = os.getenv("GEMINI_PROXY_BASE", "http://localhost:8000").rstrip("/")
PRIMARY_MODEL = "models/gemini-2.5-pro"
FALLBACK_MODEL = "models/gemini-2.5-flash"
TIMEOUT_SECONDS = int(os.getenv("CP_HTTP_TIMEOUT", "180"))

ENABLE_LINTER = os.getenv("CP_ENABLE_LINTER", "1") != "0"
LINT_REPROMPTS = max(0, int(os.getenv("CP_LINT_REPROMPTS", "2")))
JSON_RETRIES = max(1, int(os.getenv("CP_JSON_RETRIES", "6")))  # default 6
REPAIR_RETRIES = max(1, int(os.getenv("CP_REPAIR_RETRIES", "6")))  # default 6
AUTOFIX_RELATIVE = os.getenv("CP_AUTOFIX_RELATIVE", "1") != "0"

SAFE_PYTEST_PLUGINS = ("pytest_mock", "pyfakefs")  # names for -p

# ---------------------- LOGGING ----------------------
def log(msg: str) -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    line = f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {msg}"
    print(line, flush=True)
    with LOG_FILE.open("a", encoding="utf-8") as f:
        f.write(line + "\n")

# ---------------------- SNAPSHOT/DIFF ----------------------
def snapshot_previous() -> None:
    try:
        if PREV_SNAPSHOT.exists():
            shutil.rmtree(PREV_SNAPSHOT)
        if CODE_DIR.exists():
            shutil.copytree(CODE_DIR, PREV_SNAPSHOT)
        log(f"Snapshot saved: {PREV_SNAPSHOT}")
    except Exception as e:
        log(f"Snapshot warning: {e}")

def _list_rel(root: pathlib.Path) -> Set[str]:
    out: Set[str] = set()
    if not root.exists():
        return out
    for p in root.rglob("*"):
        if p.is_file():
            out.add(str(p.relative_to(root)))
    return out

def write_diff_report() -> None:
    try:
        report = OUT_DIR / "diff-report.txt"
        old = PREV_SNAPSHOT
        new = CODE_DIR
        added: List[str] = []
        removed: List[str] = []
        modified: List[str] = []

        old_set = _list_rel(old)
        new_set = _list_rel(new)
        for rel in sorted(new_set - old_set):
            added.append(rel)
        for rel in sorted(old_set - new_set):
            removed.append(rel)
        for rel in sorted(new_set & old_set):
            try:
                if (old / rel).read_bytes() != (new / rel).read_bytes():
                    modified.append(rel)
            except Exception:
                modified.append(rel)
        lines = [
            "# CodePori Diff Report",
            "",
            "## Added:",
            *((f"+ {a}" for a in added) if added else ["(none)"]),
            "",
            "## Removed:",
            *((f"- {r}" for r in removed) if removed else ["(none)"]),
            "",
            "## Modified:",
            *((f"* {m}" for m in modified) if modified else ["(none)"]),
            "",
        ]
        report.write_text("\n".join(lines), encoding="utf-8")
        log("Diff report written to ./output/diff-report.txt")
    except Exception as e:
        log(f"Diff report warning: {e}")

def log_diff_report_contents() -> None:
    try:
        p = OUT_DIR / "diff-report.txt"
        if not p.exists():
            log("Diff report not found.")
            return
        log("--- BEGIN DIFF REPORT ---")
        for ln in p.read_text(encoding="utf-8").splitlines():
            log(ln)
        log("--- END DIFF REPORT ---")
    except Exception as e:
        log(f"Diff report read warning: {e}")

# ---------------------- FILE UTIL ----------------------
def ensure_dirs() -> None:
    if OUT_DIR.exists():
        shutil.rmtree(OUT_DIR)
    CODE_DIR.mkdir(parents=True, exist_ok=True)

def read_text(p: pathlib.Path, default: str = "") -> str:
    try:
        return p.read_text(encoding="utf-8")
    except Exception:
        return default

def write_text(p: pathlib.Path, content: str) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    if not content.endswith("\n"):
        content += "\n"
    p.write_text(content, encoding="utf-8")

def safe_relpath(p: pathlib.Path) -> str:
    try:
        return str(p.relative_to(CODE_DIR))
    except Exception:
        return str(p)

# ---------------------- HTTP CLIENT (Proxy) ----------------------
@dataclass
class JsonCandidate:
    raw: str
    obj: dict
    code: str
    score: int
    reason: str

class ProxyGemini:
    def __init__(self, base: str, primary: str, fallback: str):
        self.base = base
        self.primary = primary
        self.fallback = fallback
        self.session = requests.Session()

    def _endpoint(self, model: str) -> str:
        return f"{self.base}/v1beta/models/{model}:generateContent"

    def _payload(self, prompt: str) -> Dict[str, Any]:
        return {
            "contents": [{"role": "user", "parts": [{"text": prompt}]}],
            "generationConfig": {"responseMimeType": "application/json"},
        }

    def _join_parts(self, data: Dict[str, Any]) -> str:
        try:
            parts = (data.get("candidates") or [{}])[0].get("content", {}).get("parts", [])
            out: List[str] = []
            for p in parts:
                t = p.get("text")
                if isinstance(t, str):
                    out.append(t)
            return "\n".join(out).strip()
        except Exception:
            return ""

    def ask(self, prompt: str) -> Optional[str]:
        for model in (self.primary, self.fallback):
            try:
                r = self.session.post(self._endpoint(model), json=self._payload(prompt), timeout=TIMEOUT_SECONDS)
                if r.ok:
                    text = self._join_parts(r.json())
                    if text:
                        if model == self.fallback:
                            log("Used fallback model successfully.")
                        return text
                    else:
                        log("Empty response text; trying fallback model." if model == self.primary else "Fallback returned empty text.")
                else:
                    log(f"Model {model} failed: HTTP {r.status_code} {(r.text or '')[:200]}")
            except Exception as e:
                log(f"Model {model} exception: {e}")
        return None

# ---------------------- JSON PARSING ----------------------
_JSON_FENCE_RE = re.compile(r"```(?:json)?\s*(.*?)```", re.IGNORECASE | re.DOTALL)

def _balanced_json_slices(blob: str) -> List[str]:
    out: List[str] = []
    stack: List[str] = []
    start: Optional[int] = None
    for i, ch in enumerate(blob or ""):
        if ch in "{[":
            if not stack:
                start = i
            stack.append(ch)
        elif ch in "}]":
            if stack:
                opener = stack.pop()
                if (opener, ch) not in (("{", "}"), ("[", "]")):
                    stack.clear()
                    start = None
                    continue
                if not stack and start is not None:
                    out.append(blob[start : i + 1])
                    start = None
    return out

def _all_json_blobs(text: str) -> List[str]:
    blobs: List[str] = []
    for m in _JSON_FENCE_RE.finditer(text or ""):
        block = m.group(1).strip()
        if block:
            blobs.append(block)
    blobs.extend(_balanced_json_slices(text or ""))
    t = (text or "").strip()
    if t.startswith("{") or t.startswith("["):
        blobs.append(t)
    seen = set()
    uniq: List[str] = []
    for b in blobs:
        k = b.strip()
        if k and k not in seen:
            seen.add(k)
            uniq.append(k)
    return uniq

def _score_code_sanity(code: str) -> int:
    if not code or not code.strip():
        return 0
    s = code.strip()
    score = 0
    score += min(len(s), 100000) // 50
    if "\n" in s: score += 50
    if "import " in s: score += 50
    if "def " in s: score += 50
    if "class " in s: score += 30
    if "<FULL" in s.upper(): score -= 200
    return score

def parse_json_best(text: str, *, want: type = dict, require_code: bool = False, dump_dir: Optional[pathlib.Path] = None, tag: str = "generic") -> dict:
    if not isinstance(text, str):
        raise ValueError("non-string response")
    blobs = _all_json_blobs(text)
    if dump_dir:
        dump_dir.mkdir(parents=True, exist_ok=True)
        (dump_dir / f"{tag}.raw.txt").write_text(text, encoding="utf-8")
        (dump_dir / f"{tag}.blobs.count").write_text(str(len(blobs)), encoding="utf-8")
    candidates: List[JsonCandidate] = []
    last_err = None
    for blob in blobs:
        try:
            obj = json.loads(blob)
            if not isinstance(obj, want):
                continue
            code = str(obj.get("code", "")) if isinstance(obj, dict) else ""
            score = _score_code_sanity(code)
            reason = "ok"
            if require_code and not code.strip():
                reason = "empty_code"
            candidates.append(JsonCandidate(raw=blob, obj=obj, code=code, score=score, reason=reason))
        except Exception as e:
            last_err = str(e)
    candidates.sort(key=lambda c: (c.score, len(c.code)), reverse=True)
    if dump_dir:
        lines = []
        for i, c in enumerate(candidates):
            preview = c.code[:80].replace(os.linesep, " ") if isinstance(c.code, str) else ""
            lines.append(f"{i:02d} score={c.score} reason={c.reason} code_len={len(c.code)} preview={preview}")
        (dump_dir / f"{tag}.candidates.txt").write_text("\n".join(lines), encoding="utf-8")
    if not candidates:
        raise ValueError(f"failed to parse {want.__name__} JSON ({last_err or 'no candidates'})")
    best = candidates[0]
    if require_code and not best.code.strip():
        raise ValueError("parsed JSON but best candidate has empty code (all candidates empty)")
    return best.obj

# ---------------------- CODE/TEXT WRITERS ----------------------
TEXT_EXTS = {
    ".md", ".txt", ".json", ".yaml", ".yml", ".toml", ".ini", ".cfg", ".conf", ".csv", ".tsv",
    ".env", ".gitignore", ".dockerignore", ".xml", ".html", ".css", ".sh", ".bash", ".zsh",
    ".ps1", ".bat", ".rst", ".cfg", ".pyi",
}

def write_python_file(path: pathlib.Path, code: str) -> None:
    cleaned = textwrap.dedent(code).rstrip() + "\n"
    try:
        compile(cleaned, str(path), "exec")
    except SyntaxError as e:
        preview = (cleaned.splitlines()[max(e.lineno - 1, 0)] if cleaned else "")
        raise SyntaxError(f"SyntaxError before write {path}: {e.msg} at {e.lineno}:{e.offset} -> {preview}") from e
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(cleaned, encoding="utf-8")

def write_text_file(path: pathlib.Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not content.endswith("\n"):
        content = content + "\n"
    path.write_text(content, encoding="utf-8")

# ---------------------- PLAN / PROMPTS ----------------------
def step_plan(llm: ProxyGemini) -> Dict[str, Any]:
    desc = read_text(PROMPTS["project"]) or "(no project_description.txt)"
    mgr = read_text(PROMPTS["manager"]) or ""
    required_shape = {
        "architecture": ["..."],
        "files": [{"path": "src/module.py", "purpose": "..."}],
        "tests": [{"path": "tests/test_something.py", "purpose": "..."}],
        "notes": "...",
    }
    base_prompt = "\n".join(
        [
            "You are the MANAGER orchestrator.",
            "\nProject description:",
            desc,
            "\nManager directives:",
            mgr,
            "\nReturn ONLY a JSON object with keys: architecture (list), files (list), tests (list), notes (string).",
            "Do not include markdown fences or commentary.",
            json.dumps(required_shape, indent=2),
        ]
    )
    text = llm.ask(base_prompt)
    if not text:
        raise RuntimeError("plan: empty response")
    log("=== RAW PLAN RESPONSE ===")
    log(text[:1200] + ("\n... (truncated)" if len(text) > 1200 else ""))
    log("=== END RAW PLAN ===")
    for _ in range(3):
        try:
            plan = parse_json_best(text, want=dict, require_code=False, dump_dir=OUT_DIR / "llm_raw" / "plan", tag="plan")
            if not isinstance(plan.get("files", []), list):
                raise ValueError("files not a list")
            if not isinstance(plan.get("tests", []), list):
                raise ValueError("tests not a list")
            log("=== PARSED PLAN ===")
            log(json.dumps(plan, indent=2)[:1200])
            log("=== END PARSED PLAN ===")
            return plan
        except Exception:
            log("Plan parse error; requesting strict reissue (retry)")
            text = llm.ask("Return ONLY valid JSON with keys architecture, files, tests, notes. No fences, no prose.")
            if not text:
                break
    raise RuntimeError("plan: could not parse JSON after retries")

def _dev_prompt_for_file(file_item: Dict[str, Any], plan_paths: Sequence[str]) -> str:
    dev1 = read_text(PROMPTS["dev1"]) or ""
    dev2 = read_text(PROMPTS["dev2"]) or ""
    target = str(file_item["path"]).strip()
    ext = pathlib.Path(target).suffix.lower()
    expected_lang = "python" if ext == ".py" else "text"
    schema = {"language": expected_lang, "code": "<FULL FILE CONTENT HERE>"}
    rules = [
        "You are a SENIOR DEVELOPER. Produce the COMPLETE file as JSON only.",
        dev1, dev2,
        f"Target path: {target}",
        f"Purpose: {file_item.get('purpose','')}\n",
        "Rules:",
        "- Return ONLY a JSON object with keys {\"language\", \"code\"}.",
        "- The 'code' field MUST contain the complete, production-ready source for this file.",
        "- The 'code' field MUST NOT be empty or just whitespace.",
        "- No markdown, no fences, no prose outside the JSON.",
    ]
    if ext == ".py":
        rules += ["- Import paths MUST be absolute from the repo root package (usually 'src.'), NEVER relative."]
    else:
        rules += ["- This is NOT a Python file. Return raw text in 'code' and set language='text'."]
    rules.append(json.dumps(schema, indent=2))
    return "\n".join(rules)

def _test_prompt_for_file(test_item: Dict[str, Any], plan_paths: Sequence[str]) -> str:
    verify = read_text(PROMPTS["verify"]) or ""
    schema = {"language": "python", "code": "<FULL PYTEST FILE CONTENT HERE>"}
    return "\n".join(
        [
            "You are a TEST ENGINEER. Produce a COMPLETE pytest file as JSON only.",
            verify,
            f"Target path: {test_item['path']}",
            f"Purpose: {test_item.get('purpose','')}\n",
            "Rules:",
            "- Return ONLY a JSON object with keys {\"language\", \"code\"}.",
            "- The 'code' field MUST contain the complete, production-ready pytest file.",
            "- The 'code' field MUST NOT be empty or whitespace.",
            "- No markdown, no fences, no prose outside the JSON.",
            "- Import modules using absolute paths from the repo root (e.g., 'src.module').",
            "- Use fixtures correctly; no top-level 'yield' statements.",
            json.dumps(schema, indent=2),
        ]
    )

# ---------------------- GENERATION (with universal any-error reprompts) ----------------------
def _json_retry(llm: ProxyGemini, prompt: str, *, require_code: bool, dump_dir: Optional[pathlib.Path], tag: str) -> Dict[str, Any]:
    last_err: Optional[str] = None
    for i in range(JSON_RETRIES):
        txt = llm.ask(prompt)
        if not txt:
            last_err = "empty response from LLM"
            log(f"  -> LLM returned empty response; re-prompt ({i+1}/{JSON_RETRIES})")
            continue
        try:
            payload = parse_json_best(txt, want=dict, require_code=require_code, dump_dir=dump_dir, tag=f"{tag}_{i}")
            code = str(payload.get("code", ""))
            if require_code and not code.strip():
                last_err = "code field is empty or whitespace"
                log(f"  -> Code payload empty; re-prompt ({i+1}/{JSON_RETRIES})")
                continue
            return payload
        except Exception as e:
            last_err = str(e)
            log(f"  -> JSON:MISS or invalid ({last_err}); re-prompt ({i+1}/{JSON_RETRIES})")
    raise ValueError(last_err or "no parse")

def _build_repair_prompt(original_prompt: str, *, path: str, language: str, error: BaseException, last_code: str) -> str:
    err_type = type(error).__name__
    err_msg = str(error)
    details = ""
    if isinstance(error, SyntaxError):
        se: SyntaxError = error  # type: ignore
        line = getattr(se, 'lineno', None)
        col = getattr(se, 'offset', None)
        text = getattr(se, 'text', None)
        details = f"\n# SyntaxError details\nline={line} col={col}\ntext={text or ''}"
    snippet = last_code[:4000]
    return "\n".join([
        "You previously attempted to generate a file, but it failed.",
        f"Target path: {path}",
        f"Language expected: {language}",
        f"Failure: {err_type}: {err_msg}",
        details,
        "Fix the problem and return ONLY JSON with keys {\"language\", \"code\"}. No fences, no prose.",
        "The 'code' must be the FULL corrected file, not a patch.",
        "--- BEGIN YOUR PRIOR ATTEMPT (for reference) ---",
        snippet,
        "--- END PRIOR ATTEMPT ---",
        original_prompt,
    ])

def generate_single_file_with_repair(llm: ProxyGemini, fitem: Dict[str, Any], plan_paths: Sequence[str]) -> None:
    rel = fitem["path"].strip().lstrip("/\\")
    target = CODE_DIR / rel
    ext = target.suffix.lower()
    is_python = (ext == ".py")
    tag = rel.replace("/", "_")

    original_prompt = _dev_prompt_for_file(fitem, plan_paths)
    payload = _json_retry(llm, original_prompt, require_code=True, dump_dir=OUT_DIR / "llm_raw" / "files", tag=tag)
    last_code = str(payload.get("code", ""))

    # Attempt initial write with multi-round repair for Python files
    attempts = 0
    while True:
        try:
            if is_python:
                write_python_file(target, last_code)
            else:
                write_text_file(target, last_code)
            log(f"WROTE {target}")
            return
        except Exception as e:
            attempts += 1
            log(f"[UNIVERSAL] Pre-write error for {rel}; reprompting fix (attempt {attempts}/{REPAIR_RETRIES}): {type(e).__name__}: {e}")
            if not is_python or attempts >= REPAIR_RETRIES:
                raise
            repair_prompt = _build_repair_prompt(
                original_prompt,
                path=rel,
                language="python",
                error=e,
                last_code=last_code,
            )
            payload2 = _json_retry(llm, repair_prompt, require_code=True, dump_dir=OUT_DIR / "llm_raw" / "repairs", tag=f"repair_{tag}_{attempts}")
            last_code = str(payload2.get("code", ""))

def generate_single_test_with_repair(llm: ProxyGemini, titem: Dict[str, Any], plan_paths: Sequence[str]) -> None:
    rel = titem["path"].strip().lstrip("/\\")
    target = CODE_DIR / rel
    tag = rel.replace("/", "_")
    original_prompt = _test_prompt_for_file(titem, plan_paths)
    payload = _json_retry(
        llm,
        original_prompt,
        require_code=True,
        dump_dir=OUT_DIR / "llm_raw" / "tests",
        tag=tag,
    )
    last_code = str(payload.get("code", ""))

    attempts = 0
    while True:
        try:
            write_python_file(target, last_code)
            log(f"WROTE {target}")
            return
        except Exception as e:
            attempts += 1
            log(f"[UNIVERSAL] Pre-write error for test {rel}; reprompting fix (attempt {attempts}/{REPAIR_RETRIES}): {type(e).__name__}: {e}")
            if attempts >= REPAIR_RETRIES:
                raise
            repair_prompt = _build_repair_prompt(
                original_prompt,
                path=rel,
                language="python",
                error=e,
                last_code=last_code,
            )
            payload2 = _json_retry(llm, repair_prompt, require_code=True, dump_dir=OUT_DIR / "llm_raw" / "repairs", tag=f"repair_test_{tag}_{attempts}")
            last_code = str(payload2.get("code", ""))

def step_generate(plan: Dict[str, Any], llm: ProxyGemini) -> None:
    files = plan.get("files", [])
    tests = plan.get("tests", [])
    log(f"Generating {len(files)} code files and {len(tests)} test files")
    plan_paths = [f.get("path", "") for f in files]

    for i, fitem in enumerate(files, 1):
        rel = fitem["path"].strip().lstrip("/\\")
        log(f"Generating code file {i}/{len(files)}: {rel}")
        generate_single_file_with_repair(llm, fitem, plan_paths)

    for i, titem in enumerate(tests, 1):
        rel = titem["path"].strip().lstrip("/\\")
        log(f"Generating test file {i}/{len(tests)}: {rel}")
        generate_single_test_with_repair(llm, titem, plan_paths)

# ---------------------- SYNTAX GATE ----------------------
def _collect_python_files(root: pathlib.Path) -> List[pathlib.Path]:
    return [p for p in root.rglob("*.py") if p.is_file()]

def syntax_gate(root: pathlib.Path) -> None:
    errors: List[str] = []
    for py in _collect_python_files(root):
        try:
            src = py.read_text(encoding="utf-8")
            compile(src, str(py), "exec")
        except SyntaxError as e:
            bad = (e.text or "").rstrip("\n")
            errors.append(f"{py.relative_to(root)}: SyntaxError {e.msg} at {e.lineno}:{e.offset} -> {bad}")
        except Exception as e:
            errors.append(f"{py.relative_to(root)}: read/compile error: {e}")
    if errors:
        log("Syntax gate failed:")
        for e in errors:
            log("  - " + e)
        raise SystemExit(2)
    log("Syntax gate: clean.")

# ---------------------- PACKAGE NORMALIZATION ----------------------
def normalize_packages(root_pkg: str = "src") -> None:
    root = CODE_DIR / root_pkg
    if not root.exists():
        return
    for py in root.rglob("*.py"):
        d = py.parent
        while True:
            init = d / "__init__.py"
            if not init.exists():
                init.write_text("# auto-added by CodePori\n", encoding="utf-8")
            if d == root:
                break
            d = d.parent
    log(f"Normalized packages under {root_pkg}/ (added __init__.py where missing).")

# ---------------------- AUTO-FIXERS ----------------------
def _autofix_relative_imports(mod: str, root_pkg: str = "src") -> bool:
    if not AUTOFIX_RELATIVE:
        return False
    target = CODE_DIR / pathlib.Path(*mod.split(".")).with_suffix(".py")
    if not target.exists():
        return False
    code = read_text(target, "")
    if not code:
        return False
    rel_parts = pathlib.Path(*mod.split(".")).with_suffix("").parts
    changed = False

    def replacer(match: re.Match[str]) -> str:
        nonlocal changed
        dots = match.group(1)
        rest = match.group(2)
        import_tail = match.group(3)
        level = len(dots)
        up = level - 1
        base = list(rel_parts)
        while up > 0 and len(base) > 1:
            base.pop()
            up -= 1
        if len(base) == 1:
            base = [root_pkg]
        abs_mod = ".".join(base + ([p for p in rest.split(".") if p] if rest else []))
        changed = True
        return f"from {abs_mod} import {import_tail}"

    new_code = re.sub(r"^\s*from\s+(\.+)([A-Za-z0-9_\.]*)\s+import\s+(.+)$", replacer, code, flags=re.MULTILINE)
    if changed and new_code != code:
        write_python_file(target, new_code)
        log(f"Auto-fixed relative imports in {safe_relpath(target)} -> absolute")
        return True
    return False

def _autofix_bad_config_imports() -> None:
    """Fix common bad patterns: 'from src.config import config' or 'import src.config.config'."""
    for py in CODE_DIR.rglob("*.py"):
        code = read_text(py, "")
        if not code:
            continue
        new = code
        # from src.config import config  -> import src.config as config
        new = re.sub(
            r"^\s*from\s+src\.config\s+import\s+config\s*$",
            "import src.config as config",
            new,
            flags=re.MULTILINE,
        )
        # import src.config.config -> import src.config as config
        new = re.sub(
            r"^\s*import\s+src\.config\.config\s*$",
            "import src.config as config",
            new,
            flags=re.MULTILINE,
        )
        if new != code:
            write_python_file(py, new)
            log(f"Auto-fixed config imports in {safe_relpath(py)}")

# ---------------------- UNIVERSAL IMPORT/API LINTER ----------------------
ImportSpec = Tuple[str, Tuple[str, ...]]  # (module, (symbols,))

def _module_to_relpath(mod: str) -> pathlib.Path:
    return pathlib.Path(*mod.split(".")).with_suffix(".py")

def _discover_test_imports(test_path: pathlib.Path) -> List[ImportSpec]:
    text = read_text(test_path, "")
    if not text:
        return []
    try:
        tree = ast.parse(text)
    except Exception:
        return []
    specs: List[ImportSpec] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom):
            if node.module:
                names = tuple(n.name for n in node.names if isinstance(n, ast.alias))
                specs.append((node.module, names))
        elif isinstance(node, ast.Import):
            for n in node.names:
                specs.append((n.name, ()))
    return specs

def _gather_all_test_imports(code_root: pathlib.Path) -> List[Tuple[pathlib.Path, ImportSpec]]:
    out: List[Tuple[pathlib.Path, ImportSpec]] = []
    tests_dir = code_root / "tests"
    if not tests_dir.exists():
        return out
    for test in tests_dir.rglob("test_*.py"):
        for spec in _discover_test_imports(test):
            out.append((test, spec))
    return out

def _try_import(mod: str) -> Tuple[bool, Optional[str], Optional[str]]:
    try:
        sys.path.insert(0, str(CODE_DIR))
        importlib.invalidate_caches()
        importlib.import_module(mod)
        return True, None, None
    except Exception as e:
        return False, f"{type(e).__name__}: {e}", traceback.format_exc()
    finally:
        if sys.path and sys.path[0] == str(CODE_DIR):
            sys.path.pop(0)

def _module_symbols(mod: str) -> Set[str]:
    try:
        sys.path.insert(0, str(CODE_DIR))
        importlib.invalidate_caches()
        m = importlib.import_module(mod)
        return set(dir(m))
    except Exception:
        return set()
    finally:
        if sys.path and sys.path[0] == str(CODE_DIR):
            sys.path.pop(0)

def lint_imports_and_symbols(code_root: pathlib.Path) -> Tuple[Set[str], Dict[str, Set[str]], Dict[str, str]]:
    missing_modules: Set[str] = set()
    missing_symbols: Dict[str, Set[str]] = {}
    broken_modules: Dict[str, str] = {}
    pairs = _gather_all_test_imports(code_root)
    for _test_file, (mod, names) in pairs:
        ok, err, _tb = _try_import(mod)
        if not ok:
            target = code_root / _module_to_relpath(mod)
            if target.exists():
                broken_modules[mod] = err or "ImportError"
                continue
            missing_modules.add(mod)
            continue
        if names:
            present = _module_symbols(mod)
            needed = set(names) - present
            if needed:
                missing_symbols.setdefault(mod, set()).update(needed)
    return missing_modules, missing_symbols, broken_modules

def _prompt_make_module(mod: str, sym_list: Sequence[str], plan_paths: Sequence[str]) -> str:
    schema = {"language": "python", "code": "<FULL FILE HERE>"}
    target_rel = str(_module_to_relpath(mod)).replace("\\", "/")
    project_desc = read_text(PROMPTS["project"]) or "(no project_description.txt)"
    dev1 = read_text(PROMPTS["dev1"]) or ""
    dev2 = read_text(PROMPTS["dev2"]) or ""
    root_pkg = target_rel.split("/", 1)[0] if "/" in target_rel else "src"
    return "\n".join(
        [
            "You are a SENIOR DEVELOPER. Create a NEW Python module as JSON only.",
            dev1, dev2,
            f"Target path (relative to repo root): {target_rel}",
            "Context: This module is referenced by tests and must exist.",
            f"It MUST define these top-level names: {list(sym_list)}",
            f"All imports MUST be absolute from the root package '{root_pkg}.' — never use relative imports.",
            "Keep it minimal but production-ready. Prefer stdlib; do not access network.",
            "Return ONLY a JSON object with keys {\"language\",\"code\"}. No fences, no prose.",
            json.dumps(schema, indent=2),
            "\nProject description for context:\n" + project_desc,
            f"\nOther planned files for context: {plan_paths}",
        ]
    )

def _prompt_edit_module_to_add_symbols(mod: str, missing: Sequence[str], existing_code: str, plan_paths: Sequence[str]) -> str:
    schema = {"language": "python", "code": "<FULL FILE HERE>"}
    target_rel = str(_module_to_relpath(mod)).replace("\\", "/")
    verify = read_text(PROMPTS["verify"]) or ""
    return "\n".join(
        [
            "You are a SENIOR DEVELOPER. Update the EXISTING file to add missing exports.",
            verify,
            f"Target path: {target_rel}",
            f"Missing symbols to add: {list(missing)}",
            "Rules:",
            "- Return ONLY JSON with {\"language\",\"code\"}.",
            "- No markdown/prose.",
            "- Preserve existing behavior; add minimal, correct definitions for the missing names.",
            "- **All imports must be absolute from the repo root package; never use relative imports.**",
            json.dumps(schema, indent=2),
            "\n--- BEGIN EXISTING FILE ---\n" + existing_code + "\n--- END EXISTING FILE ---\n",
            f"Other files for context: {plan_paths}",
        ]
    )

def targeted_reprompts(plan: Dict[str, Any], llm: ProxyGemini) -> None:
    if not ENABLE_LINTER or LINT_REPROMPTS <= 0:
        log("Universal linter/reprompts disabled or 0 retries configured.")
        return
    plan_paths = [f.get("path", "") for f in plan.get("files", [])]
    attempts = 0
    while attempts < LINT_REPROMPTS:
        attempts += 1
        log(f"Universal linter pass {attempts}/{LINT_REPROMPTS}...")
        missing_mods, missing_syms, broken_mods = lint_imports_and_symbols(CODE_DIR)

        for mod, err in sorted(broken_mods.items()):
            log(f"Broken module detected: {mod} -> {err}")
            if AUTOFIX_RELATIVE and "relative import" in (err or "").lower():
                if _autofix_relative_imports(mod):
                    ok, err2, _tb2 = _try_import(mod)
                    if ok:
                        log(f"Auto-fix successful for {mod}")
                        continue
                    else:
                        log(f"Auto-fix attempted for {mod} but still failing: {err2}")
            expected: Set[str] = set()
            for _t, (m, names) in _gather_all_test_imports(CODE_DIR):
                if m == mod and names:
                    expected.update(names)
            prompt = _prompt_make_module(mod, sorted(expected), plan_paths)
            try:
                payload = _json_retry(llm, prompt, require_code=True, dump_dir=OUT_DIR / "llm_raw" / "reprompts", tag=f"regen_{mod.replace('.', '_')}")
                code = str(payload.get("code", ""))
                if code.strip():
                    target = CODE_DIR / _module_to_relpath(mod)
                    write_python_file(target, code)
                    log(f"WROTE (broken module regen) {safe_relpath(target)}")
                else:
                    log(f"Targeted reprompt (broken module) got empty code for {mod}")
            except Exception as e:
                log(f"Targeted reprompt (broken module {mod}) failed: {e}")

        for mod in sorted(missing_mods):
            expected: Set[str] = set()
            for _t, (m, names) in _gather_all_test_imports(CODE_DIR):
                if m == mod and names:
                    expected.update(names)
            prompt = _prompt_make_module(mod, sorted(expected), plan_paths)
            try:
                payload = _json_retry(llm, prompt, require_code=True, dump_dir=OUT_DIR / "llm_raw" / "reprompts", tag=f"missing_{mod.replace('.', '_')}")
                code = str(payload.get("code", ""))
                if not code.strip():
                    raise ValueError("empty code")
                target = CODE_DIR / _module_to_relpath(mod)
                write_python_file(target, code)
                log(f"WROTE (missing module) {safe_relpath(target)}")
            except Exception as e:
                log(f"Targeted reprompt (module {mod}) failed: {e}")

        for mod, symset in sorted(missing_syms.items()):
            target = CODE_DIR / _module_to_relpath(mod)
            existing = read_text(target, "")
            if not existing:
                continue
            prompt = _prompt_edit_module_to_add_symbols(mod, sorted(symset), existing, plan_paths)
            try:
                payload = _json_retry(llm, prompt, require_code=True, dump_dir=OUT_DIR / "llm_raw" / "reprompts", tag=f"addsyms_{mod.replace('.', '_')}")
                code = str(payload.get("code", ""))
                if not code.strip():
                    raise ValueError("empty code")
                write_python_file(target, code)
                log(f"WROTE (added symbols) {safe_relpath(target)}")
            except Exception as e:
                log(f"Targeted reprompt (symbols {mod}) failed: {e}")

        normalize_packages("src")
        missing_mods2, missing_syms2, broken_mods2 = lint_imports_and_symbols(CODE_DIR)
        if not missing_mods2 and not missing_syms2 and not broken_mods2:
            log("Universal linter: all modules/symbols satisfied.")
            return
        else:
            log(
                "Universal linter still sees gaps: "
                f"missing_modules={sorted(missing_mods2)} "
                f"missing_symbols={{ {', '.join(f'{k}: {sorted(v)}' for k,v in missing_syms2.items())} }} "
                f"broken_modules={{ {', '.join(f'{k}: {v}' for k,v in broken_mods2.items())} }}"
            )
    log("Universal linter: reached retry limit; continuing to test run.")

# ---------------------- FINALIZER ----------------------
def step_finalize(llm: ProxyGemini) -> None:
    final1 = read_text(PROMPTS["final1"]) or ""
    final2 = read_text(PROMPTS["final2"]) or ""
    schema = {"readme": "# Project...", "requirements": "pytest\nrequests\nmarkdown-it-py\n"}
    prompt = "\n".join(
        [
            "You are the FINALIZER.",
            final1, final2,
            "Return ONLY a JSON object with keys {\"readme\", \"requirements\"}. No fences, no prose.",
            json.dumps(schema, indent=2),
        ]
    )
    txt = llm.ask(prompt) or ""
    try:
        obj = parse_json_best(txt, want=dict, require_code=False, dump_dir=OUT_DIR / "llm_raw" / "finalizer", tag="final")
    except Exception:
        obj = {}
    readme = str(obj.get("readme", "# Project\n\n(README was not returned as JSON.)\n"))
    reqs = str(obj.get("requirements", "pytest\nrequests\nmarkdown-it-py\n"))
    write_text(CODE_DIR / "README.md", readme)
    write_text(CODE_DIR / "requirements.txt", reqs)

# ---------------------- PYTEST HELPERS (plugin-aware) ----------------------
def _tests_need_fixture(name: str) -> bool:
    tests_dir = CODE_DIR / "tests"
    if not tests_dir.exists():
        return False
    pattern = re.compile(rf"\b{name}\b")
    for p in tests_dir.rglob("test_*.py"):
        try:
            txt = p.read_text(encoding="utf-8", errors="ignore")
            if pattern.search(txt):
                return True
        except Exception:
            pass
    return False

def ensure_pytest_plugins_installed() -> List[str]:
    needed: List[str] = []
    if _tests_need_fixture("mocker"):
        needed.append("pytest-mock")
    if _tests_need_fixture("fs"):
        needed.append("pyfakefs")
    if not needed:
        return []
    log(f"Installing pytest plugins (best-effort): {', '.join(needed)}")
    try:
        subprocess.run([sys.executable, "-m", "pip", "install", *needed], check=False)
    except Exception as e:
        log(f"pip install (pytest plugins) failed (continuing): {e}")
    return needed

def _is_plugin_import_crash(pytest_output: str) -> bool:
    # Heuristics: entrypoint loading + ImportError/ModuleNotFoundError during plugin import.
    if "load_setuptools_entrypoints(\"pytest11\")" in pytest_output:
        return True
    if "plugin.py" in pytest_output and "ImportError" in pytest_output:
        return True
    if "ImportError" in pytest_output and "pytest_flask" in pytest_output:
        return True
    if "site-packages" in pytest_output and "fixtures.py" in pytest_output and "ImportError" in pytest_output:
        return True
    return False

def _build_safe_plugin_args() -> List[str]:
    args: List[str] = []
    if _tests_need_fixture("mocker"):
        args += ["-p", "pytest_mock"]
    if _tests_need_fixture("fs"):
        args += ["-p", "pyfakefs"]
    return args

def run_pytest_once(autoload: bool, extra_args: Optional[List[str]] = None) -> Tuple[int, str]:
    env = dict(os.environ)
    if autoload:
        env.pop("PYTEST_DISABLE_PLUGIN_AUTOLOAD", None)
    else:
        env["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"

    val = env.get("PYTEST_DISABLE_PLUGIN_AUTOLOAD")
    log(f"PYTEST_DISABLE_PLUGIN_AUTOLOAD={val if val is not None else 'None'} (autoload={'ON' if autoload else 'OFF'})")

    cmd = [sys.executable, "-m", "pytest", "-q"]
    if extra_args:
        cmd += extra_args

    proc = subprocess.run(cmd, cwd=str(CODE_DIR), env=env, capture_output=True, text=True)
    out = (proc.stdout or "") + "\n" + (proc.stderr or "")
    for line in out.splitlines()[:400]:
        log(line)
    LOG_FILE.write_text(read_text(LOG_FILE) + "\n=== PYTEST FULL OUTPUT ===\n" + out, encoding="utf-8")
    return proc.returncode, out

def run_pytest_plugin_aware() -> Tuple[int, str]:
    ensure_pytest_plugins_installed()

    rc, out = run_pytest_once(autoload=True, extra_args=None)
    if rc == 0:
        return rc, out

    if _is_plugin_import_crash(out):
        log("Detected plugin import crash; retrying with autoload OFF and safelisted plugins only.")
        safe_args = _build_safe_plugin_args()
        rc2, out2 = run_pytest_once(autoload=False, extra_args=safe_args)
        return rc2, out2

    return rc, out

# ---------------------- RUN PYTEST + ERROR PARSING ----------------------
_MNF_RE = re.compile(r"ModuleNotFoundError:\s+No module named '([^']+)'")
_CANNOT_IMPORT_RE = re.compile(r"cannot import name '([^']+)' from '([^']+)'")

def run_pytest_and_maybe_repair(plan: Dict[str, Any], llm: ProxyGemini) -> int:
    req = CODE_DIR / "requirements.txt"
    if req.exists():
        log("Installing requirements (best-effort)...")
        try:
            subprocess.run([sys.executable, "-m", "pip", "install", "-r", str(req)], check=False)
        except Exception as e:
            log(f"pip install failed (continuing): {e}")

    _autofix_bad_config_imports()
    normalize_packages("src")

    rc, pout = run_pytest_plugin_aware()
    if rc == 0:
        log("✅ Tests passed.")
        return 0

    mm = set(m.group(1) for m in _MNF_RE.finditer(pout))
    ms_pairs = list(_CANNOT_IMPORT_RE.finditer(pout))
    missing_symbols: Dict[str, Set[str]] = {}
    for m in ms_pairs:
        sym = m.group(1); mod = m.group(2)
        missing_symbols.setdefault(mod, set()).add(sym)

    if (mm or missing_symbols) and LINT_REPROMPTS > 0:
        log("Detected pytest import/name errors. Attempting targeted repair...")
        plan_paths = [f.get("path", "") for f in plan.get("files", [])]

        for mod in sorted(mm):
            target = CODE_DIR / _module_to_relpath(mod)
            if target.exists():
                if _autofix_relative_imports(mod):
                    ok, err2, _ = _try_import(mod)
                    if ok:
                        log(f"Auto-fix successful for {mod}")
                        continue
                    else:
                        log(f"Auto-fix attempted for {mod} but still failing: {err2}")
            expected: Set[str] = set()
            for _t, (m, names) in _gather_all_test_imports(CODE_DIR):
                if m == mod and names:
                    expected.update(names)
            prompt = _prompt_make_module(mod, sorted(expected), plan_paths)
            try:
                payload = _json_retry(llm, prompt, require_code=True, dump_dir=OUT_DIR / "llm_raw" / "reprompts", tag=f"pytest_module_{mod.replace('.', '_')}")
                code = str(payload.get("code", ""))
                if not code.strip():
                    raise ValueError("empty code")
                write_python_file(target, code)
                log(f"WROTE (pytest-module) {safe_relpath(target)}")
            except Exception as e:
                log(f"pytest-module repair failed for {mod}: {e}")

        for mod, syms in sorted(missing_symbols.items()):
            target = CODE_DIR / _module_to_relpath(mod)
            existing = read_text(target, "")
            if not existing:
                continue
            prompt = _prompt_edit_module_to_add_symbols(mod, sorted(syms), existing, plan_paths)
            try:
                payload = _json_retry(llm, prompt, require_code=True, dump_dir=OUT_DIR / "llm_raw" / "reprompts", tag=f"pytest_symbols_{mod.replace('.', '_')}")
                code = str(payload.get("code", ""))
                if not code.strip():
                    raise ValueError("empty code")
                write_python_file(target, code)
                log(f"WROTE (pytest-symbols) {safe_relpath(target)}")
            except Exception as e:
                log(f"pytest-symbols repair failed for {mod}: {e}")

        normalize_packages("src")
        syntax_gate(CODE_DIR)
        rc2, pout2 = run_pytest_plugin_aware()
        if rc2 == 0:
            log("✅ Tests passed after targeted repair.")
            return 0
        else:
            log("❌ Tests still failing after targeted repair. See output above and run.log")
            return 1

    log("❌ Tests failed. See pytest output above and ./output/run.log")
    return 1

# ---------------------- HEALTHCHECK ----------------------
def proxy_healthcheck() -> None:
    try:
        r = requests.get(f"{PROXY_BASE}/health", timeout=10)
        if r.ok:
            data = r.json()
            log(
                "Proxy health: "
                f"status={data.get('status')} "
                f"valid_keys={data.get('valid_keys') or data.get('total_keys')} "
                f"cooldown={data.get('cooldown') or data.get('cooldown_keys')} "
                f"exhausted={data.get('exhausted') or data.get('exhausted_keys_per_model')}"
            )
        else:
            log(f"Warning: /health HTTP {r.status_code}")
    except Exception as e:
        log(f"Warning: could not reach proxy /health: {e}")

# ---------------------- MAIN ----------------------
def main() -> int:
    try:
        snapshot_previous()
        ensure_dirs()
        LOG_FILE.write_text("", encoding="utf-8")
        log("Starting CodePori (Proxy/Gemini) pipeline...")
        log(f"Proxy base: {PROXY_BASE}")
        log(f"Primary model: {PRIMARY_MODEL} | Fallback: {FALLBACK_MODEL}")
        proxy_healthcheck()

        llm = ProxyGemini(PROXY_BASE, PRIMARY_MODEL, FALLBACK_MODEL)

        # 1) Plan
        plan = step_plan(llm)
        log("Generated plan.")

        # 2) Generate files & tests (each Python file uses multi-round compile-checked repair)
        step_generate(plan, llm)
        log("Generated files.")

        # 3) Syntax gate (verification)
        syntax_gate(CODE_DIR)

        # 4) Normalize packages + import autofixes
        normalize_packages("src")
        _autofix_bad_config_imports()

        # 5) Universal linter + targeted reprompts (pre-test)
        targeted_reprompts(plan, llm)

        # 6) Finalizer
        step_finalize(llm)
        log("Finalized repo.")

        # 7) Diff report (ALWAYS print)
        write_diff_report()
        log_diff_report_contents()

        # 8) Pytest (plugin-aware)
        rc = run_pytest_and_maybe_repair(plan, llm)
        if rc == 0:
            log("DONE: output in ./output/code")
            return 0
        return rc

    except SystemExit as e:
        return int(e.code)
    except Exception as e:
        log(f"FATAL: {e}\n{traceback.format_exc()}")
        return 2

if __name__ == "__main__":
    sys.exit(main())
